-- =====================================================================
-- PRIME SOC PORTAL v4 — PostgreSQL schema
-- This file is mounted into the official postgres image's
-- /docker-entrypoint-initdb.d/ and runs ONCE on first cluster init.
--
-- The portal stores NO security telemetry here (that all lives in the Wazuh
-- Indexer). Postgres only holds portal-local state: sessions, audit trail,
-- analyst watchlist, saved searches, and locally-tracked incidents.
-- Column names match src/lib/db.ts exactly.
-- =====================================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto"; -- for gen_random_uuid()

-- ---------------------------------------------------------------------
-- sessions: one row per successful login (audit of who/when/from where)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sessions (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username    TEXT        NOT NULL,
  role        TEXT        NOT NULL,
  is_admin    BOOLEAN     NOT NULL DEFAULT FALSE,
  grp         TEXT,                       -- tenant DLS key; NULL for admins
  ip_address  TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at  TIMESTAMPTZ NOT NULL,
  revoked     BOOLEAN     NOT NULL DEFAULT FALSE
);
CREATE INDEX IF NOT EXISTS idx_sessions_username   ON sessions (username);
CREATE INDEX IF NOT EXISTS idx_sessions_created_at ON sessions (created_at DESC);

-- ---------------------------------------------------------------------
-- audit_log: every privileged action (login, logout, export, case create)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_log (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username    TEXT        NOT NULL,
  action      TEXT        NOT NULL,
  resource    TEXT,
  details     JSONB,
  ip_address  TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_audit_username   ON audit_log (username);
CREATE INDEX IF NOT EXISTS idx_audit_action     ON audit_log (action);
CREATE INDEX IF NOT EXISTS idx_audit_created_at ON audit_log (created_at DESC);

-- ---------------------------------------------------------------------
-- watchlist: analyst-curated IOCs (ip/domain/hash) to highlight
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS watchlist (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  added_by    TEXT        NOT NULL,
  type        TEXT        NOT NULL,       -- ip | domain | hash | user | ...
  value       TEXT        NOT NULL,
  label       TEXT,
  tenant      TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (type, value, tenant)
);
CREATE INDEX IF NOT EXISTS idx_watchlist_value ON watchlist (value);

-- ---------------------------------------------------------------------
-- saved_searches: per-user saved SIEM filter sets
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS saved_searches (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username    TEXT        NOT NULL,
  name        TEXT        NOT NULL,
  filters     JSONB       NOT NULL DEFAULT '{}'::jsonb,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_saved_username ON saved_searches (username);

-- ---------------------------------------------------------------------
-- incidents: locally-tracked incidents (alert correlation -> IRIS case)
-- An incident is recorded even when IRIS is unreachable, so nothing is lost.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS incidents (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant       TEXT,
  title        TEXT        NOT NULL,
  severity     TEXT        NOT NULL,
  alert_ids    TEXT[]      NOT NULL DEFAULT '{}',
  iris_case_id TEXT,
  status       TEXT        NOT NULL DEFAULT 'open',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_incidents_tenant     ON incidents (tenant);
CREATE INDEX IF NOT EXISTS idx_incidents_status     ON incidents (status);
CREATE INDEX IF NOT EXISTS idx_incidents_created_at ON incidents (created_at DESC);
