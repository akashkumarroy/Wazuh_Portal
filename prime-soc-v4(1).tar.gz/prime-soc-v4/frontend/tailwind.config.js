/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        'bg-primary': '#080c14',
        'bg-secondary': '#0d1117',
        'bg-card': '#111827',
        'bg-card-hover': '#141e2e',
        cyan: '#00d8e8',
        purple: '#7c3aed',
        'brand-blue': '#1a4fa3',
        'brand-red': '#dc2626',
        'text-primary': '#f1f5f9',
        'text-secondary': '#94a3b8',
        'text-dim': '#475569',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'monospace'],
      },
    },
  },
  plugins: [],
};
