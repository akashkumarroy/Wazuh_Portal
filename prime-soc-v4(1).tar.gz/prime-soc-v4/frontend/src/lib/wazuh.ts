import type { SessionPayload } from './auth';

/**
 * Wazuh Indexer (OpenSearch) data layer.
 *
 * Hard rules baked in here (confirmed against live cluster):
 *  - Rule 4: every request carries ?ignore_unavailable=true (daily index gaps exist, e.g. 2026.05.23).
 *  - Rule 5: alert queries use the wildcard index wazuh-alerts-4.x-* and a time range filter.
 *  - Rule 6: every fetch wrapped in a 15s AbortController timeout.
 *  - Bounded aggregations are fast (125ms / 813 shards confirmed); UNBOUNDED scans are the danger (26s).
 *  - Alerts tenant field  = agent.labels.group (NOT agent.groups, which does not exist).
 *  - Monitoring group/status are TEXT -> never aggregate/sort them server-side; tally in JS.
 *  - GeoLocation.location is a geo_point. country_name / data.srcip / rule.mitre.tactic /
 *    rule.pci_dss all aggregate WITHOUT a .keyword suffix.
 */

const ALERTS_INDEX = 'wazuh-alerts-4.x-*';
const MONITORING_INDEX = 'wazuh-monitoring-*';
const STATISTICS_INDEX = 'wazuh-statistics-*';
const VULN_INDEX = 'wazuh-states-vulnerabilities-*';
const TENANT_FIELD = 'agent.labels.group';

export const INDEXER_TIMEOUT_MS = 15_000; // Rule 6

export type TimeRange = '1h' | '6h' | '24h' | '7d' | '30d';

export const TIME_RANGE_LABELS: Record<TimeRange, string> = {
  '1h': 'Last 1 Hour',
  '6h': 'Last 6 Hours',
  '24h': 'Last 24 Hours',
  '7d': 'Last 7 Days',
  '30d': 'Last 30 Days',
};

export function normalizeRange(input: string | null | undefined): TimeRange {
  const allowed: TimeRange[] = ['1h', '6h', '24h', '7d', '30d'];
  return allowed.includes(input as TimeRange) ? (input as TimeRange) : '24h';
}

export type Severity = 'critical' | 'high' | 'medium' | 'low' | 'info';

export const SEVERITY_COLORS: Record<Severity, string> = {
  critical: '#ef4444',
  high: '#f59e0b',
  medium: '#eab308',
  low: '#3b82f6',
  info: '#475569',
};

export function severityFromLevel(level: number | undefined | null): Severity {
  const l = typeof level === 'number' ? level : 0;
  if (l >= 13) return 'critical';
  if (l >= 10) return 'high';
  if (l >= 7) return 'medium';
  if (l >= 4) return 'low';
  return 'info';
}

// ---------------------------------------------------------------------------
// Low-level request helper
// ---------------------------------------------------------------------------

function base(): string {
  const url = process.env.WAZUH_INDEXER_URL;
  if (!url) throw new Error('WAZUH_INDEXER_URL is not set');
  return url.replace(/\/$/, '');
}

function authHeader(): string {
  const user = process.env.WAZUH_INDEXER_USER;
  const pass = process.env.WAZUH_INDEXER_PASS;
  if (!user || !pass) throw new Error('WAZUH_INDEXER_USER / WAZUH_INDEXER_PASS not set');
  return 'Basic ' + Buffer.from(`${user}:${pass}`).toString('base64');
}

/**
 * Perform an OpenSearch _search (or other GET/POST) with the admin credentials,
 * a 15s timeout, and ignore_unavailable always appended. All data queries flow
 * through here so the rules are enforced in one place.
 */
async function osRequest<T = any>(
  path: string,
  body?: unknown,
  method: 'GET' | 'POST' = 'POST',
): Promise<T> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), INDEXER_TIMEOUT_MS);
  const sep = path.includes('?') ? '&' : '?';
  const url = `${base()}${path}${sep}ignore_unavailable=true`;
  try {
    const res = await fetch(url, {
      method,
      headers: {
        Authorization: authHeader(),
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal: controller.signal,
      cache: 'no-store',
    });
    const json = (await res.json()) as T;
    if (!res.ok) {
      const reason = (json as any)?.error?.reason || (json as any)?.error?.type || `HTTP ${res.status}`;
      throw new Error(`Indexer query failed: ${reason}`);
    }
    return json;
  } catch (err) {
    if ((err as Error)?.name === 'AbortError') {
      throw new Error('Wazuh Indexer query timed out (15s)');
    }
    throw err;
  } finally {
    clearTimeout(timeout);
  }
}

async function search<T = any>(index: string, body: unknown): Promise<T> {
  return osRequest<T>(`/${index}/_search`, body, 'POST');
}

// ---------------------------------------------------------------------------
// Query building blocks
// ---------------------------------------------------------------------------

function rangeFilter(range: TimeRange) {
  return { range: { timestamp: { gte: `now-${range}`, lte: 'now' } } };
}

/**
 * Tenant isolation: admins (group === null) see everything; clients are scoped
 * to their group via a term filter on agent.labels.group. "Unknown" users that
 * we still treat as admin must pass group=null.
 */
function tenantFilter(group: string | null): unknown[] {
  if (!group) return [];
  return [{ match: { [TENANT_FIELD]: group } }];
}

/** Build the standard bool query: time range + optional tenant + extra filters. */
function boolQuery(range: TimeRange, group: string | null, extra: unknown[] = []) {
  return {
    bool: {
      filter: [rangeFilter(range), ...tenantFilter(group), ...extra],
    },
  };
}

function groupFromSession(session: Pick<SessionPayload, 'is_admin' | 'group'>): string | null {
  return session.is_admin ? null : session.group ?? null;
}

// ---------------------------------------------------------------------------
// Severity aggregation shared block
// ---------------------------------------------------------------------------

const severityAggs = {
  critical: { filter: { range: { 'rule.level': { gte: 13 } } } },
  high: { filter: { range: { 'rule.level': { gte: 10, lt: 13 } } } },
  medium: { filter: { range: { 'rule.level': { gte: 7, lt: 10 } } } },
  low: { filter: { range: { 'rule.level': { gte: 4, lt: 7 } } } },
  info: { filter: { range: { 'rule.level': { lt: 4 } } } },
};

function histogramInterval(range: TimeRange): string {
  switch (range) {
    case '1h': return '5m';
    case '6h': return '15m';
    case '24h': return '1h';
    case '7d': return '6h';
    case '30d': return '1d';
  }
}

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface AlertHit {
  _id: string;
  _index: string;
  _source: Record<string, any>;
}

export interface DashboardData {
  range: TimeRange;
  label: string;
  total: number;
  severity: Record<Severity, number>;
  agentHealthPct: number;
  activeAgents: number;
  totalAgents: number;
  volume: { ts: number; count: number }[];
  topAgents: { key: string; count: number }[];
  topTactics: { key: string; count: number }[];
  topCountries: { key: string; count: number }[];
  topSrcIps: { key: string; count: number }[];
  eps: { ts: number; received: number; written: number }[];
  recent: AlertHit[];
}

// ---------------------------------------------------------------------------
// Dashboard (sequential, bounded — Rule 3: no Promise.all)
// ---------------------------------------------------------------------------

export async function getDashboard(
  session: Pick<SessionPayload, 'is_admin' | 'group'>,
  range: TimeRange = '24h',
): Promise<DashboardData> {
  const group = groupFromSession(session);

  // 1) Combined alert aggregation — single bounded _search (confirmed ~125ms).
  const aggBody = {
    size: 0,
    track_total_hits: true,
    query: boolQuery(range, group),
    aggs: {
      ...severityAggs,
      per_bucket: { date_histogram: { field: 'timestamp', fixed_interval: histogramInterval(range), min_doc_count: 0 } },
      top_agents: { terms: { field: 'agent.name', size: 10 } },
      top_tactics: { terms: { field: 'rule.mitre.tactic', size: 10 } },
      top_country: { terms: { field: 'GeoLocation.country_name', size: 10 } },
      top_srcip: { terms: { field: 'data.srcip', size: 10 } },
    },
  };
  const agg = await search<any>(ALERTS_INDEX, aggBody);
  const a = agg.aggregations || {};

  // 2) Recent alerts (separate bounded fetch, after the agg — sequential).
  const recentBody = {
    size: 20,
    track_total_hits: false,
    query: boolQuery(range, group),
    sort: [{ timestamp: { order: 'desc' } }],
    _source: [
      'timestamp', 'agent.name', 'agent.id', 'agent.ip', 'agent.labels.group',
      'rule.id', 'rule.level', 'rule.description', 'rule.groups',
      'rule.mitre.id', 'rule.mitre.technique', 'rule.mitre.tactic',
      'data.srcip', 'data.dstip', 'location', 'manager.name',
      'GeoLocation.country_name', 'GeoLocation.city_name',
    ],
  };
  const recent = await search<any>(ALERTS_INDEX, recentBody);

  // 3) EPS / performance from statistics index (sequential).
  const eps = await getEps(range);

  // 4) Agent health from monitoring (JS tally — group/status are text).
  const agents = await getAgentSummary(group);

  const total: number = agg.hits?.total?.value ?? 0;
  const buckets = (a.per_bucket?.buckets || []) as any[];

  return {
    range,
    label: TIME_RANGE_LABELS[range],
    total,
    severity: {
      critical: a.critical?.doc_count ?? 0,
      high: a.high?.doc_count ?? 0,
      medium: a.medium?.doc_count ?? 0,
      low: a.low?.doc_count ?? 0,
      info: a.info?.doc_count ?? 0,
    },
    activeAgents: agents.active,
    totalAgents: agents.total,
    agentHealthPct: agents.total > 0 ? Math.round((agents.active / agents.total) * 100) : 0,
    volume: buckets.map((b) => ({ ts: b.key, count: b.doc_count })),
    topAgents: mapBuckets(a.top_agents),
    topTactics: mapBuckets(a.top_tactics),
    topCountries: mapBuckets(a.top_country),
    topSrcIps: mapBuckets(a.top_srcip),
    eps,
    recent: (recent.hits?.hits || []) as AlertHit[],
  };
}

function mapBuckets(agg: any): { key: string; count: number }[] {
  return ((agg?.buckets as any[]) || []).map((b) => ({ key: String(b.key), count: b.doc_count }));
}

// ---------------------------------------------------------------------------
// Alerts (paginated + filtered)
// ---------------------------------------------------------------------------

export interface AlertQueryOptions {
  range?: TimeRange;
  page?: number;
  pageSize?: number;
  search?: string;
  minLevel?: number;
  maxLevel?: number;
  ruleGroup?: string;        // e.g. 'syscheck' (FIM), 'sca', 'malware'
  mitreTagged?: boolean;     // only alerts with rule.mitre.id present
}

export async function getAlerts(
  session: Pick<SessionPayload, 'is_admin' | 'group'>,
  opts: AlertQueryOptions = {},
): Promise<{ total: number; hits: AlertHit[] }> {
  const group = groupFromSession(session);
  const range = normalizeRange(opts.range);
  const page = Math.max(0, opts.page ?? 0);
  const pageSize = Math.min(200, Math.max(1, opts.pageSize ?? 20));

  const extra: unknown[] = [];
  if (typeof opts.minLevel === 'number' || typeof opts.maxLevel === 'number') {
    const lvl: Record<string, number> = {};
    if (typeof opts.minLevel === 'number') lvl.gte = opts.minLevel;
    if (typeof opts.maxLevel === 'number') lvl.lte = opts.maxLevel;
    extra.push({ range: { 'rule.level': lvl } });
  }
  if (opts.ruleGroup) extra.push({ match: { 'rule.groups': opts.ruleGroup } });
  if (opts.mitreTagged) extra.push({ exists: { field: 'rule.mitre.id' } });

  const must: unknown[] = [];
  if (opts.search && opts.search.trim()) {
    must.push({
      multi_match: {
        query: opts.search.trim(),
        fields: ['rule.description', 'agent.name', 'data.srcip', 'full_log', 'location'],
        type: 'best_fields',
      },
    });
  }

  const query = {
    bool: {
      filter: [rangeFilter(range), ...tenantFilter(group), ...extra],
      ...(must.length ? { must } : {}),
    },
  };

  const res = await search<any>(ALERTS_INDEX, {
    size: pageSize,
    from: page * pageSize,
    track_total_hits: true,
    query,
    sort: [{ timestamp: { order: 'desc' } }],
  });

  return {
    total: res.hits?.total?.value ?? 0,
    hits: (res.hits?.hits || []) as AlertHit[],
  };
}

export async function getAlertById(
  session: Pick<SessionPayload, 'is_admin' | 'group'>,
  id: string,
): Promise<AlertHit | null> {
  const group = groupFromSession(session);
  // _id search across the wildcard index; still apply tenant filter so a client
  // can never read another tenant's alert by guessing an id.
  const res = await search<any>(ALERTS_INDEX, {
    size: 1,
    query: {
      bool: {
        filter: [{ ids: { values: [id] } }, ...tenantFilter(group)],
      },
    },
  });
  const hit = res.hits?.hits?.[0];
  return hit ? (hit as AlertHit) : null;
}

// ---------------------------------------------------------------------------
// Agents / monitoring (JS tally — Rule: group & status are text fields)
// ---------------------------------------------------------------------------

export interface AgentRecord {
  name: string;
  id: string;
  ip: string;
  status: string;
  group: string[];
  osName: string;
  osPlatform: string;
  osVersion: string;
  lastKeepAlive: string;
  dateAdd: string;
  manager: string;
  nodeName: string;
  version: string;
}

export interface AgentSummary {
  total: number;
  active: number;
  disconnected: number;
  pending: number;
  agents: AgentRecord[];
  byOs: { key: string; count: number }[];
  byGroup: { key: string; count: number }[];
}

/**
 * Fetch recent monitoring snapshots and dedup to the latest doc per agent id,
 * then tally in JS. We deliberately do NOT aggregate/sort on group/status (text).
 * Sorting by lastKeepAlive (a date) is allowed and gives us latest-first.
 */
export async function getAgentSummary(group: string | null, window: string = 'now-2h'): Promise<AgentSummary> {
  const filter: unknown[] = [{ range: { lastKeepAlive: { gte: window, lte: 'now' } } }];
  if (group) filter.push({ match: { group } }); // text match for retrieval is allowed

  const res = await search<any>(MONITORING_INDEX, {
    size: 5000,
    track_total_hits: false,
    query: { bool: { filter } },
    sort: [{ lastKeepAlive: { order: 'desc' } }],
    _source: [
      'name', 'id', 'ip', 'status', 'group', 'os.name', 'os.platform', 'os.version',
      'lastKeepAlive', 'dateAdd', 'manager', 'node_name', 'version',
    ],
  });

  const hits = (res.hits?.hits || []) as { _source: any }[];
  const latest = new Map<string, AgentRecord>();
  for (const h of hits) {
    const s = h._source || {};
    const id = String(s.id ?? s.name ?? '');
    if (!id || latest.has(id)) continue; // first occurrence is newest (sorted desc)
    latest.set(id, {
      name: s.name ?? '',
      id,
      ip: s.ip ?? '',
      status: s.status ?? 'unknown',
      group: Array.isArray(s.group) ? s.group : s.group ? [s.group] : [],
      osName: s.os?.name ?? '',
      osPlatform: s.os?.platform ?? '',
      osVersion: s.os?.version ?? '',
      lastKeepAlive: s.lastKeepAlive ?? '',
      dateAdd: s.dateAdd ?? '',
      manager: s.manager ?? '',
      nodeName: s.node_name ?? '',
      version: s.version ?? '',
    });
  }

  const agents = Array.from(latest.values());
  const osCount = new Map<string, number>();
  const grpCount = new Map<string, number>();
  let active = 0, disconnected = 0, pending = 0;

  for (const ag of agents) {
    const st = (ag.status || '').toLowerCase();
    if (st === 'active') active++;
    else if (st === 'disconnected') disconnected++;
    else if (st === 'pending') pending++;
    if (ag.osName) osCount.set(ag.osName, (osCount.get(ag.osName) || 0) + 1);
    for (const g of ag.group) grpCount.set(g, (grpCount.get(g) || 0) + 1);
  }

  const toSorted = (m: Map<string, number>) =>
    Array.from(m.entries()).map(([key, count]) => ({ key, count })).sort((x, y) => y.count - x.count);

  return {
    total: agents.length,
    active,
    disconnected,
    pending,
    agents,
    byOs: toSorted(osCount),
    byGroup: toSorted(grpCount),
  };
}

// ---------------------------------------------------------------------------
// EPS / statistics
// ---------------------------------------------------------------------------

export async function getEps(range: TimeRange): Promise<{ ts: number; received: number; written: number }[]> {
  // statistics docs have analysisd.events_received / alerts_written and a timestamp.
  const res = await search<any>(STATISTICS_INDEX, {
    size: 0,
    query: { range: { timestamp: { gte: `now-${range}`, lte: 'now' } } },
    aggs: {
      per_bucket: {
        date_histogram: { field: 'timestamp', fixed_interval: histogramInterval(range), min_doc_count: 0 },
        aggs: {
          received: { avg: { field: 'analysisd.events_received' } },
          written: { avg: { field: 'analysisd.alerts_written' } },
        },
      },
    },
  });
  const buckets = (res.aggregations?.per_bucket?.buckets || []) as any[];
  return buckets.map((b) => ({
    ts: b.key,
    received: Math.round(b.received?.value ?? 0),
    written: Math.round(b.written?.value ?? 0),
  }));
}

// ---------------------------------------------------------------------------
// Tenants (auto-synced from agent.labels.group — NOT the Kibana tenants API)
// ---------------------------------------------------------------------------

export interface TenantSummary {
  group: string;
  total: number;
  critical: number;
  high: number;
  medium: number;
  sparkline: number[];
  lastAlert: number | null;
}

/** Admin-only: build the tenant overview from a single bounded aggregation. */
export async function getTenants(range: TimeRange = '24h'): Promise<TenantSummary[]> {
  const res = await search<any>(ALERTS_INDEX, {
    size: 0,
    query: boolQuery(range, null),
    aggs: {
      tenants: {
        terms: { field: TENANT_FIELD, size: 100 },
        aggs: {
          ...severityAggs,
          spark: { date_histogram: { field: 'timestamp', fixed_interval: histogramInterval(range), min_doc_count: 0 } },
          last_alert: { max: { field: 'timestamp' } },
        },
      },
    },
  });

  const buckets = (res.aggregations?.tenants?.buckets || []) as any[];
  return buckets.map((b) => ({
    group: String(b.key),
    total: b.doc_count,
    critical: b.critical?.doc_count ?? 0,
    high: b.high?.doc_count ?? 0,
    medium: b.medium?.doc_count ?? 0,
    sparkline: ((b.spark?.buckets || []) as any[]).slice(-14).map((s) => s.doc_count),
    lastAlert: b.last_alert?.value ?? null,
  }));
}

/** Admin tenant deep-dive: KPIs, trend, severity, top agents/rules, recent alerts. */
export async function getTenantDetail(groupKey: string, range: TimeRange = '30d') {
  const query = boolQuery(range, groupKey);

  const agg = await search<any>(ALERTS_INDEX, {
    size: 0,
    track_total_hits: true,
    query,
    aggs: {
      ...severityAggs,
      trend: { date_histogram: { field: 'timestamp', fixed_interval: histogramInterval(range), min_doc_count: 0 } },
      top_agents: { terms: { field: 'agent.name', size: 10 } },
      top_rules: { terms: { field: 'rule.description', size: 10 } },
    },
  });

  const recent = await search<any>(ALERTS_INDEX, {
    size: 20,
    query,
    sort: [{ timestamp: { order: 'desc' } }],
    _source: [
      'timestamp', 'agent.name', 'rule.level', 'rule.description', 'rule.groups',
      'rule.mitre.tactic', 'data.srcip', 'GeoLocation.country_name',
    ],
  });

  const agents = await getAgentSummary(groupKey);
  const a = agg.aggregations || {};

  return {
    group: groupKey,
    range,
    total: agg.hits?.total?.value ?? 0,
    severity: {
      critical: a.critical?.doc_count ?? 0,
      high: a.high?.doc_count ?? 0,
      medium: a.medium?.doc_count ?? 0,
      low: a.low?.doc_count ?? 0,
      info: a.info?.doc_count ?? 0,
    },
    trend: ((a.trend?.buckets || []) as any[]).map((b) => ({ ts: b.key, count: b.doc_count })),
    topAgents: mapBuckets(a.top_agents),
    topRules: mapBuckets(a.top_rules),
    agents: agents.agents,
    activeAgents: agents.active,
    disconnectedAgents: agents.disconnected,
    totalAgents: agents.total,
    byOs: agents.byOs,
    recent: (recent.hits?.hits || []) as AlertHit[],
  };
}

// ---------------------------------------------------------------------------
// MITRE
// ---------------------------------------------------------------------------

export async function getMitre(
  session: Pick<SessionPayload, 'is_admin' | 'group'>,
  range: TimeRange = '24h',
) {
  const group = groupFromSession(session);
  const res = await search<any>(ALERTS_INDEX, {
    size: 0,
    query: boolQuery(range, group, [{ exists: { field: 'rule.mitre.id' } }]),
    aggs: {
      tactics: { terms: { field: 'rule.mitre.tactic', size: 20 } },
      techniques: { terms: { field: 'rule.mitre.technique', size: 20 } },
      technique_ids: { terms: { field: 'rule.mitre.id', size: 20 } },
    },
  });
  const a = res.aggregations || {};
  return {
    tactics: mapBuckets(a.tactics),
    techniques: mapBuckets(a.techniques),
    techniqueIds: mapBuckets(a.technique_ids),
  };
}

// ---------------------------------------------------------------------------
// Compliance (by field existence — rule.groups:"pci_dss" returns 0)
// ---------------------------------------------------------------------------

export type ComplianceFramework = 'pci_dss' | 'gdpr' | 'hipaa' | 'nist_800_53' | 'tsc' | 'gpg13';

const COMPLIANCE_FIELDS: Record<ComplianceFramework, string> = {
  pci_dss: 'rule.pci_dss',
  gdpr: 'rule.gdpr',
  hipaa: 'rule.hipaa',
  nist_800_53: 'rule.nist_800_53',
  tsc: 'rule.tsc',
  gpg13: 'rule.gpg13',
};

export async function getCompliance(
  session: Pick<SessionPayload, 'is_admin' | 'group'>,
  framework: ComplianceFramework,
  range: TimeRange = '24h',
) {
  const group = groupFromSession(session);
  const field = COMPLIANCE_FIELDS[framework];

  const res = await search<any>(ALERTS_INDEX, {
    size: 0,
    track_total_hits: true,
    query: boolQuery(range, group, [{ exists: { field } }]),
    aggs: { reqs: { terms: { field, size: 25 } } },
  });

  const alerts = await search<any>(ALERTS_INDEX, {
    size: 20,
    query: boolQuery(range, group, [{ exists: { field } }]),
    sort: [{ timestamp: { order: 'desc' } }],
    _source: ['timestamp', 'agent.name', 'rule.level', 'rule.description', field],
  });

  return {
    framework,
    total: res.hits?.total?.value ?? 0,
    requirements: mapBuckets(res.aggregations?.reqs),
    alerts: (alerts.hits?.hits || []) as AlertHit[],
  };
}

// ---------------------------------------------------------------------------
// FIM (syscheck group on alerts index — no states-fim index exists)
// ---------------------------------------------------------------------------

export async function getFim(
  session: Pick<SessionPayload, 'is_admin' | 'group'>,
  range: TimeRange = '24h',
  page = 0,
  pageSize = 50,
) {
  const group = groupFromSession(session);
  const res = await search<any>(ALERTS_INDEX, {
    size: pageSize,
    from: page * pageSize,
    track_total_hits: true,
    query: boolQuery(range, group, [{ match: { 'rule.groups': 'syscheck' } }]),
    sort: [{ timestamp: { order: 'desc' } }],
    _source: [
      'timestamp', 'agent.name', 'rule.description', 'rule.level',
      'syscheck.path', 'syscheck.event', 'syscheck.md5_after', 'syscheck.sha256_after',
      'full_log',
    ],
  });
  return { total: res.hits?.total?.value ?? 0, hits: (res.hits?.hits || []) as AlertHit[] };
}

// ---------------------------------------------------------------------------
// SCA (policy monitoring)
// ---------------------------------------------------------------------------

export async function getSca(
  session: Pick<SessionPayload, 'is_admin' | 'group'>,
  range: TimeRange = '24h',
) {
  const group = groupFromSession(session);
  const res = await search<any>(ALERTS_INDEX, {
    size: 50,
    track_total_hits: true,
    query: boolQuery(range, group, [{ match: { 'rule.groups': 'sca' } }]),
    sort: [{ timestamp: { order: 'desc' } }],
    aggs: {
      by_agent: {
        terms: { field: 'agent.name', size: 25 },
        aggs: {
          passed: { filter: { match: { 'data.sca.check.result': 'passed' } } },
          failed: { filter: { match: { 'data.sca.check.result': 'failed' } } },
        },
      },
    },
    _source: [
      'timestamp', 'agent.name', 'rule.description', 'rule.level',
      'data.sca.check.title', 'data.sca.check.result', 'data.sca.policy',
    ],
  });
  const byAgent = ((res.aggregations?.by_agent?.buckets || []) as any[]).map((b) => ({
    key: String(b.key),
    total: b.doc_count,
    passed: b.passed?.doc_count ?? 0,
    failed: b.failed?.doc_count ?? 0,
  }));
  return { total: res.hits?.total?.value ?? 0, byAgent, hits: (res.hits?.hits || []) as AlertHit[] };
}

// ---------------------------------------------------------------------------
// Vulnerability (states index — currently 0 docs; returns honest empty state)
// ---------------------------------------------------------------------------

export async function getVulnerabilities(
  session: Pick<SessionPayload, 'is_admin' | 'group'>,
) {
  const group = groupFromSession(session);
  const filter: unknown[] = [];
  if (group) filter.push({ match: { 'agent.labels.group': group } });

  try {
    const res = await search<any>(VULN_INDEX, {
      size: 50,
      track_total_hits: true,
      query: filter.length ? { bool: { filter } } : { match_all: {} },
      aggs: { by_severity: { terms: { field: 'vulnerability.severity', size: 10 } } },
      _source: ['agent.name', 'vulnerability.severity', 'vulnerability.cve', 'vulnerability.name', 'vulnerability.status'],
    });
    return {
      total: res.hits?.total?.value ?? 0,
      bySeverity: mapBuckets(res.aggregations?.by_severity),
      hits: (res.hits?.hits || []) as AlertHit[],
      indexed: true,
    };
  } catch {
    // Index may be absent/closed — treat as honest empty rather than an error.
    return { total: 0, bySeverity: [], hits: [], indexed: false };
  }
}

// ---------------------------------------------------------------------------
// Sankey (Agent Group -> Rule Group[0] -> Manager Node)
// ---------------------------------------------------------------------------

export interface SankeyData {
  nodes: { name: string }[];
  links: { source: number; target: number; value: number }[];
}

export async function getSankey(
  session: Pick<SessionPayload, 'is_admin' | 'group'>,
  range: TimeRange = '24h',
): Promise<SankeyData> {
  const group = groupFromSession(session);
  // Malware-tagged alerts -> nested terms: group -> rule.groups -> manager.name
  const res = await search<any>(ALERTS_INDEX, {
    size: 0,
    query: boolQuery(range, group, [{ match: { 'rule.groups': 'malware' } }]),
    aggs: {
      groups: {
        terms: { field: TENANT_FIELD, size: 12 },
        aggs: {
          rule_groups: {
            terms: { field: 'rule.groups', size: 8 },
            aggs: { managers: { terms: { field: 'manager.name', size: 8 } } },
          },
        },
      },
    },
  });

  const nodes: { name: string }[] = [];
  const index = new Map<string, number>();
  const links: { source: number; target: number; value: number }[] = [];
  const nodeId = (label: string, col: number) => {
    const key = `${col}:${label}`;
    if (!index.has(key)) {
      index.set(key, nodes.length);
      nodes.push({ name: label });
    }
    return index.get(key)!;
  };
  const addLink = (s: number, t: number, v: number) => {
    const existing = links.find((l) => l.source === s && l.target === t);
    if (existing) existing.value += v;
    else links.push({ source: s, target: t, value: v });
  };

  for (const g of (res.aggregations?.groups?.buckets || []) as any[]) {
    const gid = nodeId(String(g.key), 0);
    for (const rg of (g.rule_groups?.buckets || []) as any[]) {
      if (rg.key === 'malware') continue; // skip the tautological tag itself
      const rid = nodeId(String(rg.key), 1);
      addLink(gid, rid, rg.doc_count);
      for (const m of (rg.managers?.buckets || []) as any[]) {
        const mid = nodeId(String(m.key), 2);
        addLink(rid, mid, m.doc_count);
      }
    }
  }
  return { nodes, links };
}

// ---------------------------------------------------------------------------
// Geo (attack origins for the D3 world map — GeoLocation.location is geo_point)
// ---------------------------------------------------------------------------

export interface GeoPoint {
  country: string;
  city: string;
  lat: number;
  lon: number;
  count: number;
  topRule: string;
}

export async function getGeo(
  session: Pick<SessionPayload, 'is_admin' | 'group'>,
  range: TimeRange = '24h',
): Promise<{ points: GeoPoint[]; byCountry: { key: string; count: number }[] }> {
  const group = groupFromSession(session);
  const res = await search<any>(ALERTS_INDEX, {
    size: 0,
    query: boolQuery(range, group, [{ exists: { field: 'GeoLocation.location' } }]),
    aggs: {
      by_country: { terms: { field: 'GeoLocation.country_name', size: 50 } },
      grid: {
        geohash_grid: { field: 'GeoLocation.location', precision: 3, size: 300 },
        aggs: {
          centroid: { geo_centroid: { field: 'GeoLocation.location' } },
          country: { terms: { field: 'GeoLocation.country_name', size: 1 } },
          city: { terms: { field: 'GeoLocation.city_name', size: 1 } },
          top_rule: { terms: { field: 'rule.description', size: 1 } },
        },
      },
    },
  });

  const points: GeoPoint[] = ((res.aggregations?.grid?.buckets || []) as any[])
    .map((b) => {
      const c = b.centroid?.location;
      return {
        country: b.country?.buckets?.[0]?.key ?? '',
        city: b.city?.buckets?.[0]?.key ?? '',
        lat: c?.lat ?? 0,
        lon: c?.lon ?? 0,
        count: b.doc_count,
        topRule: b.top_rule?.buckets?.[0]?.key ?? '',
      };
    })
    .filter((p) => p.lat !== 0 || p.lon !== 0);

  return { points, byCountry: mapBuckets(res.aggregations?.by_country) };
}

// ---------------------------------------------------------------------------
// Security users (admin) — OpenSearch internalusers (Manager API rejects basic auth)
// ---------------------------------------------------------------------------

export interface PortalUser {
  username: string;
  type: 'ADMIN' | 'CLIENT';
  backend_roles: string[];
  roles: string[];
}

export async function getSecurityUsers(): Promise<PortalUser[]> {
  const data = await osRequest<Record<string, any>>(
    '/_plugins/_security/api/internalusers',
    undefined,
    'GET',
  );
  return Object.entries(data)
    .map(([username, info]) => {
      const backend = (info.backend_roles || []) as string[];
      const odRoles = (info.opendistro_security_roles || []) as string[];
      const isAdmin =
        backend.some((r) => r && r.trim() !== '') || odRoles.includes('all_access');
      return {
        username,
        type: (isAdmin ? 'ADMIN' : 'CLIENT') as 'ADMIN' | 'CLIENT',
        backend_roles: backend,
        roles: odRoles,
      };
    })
    .sort((a, b) => a.username.localeCompare(b.username));
}

// ---------------------------------------------------------------------------
// Health probe (used by /api/health and /settings)
// ---------------------------------------------------------------------------

export async function pingIndexer(): Promise<{ ok: boolean; detail: string }> {
  try {
    const res = await osRequest<any>('/_cluster/health', undefined, 'GET');
    return { ok: true, detail: `status=${res.status}` };
  } catch (e) {
    return { ok: false, detail: (e as Error).message };
  }
}
