import type { ChatMessage, LLMProvider } from './types';
import { anthropicProvider } from './providers/anthropic';
import { openaiProvider } from './providers/openai';
import { geminiProvider } from './providers/gemini';

/**
 * Public AI facade. Routes and the floating assistant import from here and never
 * touch a vendor SDK. To switch providers, set AI_PROVIDER (anthropic | openai |
 * gemini) and that provider's key/model env — no code change required.
 */

export type { ChatMessage } from './types';

const REGISTRY: Record<string, LLMProvider> = {
  anthropic: anthropicProvider,
  openai: openaiProvider,
  gemini: geminiProvider,
};

/** Resolve the active provider from AI_PROVIDER (defaults to anthropic). */
export function getProvider(): LLMProvider {
  const id = (process.env.AI_PROVIDER || 'anthropic').toLowerCase();
  return REGISTRY[id] || anthropicProvider;
}

export function listProviders(): { id: string; label: string; model: string; configured: boolean }[] {
  return Object.values(REGISTRY).map((p) => ({ id: p.id, label: p.label, model: p.model, configured: p.isConfigured() }));
}

/** True when the active provider has its credentials configured. */
export function aiConfigured(): boolean {
  return getProvider().isConfigured();
}

/** Active provider metadata, for /settings and health surfaces. */
export function activeProviderInfo(): { id: string; label: string; model: string } {
  const p = getProvider();
  return { id: p.id, label: p.label, model: p.model };
}

// ---------------------------------------------------------------------------
// SOC-specific prompt layer (provider-independent)
// ---------------------------------------------------------------------------

const MAX_TOKENS = 1024;

export interface AssistantContext {
  group: string | null;
  page: string;
  criticalAlerts: { title: string; level: number; agent: string }[];
}

const ASSISTANT_SYSTEM =
  'You are a SOC analyst assistant for Prime Infoserv MSSP. Answer cybersecurity questions ' +
  'concisely. Reference provided alert data when relevant. Recommend MITRE ATT&CK techniques. ' +
  'Keep responses under 150 words.';

function contextBlock(ctx: AssistantContext): string {
  const scope = ctx.group ? `Tenant scope: ${ctx.group}` : 'Scope: all tenants (admin)';
  const page = `Current page: ${ctx.page}`;
  const alerts = ctx.criticalAlerts.length
    ? 'Recent critical alerts:\n' + ctx.criticalAlerts.map((a) => `- [L${a.level}] ${a.title} (agent: ${a.agent})`).join('\n')
    : 'Recent critical alerts: none in the current window.';
  return `${scope}\n${page}\n${alerts}`;
}

/** Streaming SOC assistant — delegates to the active provider. */
export async function* streamAssistant(messages: ChatMessage[], ctx: AssistantContext): AsyncGenerator<string> {
  yield* getProvider().streamChat({
    system: `${ASSISTANT_SYSTEM}\n\n${contextBlock(ctx)}`,
    messages,
    maxTokens: MAX_TOKENS,
  });
}

const TRIAGE_SYSTEM =
  'You are a senior SOC analyst. Analyze this alert. Provide: 1) Threat classification (1 line) ' +
  '2) Severity justification (1 line) 3) Immediate actions (3 bullet points) 4) MITRE techniques ' +
  'involved. Max 150 words.';

export async function triageAlert(alert: Record<string, unknown>): Promise<string> {
  return getProvider().complete({
    system: TRIAGE_SYSTEM,
    messages: [{ role: 'user', content: 'Analyze this Wazuh alert:\n```json\n' + JSON.stringify(alert, null, 2) + '\n```' }],
    maxTokens: MAX_TOKENS,
  });
}

const BRIEF_SYSTEM =
  'Summarize these 24h security events for a CISO. Mention top threats, most active agents, ' +
  'trending attack techniques. 3 sentences max.';

export interface BriefInput {
  total: number;
  critical: number;
  high: number;
  topAgents: { key: string; count: number }[];
  topTactics: { key: string; count: number }[];
}

export async function generateBrief(input: BriefInput): Promise<string> {
  const summary =
    `Total alerts (24h): ${input.total}; critical: ${input.critical}; high: ${input.high}.\n` +
    `Most active agents: ${input.topAgents.slice(0, 5).map((a) => `${a.key} (${a.count})`).join(', ') || 'n/a'}.\n` +
    `Trending MITRE tactics: ${input.topTactics.slice(0, 5).map((t) => `${t.key} (${t.count})`).join(', ') || 'n/a'}.`;
  return getProvider().complete({
    system: BRIEF_SYSTEM,
    messages: [{ role: 'user', content: summary }],
    maxTokens: 400,
  });
}
