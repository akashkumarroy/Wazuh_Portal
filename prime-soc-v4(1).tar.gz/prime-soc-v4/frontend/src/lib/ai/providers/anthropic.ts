import Anthropic from '@anthropic-ai/sdk';
import type { LLMProvider, ChatRequest } from '../types';

/**
 * Anthropic / Claude adapter (official SDK).
 * Model defaults to the spec's claude-sonnet-4-20250514 and is overridable via
 * ANTHROPIC_MODEL (or the legacy AI_MODEL).
 */

const DEFAULT_MODEL = 'claude-sonnet-4-20250514';

function modelId(): string {
  return process.env.ANTHROPIC_MODEL || process.env.AI_MODEL || DEFAULT_MODEL;
}

let client: Anthropic | null = null;
function getClient(): Anthropic {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) throw new Error('ANTHROPIC_API_KEY is not configured');
  if (!client) client = new Anthropic({ apiKey });
  return client;
}

export const anthropicProvider: LLMProvider = {
  id: 'anthropic',
  label: 'Anthropic Claude',
  get model() { return modelId(); },

  isConfigured() {
    const k = process.env.ANTHROPIC_API_KEY;
    return !!k && !k.startsWith('FILL_IN');
  },

  async *streamChat(req: ChatRequest): AsyncGenerator<string> {
    const stream = getClient().messages.stream({
      model: modelId(),
      max_tokens: req.maxTokens ?? 1024,
      system: req.system,
      messages: req.messages.map((m) => ({ role: m.role, content: m.content })),
    });
    for await (const event of stream) {
      if (event.type === 'content_block_delta' && event.delta.type === 'text_delta') {
        yield event.delta.text;
      }
    }
  },

  async complete(req: ChatRequest): Promise<string> {
    const res = await getClient().messages.create({
      model: modelId(),
      max_tokens: req.maxTokens ?? 1024,
      system: req.system,
      messages: req.messages.map((m) => ({ role: m.role, content: m.content })),
    });
    return res.content
      .filter((b) => b.type === 'text')
      .map((b) => (b as { text: string }).text)
      .join('\n');
  },
};
