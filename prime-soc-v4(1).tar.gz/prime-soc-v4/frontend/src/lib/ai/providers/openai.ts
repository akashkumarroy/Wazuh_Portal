import type { LLMProvider, ChatRequest } from '../types';
import { readSse, withTimeout } from '../sse';

/**
 * OpenAI (ChatGPT) adapter — raw fetch, no SDK dependency.
 *
 * Because it speaks the standard /chat/completions contract, the same adapter
 * works with ANY OpenAI-compatible endpoint by setting OPENAI_BASE_URL:
 * Azure OpenAI gateways, OpenRouter, LiteLLM, or a local vLLM / Ollama server.
 * That makes provider scaling a pure config exercise.
 *
 * Env: OPENAI_API_KEY, OPENAI_MODEL (default gpt-4o), OPENAI_BASE_URL
 *      (default https://api.openai.com/v1).
 */

const DEFAULT_MODEL = 'gpt-4o';

function base(): string {
  return (process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');
}
function modelId(): string {
  return process.env.OPENAI_MODEL || DEFAULT_MODEL;
}
function headers(): HeadersInit {
  return {
    Authorization: `Bearer ${process.env.OPENAI_API_KEY || ''}`,
    'Content-Type': 'application/json',
  };
}
function buildMessages(req: ChatRequest) {
  return [{ role: 'system', content: req.system }, ...req.messages.map((m) => ({ role: m.role, content: m.content }))];
}

export const openaiProvider: LLMProvider = {
  id: 'openai',
  label: 'OpenAI',
  get model() { return modelId(); },

  isConfigured() {
    const k = process.env.OPENAI_API_KEY;
    return !!k && !k.startsWith('FILL_IN');
  },

  async *streamChat(req: ChatRequest): AsyncGenerator<string> {
    const res = await fetch(`${base()}/chat/completions`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({
        model: modelId(),
        max_tokens: req.maxTokens ?? 1024,
        stream: true,
        messages: buildMessages(req),
      }),
      cache: 'no-store',
    });
    if (!res.ok) {
      const txt = await res.text().catch(() => '');
      throw new Error(`OpenAI HTTP ${res.status}${txt ? `: ${txt.slice(0, 200)}` : ''}`);
    }
    for await (const obj of readSse(res)) {
      const delta = obj?.choices?.[0]?.delta?.content;
      if (delta) yield delta as string;
    }
  },

  async complete(req: ChatRequest): Promise<string> {
    const { signal, clear } = withTimeout(30_000);
    try {
      const res = await fetch(`${base()}/chat/completions`, {
        method: 'POST',
        headers: headers(),
        body: JSON.stringify({
          model: modelId(),
          max_tokens: req.maxTokens ?? 1024,
          messages: buildMessages(req),
        }),
        signal,
        cache: 'no-store',
      });
      if (!res.ok) {
        const txt = await res.text().catch(() => '');
        throw new Error(`OpenAI HTTP ${res.status}${txt ? `: ${txt.slice(0, 200)}` : ''}`);
      }
      const data = await res.json();
      return data?.choices?.[0]?.message?.content ?? '';
    } finally {
      clear();
    }
  },
};
