import type { LLMProvider, ChatRequest } from '../types';
import { readSse, withTimeout } from '../sse';

/**
 * Google Gemini adapter — raw fetch, no SDK dependency.
 *
 * Gemini differs from the OpenAI/Anthropic shape in two ways we normalize here:
 *  - the assistant role is called "model" (we map assistant -> model);
 *  - the system prompt is passed as `systemInstruction`, not a message.
 *
 * Env: GEMINI_API_KEY, GEMINI_MODEL (default gemini-1.5-pro), GEMINI_BASE_URL
 *      (default https://generativelanguage.googleapis.com/v1beta).
 */

const DEFAULT_MODEL = 'gemini-1.5-pro';

function base(): string {
  return (process.env.GEMINI_BASE_URL || 'https://generativelanguage.googleapis.com/v1beta').replace(/\/$/, '');
}
function modelId(): string {
  return process.env.GEMINI_MODEL || DEFAULT_MODEL;
}
function apiKey(): string {
  return process.env.GEMINI_API_KEY || '';
}
function buildBody(req: ChatRequest) {
  return {
    systemInstruction: { parts: [{ text: req.system }] },
    contents: req.messages.map((m) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    })),
    generationConfig: { maxOutputTokens: req.maxTokens ?? 1024 },
  };
}
function extractText(data: any): string {
  const parts = data?.candidates?.[0]?.content?.parts;
  if (!Array.isArray(parts)) return '';
  return parts.map((p: any) => p?.text ?? '').join('');
}

export const geminiProvider: LLMProvider = {
  id: 'gemini',
  label: 'Google Gemini',
  get model() { return modelId(); },

  isConfigured() {
    const k = process.env.GEMINI_API_KEY;
    return !!k && !k.startsWith('FILL_IN');
  },

  async *streamChat(req: ChatRequest): AsyncGenerator<string> {
    const url = `${base()}/models/${modelId()}:streamGenerateContent?alt=sse&key=${apiKey()}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(buildBody(req)),
      cache: 'no-store',
    });
    if (!res.ok) {
      const txt = await res.text().catch(() => '');
      throw new Error(`Gemini HTTP ${res.status}${txt ? `: ${txt.slice(0, 200)}` : ''}`);
    }
    for await (const obj of readSse(res)) {
      const text = extractText(obj);
      if (text) yield text;
    }
  },

  async complete(req: ChatRequest): Promise<string> {
    const { signal, clear } = withTimeout(30_000);
    try {
      const url = `${base()}/models/${modelId()}:generateContent?key=${apiKey()}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(buildBody(req)),
        signal,
        cache: 'no-store',
      });
      if (!res.ok) {
        const txt = await res.text().catch(() => '');
        throw new Error(`Gemini HTTP ${res.status}${txt ? `: ${txt.slice(0, 200)}` : ''}`);
      }
      const data = await res.json();
      return extractText(data);
    } finally {
      clear();
    }
  },
};
