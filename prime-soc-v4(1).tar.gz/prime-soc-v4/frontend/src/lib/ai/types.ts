/**
 * Provider-agnostic LLM contract.
 *
 * Every concrete provider (Anthropic, OpenAI, Gemini, or any OpenAI-compatible
 * gateway such as LiteLLM / OpenRouter / a local vLLM or Ollama server)
 * implements this single interface. The rest of the app (routes, the floating
 * assistant, triage, briefs) talks ONLY to this interface — never to a vendor
 * SDK directly — so swapping providers is a config change, not a code change.
 */

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface ChatRequest {
  system: string;
  messages: ChatMessage[];
  maxTokens?: number;
}

export interface LLMProvider {
  /** Stable identifier, e.g. 'anthropic' | 'openai' | 'gemini'. */
  readonly id: string;
  /** Human-readable name for status/health surfaces. */
  readonly label: string;
  /** The model id this provider is currently configured to use. */
  readonly model: string;
  /** True when an API key (and anything else required) is present. */
  isConfigured(): boolean;
  /** Stream assistant text deltas (for SSE typing effect). */
  streamChat(req: ChatRequest): AsyncGenerator<string>;
  /** One-shot completion (triage, daily brief). Returns the full text. */
  complete(req: ChatRequest): Promise<string>;
}
