import { Pool, type QueryResultRow } from 'pg';

/**
 * PostgreSQL access via raw `pg` (no Prisma — Rule 7). A single pooled
 * connection is reused across hot reloads in dev. The query helper uses an
 * EXPLICIT signature (sql: string, params?: unknown[]) per Rule 12 — never
 * (...args: any[]).
 */

declare global {
  // eslint-disable-next-line no-var
  var __primePgPool: Pool | undefined;
}

function createPool(): Pool {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) throw new Error('DATABASE_URL is not set');
  return new Pool({
    connectionString,
    max: 10,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 5_000,
  });
}

/**
 * Lazily resolve the pool. Constructing it at module load would require
 * DATABASE_URL during `next build` (page-data collection evaluates route
 * modules), so we defer creation until the first actual query at runtime.
 */
function getPool(): Pool {
  if (!global.__primePgPool) {
    global.__primePgPool = createPool();
  }
  return global.__primePgPool;
}

/** Run a parameterized query. Explicit signature (Rule 12). */
export async function query<T extends QueryResultRow = QueryResultRow>(
  sql: string,
  params?: unknown[],
): Promise<{ rows: T[]; rowCount: number }> {
  const res = await getPool().query<T>(sql, params as any[] | undefined);
  return { rows: res.rows, rowCount: res.rowCount ?? 0 };
}

// ---------------------------------------------------------------------------
// Sessions
// ---------------------------------------------------------------------------

export interface SessionRow extends QueryResultRow {
  id: string;
  username: string;
  role: string;
  is_admin: boolean;
  grp: string | null;
  ip_address: string | null;
  created_at: string;
  expires_at: string;
  revoked: boolean;
}

export async function recordSession(input: {
  username: string;
  role: string;
  isAdmin: boolean;
  group: string | null;
  ip: string | null;
  expiresAt: Date;
}): Promise<string> {
  const { rows } = await query<{ id: string }>(
    `INSERT INTO sessions (username, role, is_admin, grp, ip_address, expires_at)
     VALUES ($1, $2, $3, $4, $5, $6) RETURNING id`,
    [input.username, input.role, input.isAdmin, input.group, input.ip, input.expiresAt.toISOString()],
  );
  return rows[0].id;
}

export async function revokeSession(id: string): Promise<void> {
  await query(`UPDATE sessions SET revoked = TRUE WHERE id = $1`, [id]);
}

// ---------------------------------------------------------------------------
// Audit log
// ---------------------------------------------------------------------------

export async function audit(input: {
  username: string;
  action: string;
  resource?: string | null;
  details?: unknown;
  ip?: string | null;
}): Promise<void> {
  try {
    await query(
      `INSERT INTO audit_log (username, action, resource, details, ip_address)
       VALUES ($1, $2, $3, $4, $5)`,
      [
        input.username,
        input.action,
        input.resource ?? null,
        input.details != null ? JSON.stringify(input.details) : null,
        input.ip ?? null,
      ],
    );
  } catch {
    // Auditing must never break a request path.
  }
}

// ---------------------------------------------------------------------------
// Watchlist
// ---------------------------------------------------------------------------

export interface WatchlistRow extends QueryResultRow {
  id: string;
  added_by: string;
  type: string;
  value: string;
  label: string | null;
  tenant: string | null;
  created_at: string;
}

export async function listWatchlist(): Promise<WatchlistRow[]> {
  const { rows } = await query<WatchlistRow>(
    `SELECT * FROM watchlist ORDER BY created_at DESC`,
  );
  return rows;
}

export async function addWatchlist(input: {
  addedBy: string;
  type: string;
  value: string;
  label?: string | null;
  tenant?: string | null;
}): Promise<WatchlistRow> {
  const { rows } = await query<WatchlistRow>(
    `INSERT INTO watchlist (added_by, type, value, label, tenant)
     VALUES ($1, $2, $3, $4, $5) RETURNING *`,
    [input.addedBy, input.type, input.value, input.label ?? null, input.tenant ?? null],
  );
  return rows[0];
}

export async function removeWatchlist(id: string): Promise<void> {
  await query(`DELETE FROM watchlist WHERE id = $1`, [id]);
}

// ---------------------------------------------------------------------------
// Saved searches
// ---------------------------------------------------------------------------

export interface SavedSearchRow extends QueryResultRow {
  id: string;
  username: string;
  name: string;
  filters: Record<string, unknown>;
  created_at: string;
}

export async function listSavedSearches(username: string): Promise<SavedSearchRow[]> {
  const { rows } = await query<SavedSearchRow>(
    `SELECT * FROM saved_searches WHERE username = $1 ORDER BY created_at DESC`,
    [username],
  );
  return rows;
}

export async function addSavedSearch(input: {
  username: string;
  name: string;
  filters: Record<string, unknown>;
}): Promise<SavedSearchRow> {
  const { rows } = await query<SavedSearchRow>(
    `INSERT INTO saved_searches (username, name, filters)
     VALUES ($1, $2, $3) RETURNING *`,
    [input.username, input.name, JSON.stringify(input.filters)],
  );
  return rows[0];
}

export async function removeSavedSearch(id: string, username: string): Promise<void> {
  await query(`DELETE FROM saved_searches WHERE id = $1 AND username = $2`, [id, username]);
}

// ---------------------------------------------------------------------------
// Incidents (alert correlation -> IRIS promotion, Phase 4)
// ---------------------------------------------------------------------------

export interface IncidentRow extends QueryResultRow {
  id: string;
  tenant: string | null;
  title: string;
  severity: string;
  alert_ids: string[];
  iris_case_id: string | null;
  status: string;
  created_at: string;
  updated_at: string;
}

export async function createIncident(input: {
  tenant: string | null;
  title: string;
  severity: string;
  alertIds: string[];
}): Promise<IncidentRow> {
  const { rows } = await query<IncidentRow>(
    `INSERT INTO incidents (tenant, title, severity, alert_ids)
     VALUES ($1, $2, $3, $4) RETURNING *`,
    [input.tenant, input.title, input.severity, input.alertIds],
  );
  return rows[0];
}

export async function attachIrisCase(incidentId: string, caseId: string): Promise<void> {
  await query(
    `UPDATE incidents SET iris_case_id = $2, updated_at = NOW() WHERE id = $1`,
    [incidentId, caseId],
  );
}

/** Lightweight DB health check for /api/health and /settings. */
export async function pingDb(): Promise<{ ok: boolean; detail: string }> {
  try {
    await query('SELECT 1');
    return { ok: true, detail: 'connected' };
  } catch (e) {
    return { ok: false, detail: (e as Error).message };
  }
}
