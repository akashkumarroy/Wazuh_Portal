// Client-safe pure helpers. Deliberately NOT imported from lib/wazuh.ts, which
// transitively pulls next/headers (server-only) and would break client bundles.

export interface AlertHit {
  _id: string;
  _index: string;
  _source: Record<string, any>;
}

export type Severity = 'critical' | 'high' | 'medium' | 'low' | 'info';

export const SEVERITY_COLORS: Record<Severity, string> = {
  critical: '#ef4444',
  high: '#f59e0b',
  medium: '#eab308',
  low: '#3b82f6',
  info: '#475569',
};

export function severityFromLevel(level: number | undefined | null): Severity {
  const l = typeof level === 'number' ? level : 0;
  if (l >= 13) return 'critical';
  if (l >= 10) return 'high';
  if (l >= 7) return 'medium';
  if (l >= 4) return 'low';
  return 'info';
}

export function severityBadgeClass(sev: Severity): string {
  return `badge badge-${sev}`;
}

export function formatNumber(n: number | null | undefined): string {
  if (n == null || Number.isNaN(n)) return '—';
  return n.toLocaleString('en-US');
}

export function formatTs(input: string | number | null | undefined): string {
  if (input == null || input === '') return '—';
  const d = new Date(input);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toISOString().replace('T', ' ').replace(/\.\d+Z$/, 'Z');
}

export function timeAgo(input: string | number | null | undefined): string {
  if (input == null || input === '') return '—';
  const d = new Date(input);
  if (Number.isNaN(d.getTime())) return '—';
  const diff = Date.now() - d.getTime();
  const s = Math.floor(diff / 1000);
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const days = Math.floor(h / 24);
  return `${days}d ago`;
}

/** Axis tick formatter for date_histogram epoch-ms keys, scaled to the range. */
export function axisTimeFormatter(range: string): (ms: number) => string {
  const longRange = range === '7d' || range === '30d';
  return (ms: number) => {
    const d = new Date(ms);
    if (Number.isNaN(d.getTime())) return '';
    if (longRange) {
      return `${String(d.getUTCMonth() + 1).padStart(2, '0')}/${String(d.getUTCDate()).padStart(2, '0')}`;
    }
    return `${String(d.getUTCHours()).padStart(2, '0')}:${String(d.getUTCMinutes()).padStart(2, '0')}`;
  };
}

/** Safely read a dotted path from an object. */
export function get(obj: any, path: string): any {
  return path.split('.').reduce((acc, key) => (acc == null ? acc : acc[key]), obj);
}

/** Normalize rule.groups (string | string[]) to an array. */
export function asArray<T = any>(v: T | T[] | undefined | null): T[] {
  if (v == null) return [];
  return Array.isArray(v) ? v : [v];
}
