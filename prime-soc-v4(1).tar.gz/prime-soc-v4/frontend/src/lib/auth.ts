import { SignJWT, jwtVerify, type JWTPayload } from 'jose';
import { cookies } from 'next/headers';

/**
 * Authentication is 100% delegated to the Wazuh Indexer (OpenSearch Security).
 * There is NO separate user database. We validate credentials by calling the
 * Security account API with HTTP Basic auth, then issue our own JWT cookie.
 *
 * Role model (confirmed against live indexer):
 *   admin   account -> backend_roles: ["admin"], roles: ["own_index","all_access"]
 *   Ploutos account -> backend_roles: [""],      roles: ["own_index","Ploutos"]
 *
 * is_admin  = backend_roles has a non-blank entry OR roles includes "all_access"
 * group     = the role that is not own_index / all_access (falls back to username)
 */

export const SESSION_COOKIE = 'prime_soc_session';
const SESSION_HOURS = 8;

export interface SessionPayload extends JWTPayload {
  sub: string;        // username
  role: 'admin' | 'client';
  is_admin: boolean;
  group: string | null; // tenant DLS key for clients; null for admins (see all)
}

export interface WazuhAccount {
  user_name: string;
  backend_roles: string[];
  roles: string[];
  tenants?: Record<string, boolean>;
}

function jwtSecret(): Uint8Array {
  const secret = process.env.JWT_SECRET;
  if (!secret || secret.length < 16) {
    throw new Error('JWT_SECRET is not set or too short (set a 64-char random value in .env)');
  }
  return new TextEncoder().encode(secret);
}

function indexerBase(): string {
  const url = process.env.WAZUH_INDEXER_URL;
  if (!url) throw new Error('WAZUH_INDEXER_URL is not set');
  return url.replace(/\/$/, '');
}

const RESERVED_ROLES = new Set(['own_index', 'all_access', 'kibana_user', 'readall']);

/** True when the account has any meaningful (non-blank) backend role, or all_access. */
export function isAdminAccount(account: WazuhAccount): boolean {
  const hasBackendRole = (account.backend_roles || []).some((r) => typeof r === 'string' && r.trim() !== '');
  const hasAllAccess = (account.roles || []).includes('all_access');
  return hasBackendRole || hasAllAccess;
}

/** Resolve a client's tenant DLS key from their roles, falling back to username. */
export function resolveGroup(account: WazuhAccount): string {
  const candidate = (account.roles || []).find((r) => r && !RESERVED_ROLES.has(r));
  return candidate || account.user_name;
}

/**
 * Validate username/password directly against the Wazuh Indexer Security API.
 * Returns the parsed account on HTTP 200, or null on 401/invalid.
 * Throws only on unexpected transport errors (so the route can 500 distinctly).
 */
export async function validateWazuhCredentials(
  username: string,
  password: string,
): Promise<WazuhAccount | null> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15_000); // Rule 6: 15s indexer timeout
  try {
    const basic = Buffer.from(`${username}:${password}`).toString('base64');
    const res = await fetch(`${indexerBase()}/_plugins/_security/api/account`, {
      method: 'GET',
      headers: { Authorization: `Basic ${basic}`, Accept: 'application/json' },
      signal: controller.signal,
      cache: 'no-store',
    });

    if (res.status === 401 || res.status === 403) return null;
    if (!res.ok) return null;

    const data = (await res.json()) as WazuhAccount;
    if (!data || !data.user_name) return null;
    return data;
  } catch (err) {
    if ((err as Error)?.name === 'AbortError') {
      throw new Error('Wazuh Indexer timed out during authentication');
    }
    throw err;
  } finally {
    clearTimeout(timeout);
  }
}

/** Build the session payload from a validated Wazuh account. */
export function buildSession(account: WazuhAccount): SessionPayload {
  const admin = isAdminAccount(account);
  return {
    sub: account.user_name,
    role: admin ? 'admin' : 'client',
    is_admin: admin,
    group: admin ? null : resolveGroup(account),
  };
}

/** Sign an 8-hour JWT for the given session payload. */
export async function signSession(payload: SessionPayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: 'HS256' })
    .setSubject(payload.sub)
    .setIssuedAt()
    .setExpirationTime(`${SESSION_HOURS}h`)
    .sign(jwtSecret());
}

/** Verify a JWT string and return the session payload, or null when invalid/expired. */
export async function verifySession(token: string | undefined | null): Promise<SessionPayload | null> {
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, jwtSecret());
    if (typeof payload.sub !== 'string' || typeof payload.is_admin !== 'boolean') return null;
    return payload as SessionPayload;
  } catch {
    return null;
  }
}

/** Read + verify the session from the request cookie (server components / route handlers). */
export async function getSession(): Promise<SessionPayload | null> {
  const token = cookies().get(SESSION_COOKIE)?.value;
  return verifySession(token);
}

export function sessionCookieMaxAge(): number {
  return SESSION_HOURS * 60 * 60;
}
