/**
 * SOAR layer — IRIS (case management) + Shuffle (local SOAR instance).
 *
 * Confirmed against live infra:
 *  - IRIS is UNREACHABLE from the portal server (WireGuard routing). It MUST fail gracefully
 *    in under 8s and return empty — never hang, never throw to the route. Show "0 cases".
 *  - Shuffle is the LOCAL instance (http://10.10.5.71:3001), NOT shuffler.io. It returns
 *    {success:false} when there are no workflows; we coerce that to [].
 *  - 8s AbortController on every call (Rule 6).
 */

const SOAR_TIMEOUT_MS = 8_000;

async function timedFetch(url: string, init: RequestInit, timeoutMs = SOAR_TIMEOUT_MS): Promise<Response> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal, cache: 'no-store' });
  } finally {
    clearTimeout(timeout);
  }
}

// ---------------------------------------------------------------------------
// IRIS — every export returns a safe empty shape on failure/timeout
// ---------------------------------------------------------------------------

function irisBase(): string {
  const url = process.env.IRIS_URL;
  if (!url) throw new Error('IRIS_URL is not set');
  return url.replace(/\/$/, '');
}

function irisHeaders(): HeadersInit {
  return {
    Authorization: `Bearer ${process.env.IRIS_API_KEY || ''}`,
    Accept: 'application/json',
    'Content-Type': 'application/json',
  };
}

export interface IrisCase {
  id: string;
  name: string;
  severity: string;
  state: string;
  open: boolean;
  openDate: string;
  owner: string;
}

export interface IrisResult {
  reachable: boolean;
  cases: IrisCase[];
  stats: {
    total: number;
    open: number;
    closed: number;
    bySeverity: { key: string; count: number }[];
    byState: { key: string; count: number }[];
  };
  detail: string;
}

function emptyIris(detail: string): IrisResult {
  return {
    reachable: false,
    cases: [],
    stats: { total: 0, open: 0, closed: 0, bySeverity: [], byState: [] },
    detail,
  };
}

export async function getIrisCases(): Promise<IrisResult> {
  try {
    const res = await timedFetch(`${irisBase()}/manage/cases/list`, {
      method: 'GET',
      headers: irisHeaders(),
    });
    if (!res.ok) return emptyIris(`IRIS HTTP ${res.status}`);
    const data = await res.json();
    const raw = (data?.data?.cases || data?.data || []) as any[];
    if (!Array.isArray(raw)) return emptyIris('IRIS returned unexpected shape');

    const cases: IrisCase[] = raw.map((c) => ({
      id: String(c.case_id ?? c.id ?? ''),
      name: c.case_name ?? c.name ?? '',
      severity: String(c.severity_id ?? c.severity ?? 'unknown'),
      state: String(c.state_name ?? c.state ?? 'unknown'),
      open: c.case_open === true || c.close_date == null,
      openDate: c.open_date ?? c.case_open_date ?? '',
      owner: c.owner ?? c.user ?? '',
    }));

    const sevMap = new Map<string, number>();
    const stateMap = new Map<string, number>();
    let open = 0;
    for (const c of cases) {
      sevMap.set(c.severity, (sevMap.get(c.severity) || 0) + 1);
      stateMap.set(c.state, (stateMap.get(c.state) || 0) + 1);
      if (c.open) open++;
    }
    const toArr = (m: Map<string, number>) =>
      Array.from(m.entries()).map(([key, count]) => ({ key, count })).sort((a, b) => b.count - a.count);

    return {
      reachable: true,
      cases,
      stats: {
        total: cases.length,
        open,
        closed: cases.length - open,
        bySeverity: toArr(sevMap),
        byState: toArr(stateMap),
      },
      detail: `IRIS OK, ${cases.length} cases`,
    };
  } catch (e) {
    const msg = (e as Error)?.name === 'AbortError' ? 'IRIS timeout (8s)' : (e as Error).message;
    return emptyIris(msg);
  }
}

export interface IrisCreateResult {
  ok: boolean;
  caseId: string | null;
  detail: string;
}

/** One-click case creation (Phase 4). Fails gracefully when IRIS is unreachable. */
export async function createIrisCase(input: {
  name: string;
  severity: number;
  description: string;
}): Promise<IrisCreateResult> {
  try {
    const res = await timedFetch(`${irisBase()}/manage/cases/add`, {
      method: 'POST',
      headers: irisHeaders(),
      body: JSON.stringify({
        case_name: input.name,
        case_description: input.description,
        case_customer: 1,
        case_classification: 1,
        severity_id: Math.max(1, Math.min(6, Math.round(input.severity / 2))),
      }),
    });
    if (!res.ok) return { ok: false, caseId: null, detail: `IRIS HTTP ${res.status}` };
    const data = await res.json();
    const id = data?.data?.case_id ?? data?.data?.id ?? null;
    return { ok: id != null, caseId: id != null ? String(id) : null, detail: id != null ? 'created' : 'no id returned' };
  } catch (e) {
    const msg = (e as Error)?.name === 'AbortError' ? 'IRIS unavailable — case not created' : (e as Error).message;
    return { ok: false, caseId: null, detail: msg };
  }
}

export async function pingIris(): Promise<{ ok: boolean; detail: string }> {
  const r = await getIrisCases();
  return { ok: r.reachable, detail: r.detail };
}

// ---------------------------------------------------------------------------
// Shuffle (local instance; {success:false} => [])
// ---------------------------------------------------------------------------

function shuffleBase(): string {
  const url = process.env.SHUFFLE_URL;
  if (!url) throw new Error('SHUFFLE_URL is not set');
  return url.replace(/\/$/, '');
}

export interface ShuffleWorkflow {
  id: string;
  name: string;
  description: string;
  isValid: boolean;
  actionCount: number;
  triggerCount: number;
}

export interface ShuffleResult {
  reachable: boolean;
  workflows: ShuffleWorkflow[];
  detail: string;
}

export async function getShuffleWorkflows(): Promise<ShuffleResult> {
  try {
    const res = await timedFetch(`${shuffleBase()}/api/v1/workflows`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${process.env.SHUFFLE_API_KEY || ''}`,
        Accept: 'application/json',
      },
    });
    if (!res.ok) return { reachable: false, workflows: [], detail: `Shuffle HTTP ${res.status}` };
    const data = await res.json();

    // No workflows -> {success:false}. Coerce to empty, still "reachable".
    if (!Array.isArray(data)) {
      return { reachable: true, workflows: [], detail: 'Shuffle reachable, no workflows' };
    }
    const workflows: ShuffleWorkflow[] = data.map((w: any) => ({
      id: String(w.id ?? ''),
      name: w.name ?? '(unnamed workflow)',
      description: w.description ?? '',
      isValid: w.is_valid === true,
      actionCount: Array.isArray(w.actions) ? w.actions.length : 0,
      triggerCount: Array.isArray(w.triggers) ? w.triggers.length : 0,
    }));
    return { reachable: true, workflows, detail: `Shuffle OK, ${workflows.length} workflows` };
  } catch (e) {
    const msg = (e as Error)?.name === 'AbortError' ? 'Shuffle timeout (8s)' : (e as Error).message;
    return { reachable: false, workflows: [], detail: msg };
  }
}

export async function pingShuffle(): Promise<{ ok: boolean; detail: string }> {
  const r = await getShuffleWorkflows();
  return { ok: r.reachable, detail: r.detail };
}
