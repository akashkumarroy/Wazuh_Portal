/**
 * Threat Intelligence layer — MISP (REST) + OpenCTI (GraphQL).
 *
 * Confirmed against live instances:
 *  - MISP works; restSearch returns response[].Event{info,date,threat_level_id,Orgc.name,Tag[],...}.
 *    Some feed events carry ~2000 attributes, so we request metadata:true (events WITHOUT the
 *    giant attribute arrays) and use attribute_count when present. 8s timeout (Rule 6).
 *  - MISP threat_level_id scale: 1=High, 2=Medium, 3=Low, 4=Undefined (NOT Wazuh's scale).
 *  - OpenCTI has NO totalCount on connections; pageInfo.globalCount WORKS and gives true totals.
 *    Live counts: indicators 980717, malwares 862, reports 186, attackPatterns 1548, threatActors 0.
 *    Threat Actors are genuinely 0 -> honest empty state, never fabricated.
 */

const INTEL_TIMEOUT_MS = 8_000; // Rule 6: 8s for MISP / OpenCTI / IRIS / Shuffle

async function timedFetch(url: string, init: RequestInit): Promise<Response> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), INTEL_TIMEOUT_MS);
  try {
    return await fetch(url, { ...init, signal: controller.signal, cache: 'no-store' });
  } finally {
    clearTimeout(timeout);
  }
}

// ---------------------------------------------------------------------------
// MISP
// ---------------------------------------------------------------------------

function mispBase(): string {
  const url = process.env.MISP_URL;
  if (!url) throw new Error('MISP_URL is not set');
  return url.replace(/\/$/, '');
}

export type MispThreatLevel = 'High' | 'Medium' | 'Low' | 'Undefined';

export function mispLevel(id: string | number | undefined): MispThreatLevel {
  switch (String(id)) {
    case '1': return 'High';
    case '2': return 'Medium';
    case '3': return 'Low';
    default: return 'Undefined';
  }
}

export interface MispEvent {
  id: string;
  info: string;
  date: string;
  threatLevel: MispThreatLevel;
  org: string;
  tags: string[];
  iocCount: number;
}

/**
 * Fetch MISP events (metadata-only to stay fast). Returns [] on any failure so
 * the Threat Intel page degrades gracefully rather than hanging or 500-ing.
 */
export async function getMispEvents(limit = 20): Promise<MispEvent[]> {
  try {
    const res = await timedFetch(`${mispBase()}/events/restSearch`, {
      method: 'POST',
      headers: {
        Authorization: process.env.MISP_API_KEY || '',
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ limit, returnFormat: 'json', metadata: true }),
    });
    if (!res.ok) return [];
    const data = await res.json();
    const events = (data?.response || []) as any[];
    return events.map((e) => {
      const ev = e.Event || {};
      const attrCount =
        typeof ev.attribute_count === 'string'
          ? parseInt(ev.attribute_count, 10)
          : Array.isArray(ev.Attribute)
            ? ev.Attribute.length
            : 0;
      return {
        id: String(ev.id ?? ''),
        info: ev.info ?? '(untitled event)',
        date: ev.date ?? '',
        threatLevel: mispLevel(ev.threat_level_id),
        org: ev.Orgc?.name ?? ev.Org?.name ?? '',
        tags: Array.isArray(ev.Tag) ? ev.Tag.map((t: any) => t.name).filter(Boolean) : [],
        iocCount: Number.isFinite(attrCount) ? attrCount : 0,
      } as MispEvent;
    });
  } catch {
    return [];
  }
}

export interface MispSummary {
  total: number;
  events: MispEvent[];
  byLevel: Record<MispThreatLevel, number>;
  byOrg: { key: string; count: number }[];
}

export async function getMispSummary(limit = 30): Promise<MispSummary> {
  const events = await getMispEvents(limit);
  const byLevel: Record<MispThreatLevel, number> = { High: 0, Medium: 0, Low: 0, Undefined: 0 };
  const orgMap = new Map<string, number>();
  for (const ev of events) {
    byLevel[ev.threatLevel]++;
    if (ev.org) orgMap.set(ev.org, (orgMap.get(ev.org) || 0) + 1);
  }
  return {
    total: events.length,
    events,
    byLevel,
    byOrg: Array.from(orgMap.entries())
      .map(([key, count]) => ({ key, count }))
      .sort((a, b) => b.count - a.count),
  };
}

/** Look up a single IP/value in MISP (used by IOC auto-enrichment, Phase 4). */
export async function mispLookup(value: string): Promise<{ found: boolean; count: number }> {
  try {
    const res = await timedFetch(`${mispBase()}/attributes/restSearch`, {
      method: 'POST',
      headers: {
        Authorization: process.env.MISP_API_KEY || '',
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ value, limit: 5, returnFormat: 'json' }),
    });
    if (!res.ok) return { found: false, count: 0 };
    const data = await res.json();
    const attrs = (data?.response?.Attribute || []) as any[];
    return { found: attrs.length > 0, count: attrs.length };
  } catch {
    return { found: false, count: 0 };
  }
}

// ---------------------------------------------------------------------------
// OpenCTI (GraphQL)
// ---------------------------------------------------------------------------

function octiBase(): string {
  const url = process.env.OPENCTI_URL;
  if (!url) throw new Error('OPENCTI_URL is not set');
  return url.replace(/\/$/, '');
}

async function octiQuery<T = any>(query: string, variables?: Record<string, unknown>): Promise<T | null> {
  try {
    const res = await timedFetch(`${octiBase()}/graphql`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.OPENCTI_API_KEY || ''}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ query, variables }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (data?.errors) return (data.data ?? null) as T | null; // partial data still usable
    return (data?.data ?? null) as T | null;
  } catch {
    return null;
  }
}

export interface CtiCounts {
  indicators: number;
  malwares: number;
  reports: number;
  attackPatterns: number;
  threatActors: number;
}

/** True totals via pageInfo.globalCount (confirmed working on this OpenCTI build). */
export async function getCtiCounts(): Promise<CtiCounts> {
  const data = await octiQuery<any>(`{
    indicators { pageInfo { globalCount } }
    malwares { pageInfo { globalCount } }
    reports { pageInfo { globalCount } }
    attackPatterns { pageInfo { globalCount } }
    threatActors { pageInfo { globalCount } }
  }`);
  const g = (k: string) => data?.[k]?.pageInfo?.globalCount ?? 0;
  return {
    indicators: g('indicators'),
    malwares: g('malwares'),
    reports: g('reports'),
    attackPatterns: g('attackPatterns'),
    threatActors: g('threatActors'),
  };
}

export interface ThreatActor {
  id: string;
  name: string;
  types: string[];
  sophistication: string | null;
  confidence: number | null;
}

export async function getThreatActors(first = 24): Promise<ThreatActor[]> {
  const data = await octiQuery<any>(
    `query($first:Int){ threatActors(first:$first){ edges { node {
      id name threat_actor_types sophistication confidence
    } } } }`,
    { first },
  );
  const edges = (data?.threatActors?.edges || []) as any[];
  return edges.map((e) => ({
    id: e.node.id,
    name: e.node.name,
    types: e.node.threat_actor_types || [],
    sophistication: e.node.sophistication ?? null,
    confidence: e.node.confidence ?? null,
  }));
}

export interface CtiIndicator {
  id: string;
  name: string;
  pattern: string | null;
  patternType: string | null;
  score: number | null;
  validFrom: string | null;
}

export async function getIndicators(first = 50): Promise<CtiIndicator[]> {
  const data = await octiQuery<any>(
    `query($first:Int){ indicators(first:$first){ edges { node {
      id name pattern pattern_type x_opencti_score valid_from
    } } } }`,
    { first },
  );
  const edges = (data?.indicators?.edges || []) as any[];
  return edges.map((e) => ({
    id: e.node.id,
    name: e.node.name,
    pattern: e.node.pattern ?? null,
    patternType: e.node.pattern_type ?? null,
    score: e.node.x_opencti_score ?? null,
    validFrom: e.node.valid_from ?? null,
  }));
}

// ---------------------------------------------------------------------------
// Health probes
// ---------------------------------------------------------------------------

export async function pingMisp(): Promise<{ ok: boolean; detail: string }> {
  try {
    const res = await timedFetch(`${mispBase()}/events/restSearch`, {
      method: 'POST',
      headers: {
        Authorization: process.env.MISP_API_KEY || '',
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ limit: 1, returnFormat: 'json', metadata: true }),
    });
    return { ok: res.ok, detail: `HTTP ${res.status}` };
  } catch (e) {
    return { ok: false, detail: (e as Error).message };
  }
}

export async function pingOpenCti(): Promise<{ ok: boolean; detail: string }> {
  const data = await octiQuery<any>('{ about { version } }');
  if (data?.about?.version) return { ok: true, detail: `v${data.about.version}` };
  // about{} may be restricted; fall back to a trivial count query.
  const counts = await octiQuery<any>('{ indicators { pageInfo { globalCount } } }');
  return counts?.indicators
    ? { ok: true, detail: 'reachable' }
    : { ok: false, detail: 'unreachable / auth failed' };
}
