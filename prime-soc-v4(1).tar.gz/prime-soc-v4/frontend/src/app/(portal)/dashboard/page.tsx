'use client';

import { useState } from 'react';
import { useApi } from '@/lib/useApi';
import { useTimeRange } from '@/components/TimeRangeContext';
import { useSession } from '@/components/SessionContext';
import { type AlertHit, formatNumber } from '@/lib/format';
import {
  StatCard, BarList, SeverityDonut, TimeSeriesArea, Funnel,
  SectionTitle, SkeletonCard, ErrorBanner, Grid,
} from '@/components/widgets/primitives';
import AlertsTable from '@/components/widgets/AlertsTable';
import AlertDetailPanel from '@/components/AlertDetailPanel';

interface DashboardData {
  range: string;
  label: string;
  total: number;
  severity: { critical: number; high: number; medium: number; low: number; info: number };
  agentHealthPct: number;
  activeAgents: number;
  totalAgents: number;
  volume: { ts: number; count: number }[];
  topAgents: { key: string; count: number }[];
  topTactics: { key: string; count: number }[];
  topCountries: { key: string; count: number }[];
  topSrcIps: { key: string; count: number }[];
  eps: { ts: number; received: number; written: number }[];
  recent: AlertHit[];
}

export default function DashboardPage() {
  const { range, label } = useTimeRange();
  const user = useSession();
  const { data, loading, error, refetch } = useApi<DashboardData>(`/api/wazuh/dashboard?range=${range}`, [range]);
  const [selected, setSelected] = useState<AlertHit | null>(null);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
        <div>
          <h1 style={{ fontSize: 18, fontWeight: 700, margin: 0 }}>Security Operations</h1>
          <div style={{ fontSize: 11.5, color: 'var(--text-secondary)', marginTop: 2 }}>
            {user.is_admin ? 'All tenants' : `Tenant: ${user.group ?? '—'}`} · {label}
          </div>
        </div>
      </div>

      {error && <ErrorBanner message={error} onRetry={refetch} />}

      {/* KPI row */}
      {loading && !data ? (
        <Grid cols="repeat(5, 1fr)"><SkeletonCard /><SkeletonCard /><SkeletonCard /><SkeletonCard /><SkeletonCard /></Grid>
      ) : data ? (
        <Grid cols="repeat(5, 1fr)">
          <StatCard label="Total Alerts" value={data.total} accent="var(--cyan)" sub={label} />
          <StatCard label="Critical" value={data.severity.critical} accent="#ef4444" sub="rule.level ≥ 13" />
          <StatCard label="High" value={data.severity.high} accent="#f59e0b" sub="rule.level 10–12" />
          <StatCard label="Active Agents" value={data.activeAgents} accent="#10b981" sub={`of ${formatNumber(data.totalAgents)} known`} />
          <StatCard label="Agent Health" value={`${data.agentHealthPct}%`} accent={data.agentHealthPct >= 80 ? '#10b981' : data.agentHealthPct >= 50 ? '#f59e0b' : '#ef4444'} sub="active / total" />
        </Grid>
      ) : null}

      {/* Volume + severity */}
      <Grid cols="2fr 1fr">
        <div className="card card-static card-pad">
          <SectionTitle>Alert Volume</SectionTitle>
          {loading && !data ? <SkeletonCard height={200} /> : data ? (
            <TimeSeriesArea data={data.volume} range={range} series={[{ key: 'count', color: '#00d8e8', label: 'Alerts' }]} />
          ) : null}
        </div>
        <div className="card card-static card-pad">
          <SectionTitle>Severity Breakdown</SectionTitle>
          {loading && !data ? <SkeletonCard height={130} /> : data ? <SeverityDonut severity={data.severity} /> : null}
        </div>
      </Grid>

      {/* Top breakdowns */}
      <Grid cols="repeat(4, 1fr)">
        <div className="card card-static card-pad">
          <SectionTitle>Top Alert Sources</SectionTitle>
          {data ? <BarList items={data.topAgents} color="#00d8e8" /> : <SkeletonCard height={140} />}
        </div>
        <div className="card card-static card-pad">
          <SectionTitle>MITRE Tactics</SectionTitle>
          {data ? <BarList items={data.topTactics} color="#7c3aed" /> : <SkeletonCard height={140} />}
        </div>
        <div className="card card-static card-pad">
          <SectionTitle>Communicating Nations</SectionTitle>
          {data ? <BarList items={data.topCountries} color="#3b82f6" /> : <SkeletonCard height={140} />}
        </div>
        <div className="card card-static card-pad">
          <SectionTitle>Top Malicious IPs</SectionTitle>
          {data ? <BarList items={data.topSrcIps} color="#ef4444" /> : <SkeletonCard height={140} />}
        </div>
      </Grid>

      {/* Performance / EPS */}
      <Grid cols="1fr 2fr">
        <div className="card card-static card-pad">
          <SectionTitle>Event Processing</SectionTitle>
          {data ? (
            <Funnel
              stages={[
                { label: 'Events Received', value: sum(data.eps, 'received'), color: '#00d8e8' },
                { label: 'Alerts Generated', value: sum(data.eps, 'written'), color: '#f59e0b' },
              ]}
            />
          ) : <SkeletonCard height={90} />}
        </div>
        <div className="card card-static card-pad">
          <SectionTitle>EPS — Received vs Written</SectionTitle>
          {data ? (
            <TimeSeriesArea
              data={data.eps}
              range={range}
              height={160}
              series={[
                { key: 'received', color: '#00d8e8', label: 'Events Received' },
                { key: 'written', color: '#f59e0b', label: 'Alerts Written' },
              ]}
            />
          ) : <SkeletonCard height={160} />}
        </div>
      </Grid>

      {/* Recent alerts */}
      <div className="card card-static card-pad">
        <SectionTitle>Recent Alerts</SectionTitle>
        {loading && !data ? <SkeletonCard height={200} /> : data ? (
          <AlertsTable hits={data.recent} onSelect={setSelected} showGroup={user.is_admin} />
        ) : null}
      </div>

      <AlertDetailPanel alert={selected} onClose={() => setSelected(null)} />
    </div>
  );
}

function sum(arr: { [k: string]: number }[], key: string): number {
  return (arr || []).reduce((acc, x) => acc + (x[key] || 0), 0);
}
