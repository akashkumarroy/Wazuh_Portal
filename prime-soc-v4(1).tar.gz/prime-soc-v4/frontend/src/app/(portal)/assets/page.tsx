'use client';

import { useMemo, useState } from 'react';
import { useApi } from '@/lib/useApi';
import { useSession } from '@/components/SessionContext';
import { formatNumber, formatTs, timeAgo } from '@/lib/format';
import {
  StatCard, BarList, SectionTitle, SkeletonCard, ErrorBanner, EmptyState, Grid,
} from '@/components/widgets/primitives';

interface AgentRecord {
  name: string; id: string; ip: string; status: string;
  group: string[]; osName: string; osPlatform: string; osVersion: string;
  lastKeepAlive: string; dateAdd: string; manager: string; nodeName: string; version: string;
}

interface AgentSummary {
  total: number; active: number; disconnected: number; pending: number;
  agents: AgentRecord[];
  byOs: { key: string; count: number }[];
  byGroup: { key: string; count: number }[];
}

function statusBadge(status: string) {
  const s = (status || '').toLowerCase();
  const cls = s === 'active' ? 'badge-active' : s === 'disconnected' ? 'badge-disconnected' : s === 'pending' ? 'badge-pending' : 'badge-info';
  return <span className={`badge ${cls}`} style={{ textTransform: 'capitalize' }}>{status || 'unknown'}</span>;
}

export default function AssetsPage() {
  const user = useSession();
  const { data, loading, error, refetch } = useApi<AgentSummary>('/api/wazuh/agents', []);
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'disconnected' | 'pending'>('all');

  const filtered = useMemo(() => {
    let list = data?.agents ?? [];
    if (statusFilter !== 'all') list = list.filter((a) => (a.status || '').toLowerCase() === statusFilter);
    const q = query.trim().toLowerCase();
    if (q) {
      list = list.filter((a) =>
        a.name.toLowerCase().includes(q) ||
        a.ip.toLowerCase().includes(q) ||
        a.id.toLowerCase().includes(q) ||
        a.osName.toLowerCase().includes(q) ||
        a.group.join(' ').toLowerCase().includes(q),
      );
    }
    return list;
  }, [data, query, statusFilter]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div>
        <h1 style={{ fontSize: 18, fontWeight: 700, margin: 0 }}>Assets</h1>
        <div style={{ fontSize: 11.5, color: 'var(--text-secondary)', marginTop: 2 }}>
          {user.is_admin ? 'All monitored endpoints' : `Endpoints for ${user.group ?? '—'}`} · latest monitoring snapshot
        </div>
      </div>

      {error && <ErrorBanner message={error} onRetry={refetch} />}

      {loading && !data ? (
        <Grid cols="repeat(4,1fr)"><SkeletonCard /><SkeletonCard /><SkeletonCard /><SkeletonCard /></Grid>
      ) : data && data.total === 0 ? (
        <div className="card card-static card-pad">
          <EmptyState title="No agents reporting" detail="No monitoring snapshots in the last 2 hours for this scope." />
        </div>
      ) : data ? (
        <>
          <Grid cols="repeat(4, 1fr)">
            <StatCard label="Total Agents" value={data.total} accent="var(--cyan)" sub="latest snapshot" />
            <StatCard label="Active" value={data.active} accent="#10b981" sub={`${data.total ? Math.round((data.active / data.total) * 100) : 0}% online`} />
            <StatCard label="Disconnected" value={data.disconnected} accent="#ef4444" />
            <StatCard label="Pending" value={data.pending} accent="#f59e0b" />
          </Grid>

          <Grid cols="1fr 1fr">
            <div className="card card-static card-pad"><SectionTitle>Operating Systems</SectionTitle><BarList items={data.byOs} color="#00d8e8" emptyText="No OS data" /></div>
            <div className="card card-static card-pad"><SectionTitle>Tenant Groups</SectionTitle><BarList items={data.byGroup} color="#7c3aed" emptyText="No group labels" /></div>
          </Grid>

          {/* Inventory */}
          <div className="card card-static card-pad">
            <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap', marginBottom: 12 }}>
              <div className="card-title" style={{ marginRight: 'auto' }}>Agent Inventory</div>
              <input className="input" placeholder="Filter by name, IP, OS, group…" value={query} onChange={(e) => setQuery(e.target.value)} style={{ width: 260 }} />
              <select className="input" style={{ width: 'auto' }} value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as any)}>
                <option value="all">All statuses</option>
                <option value="active">Active</option>
                <option value="disconnected">Disconnected</option>
                <option value="pending">Pending</option>
              </select>
            </div>

            {filtered.length === 0 ? (
              <div style={{ fontSize: 11, color: 'var(--text-dim)', padding: '16px 0', textAlign: 'center' }}>No agents match the filter.</div>
            ) : (
              <div style={{ overflowX: 'auto' }}>
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Agent</th><th>ID</th><th>IP</th><th>Status</th>
                      <th>OS</th>{user.is_admin && <th>Group</th>}<th>Manager</th><th>Last Keep-Alive</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((a) => (
                      <tr key={a.id || a.name} style={{ cursor: 'default' }}>
                        <td style={{ whiteSpace: 'nowrap', fontWeight: 500 }}>{a.name || '—'}</td>
                        <td className="mono" style={{ color: 'var(--text-secondary)' }}>{a.id || '—'}</td>
                        <td className="mono" style={{ color: 'var(--text-secondary)' }}>{a.ip || '—'}</td>
                        <td>{statusBadge(a.status)}</td>
                        <td style={{ whiteSpace: 'nowrap' }}>{a.osName || a.osPlatform || '—'}</td>
                        {user.is_admin && <td>{a.group.length ? a.group.join(', ') : <span className="text-dim">none</span>}</td>}
                        <td style={{ color: 'var(--text-secondary)' }}>{a.manager || '—'}</td>
                        <td className="mono" style={{ whiteSpace: 'nowrap', color: 'var(--text-secondary)' }} title={formatTs(a.lastKeepAlive)}>{timeAgo(a.lastKeepAlive)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            <div style={{ fontSize: 10.5, color: 'var(--text-dim)', marginTop: 10 }}>
              Showing {formatNumber(filtered.length)} of {formatNumber(data.total)} agents
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}
