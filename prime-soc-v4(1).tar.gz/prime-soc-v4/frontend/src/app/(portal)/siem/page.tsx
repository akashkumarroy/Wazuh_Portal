'use client';

import { Suspense, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { useApi } from '@/lib/useApi';
import { useTimeRange } from '@/components/TimeRangeContext';
import { useSession } from '@/components/SessionContext';
import { type AlertHit, formatNumber, formatTs, get } from '@/lib/format';
import {
  SectionTitle, BarList, SkeletonCard, ErrorBanner, EmptyState, Grid,
} from '@/components/widgets/primitives';
import AlertsTable from '@/components/widgets/AlertsTable';
import AlertDetailPanel from '@/components/AlertDetailPanel';
import SankeyChart from '@/components/widgets/SankeyChart';

type TabKey = 'alerts' | 'mitre' | 'compliance' | 'fim' | 'sca' | 'vuln' | 'malware' | 'auth';

const TABS: { key: TabKey; label: string }[] = [
  { key: 'alerts', label: 'Alerts' },
  { key: 'mitre', label: 'MITRE ATT&CK' },
  { key: 'compliance', label: 'Compliance' },
  { key: 'fim', label: 'File Integrity' },
  { key: 'sca', label: 'SCA' },
  { key: 'vuln', label: 'Vulnerabilities' },
  { key: 'malware', label: 'Malware Flow' },
  { key: 'auth', label: 'Authentication' },
];

export default function SiemPage() {
  return (
    <Suspense fallback={<SkeletonCard height={400} />}>
      <SiemInner />
    </Suspense>
  );
}

function SiemInner() {
  const params = useSearchParams();
  const { range } = useTimeRange();
  const [tab, setTab] = useState<TabKey>('alerts');
  const [selected, setSelected] = useState<AlertHit | null>(null);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div>
        <h1 style={{ fontSize: 18, fontWeight: 700, margin: 0 }}>SIEM</h1>
        <div style={{ fontSize: 11.5, color: 'var(--text-secondary)', marginTop: 2 }}>
          Live event analytics from the Wazuh Indexer
        </div>
      </div>

      {/* Tab bar */}
      <div style={{ display: 'flex', gap: 6, borderBottom: '1px solid var(--border)', paddingBottom: 2, overflowX: 'auto' }}>
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className="btn btn-ghost"
            style={{
              borderRadius: '8px 8px 0 0',
              border: 'none',
              borderBottom: `2px solid ${tab === t.key ? 'var(--cyan)' : 'transparent'}`,
              color: tab === t.key ? 'var(--cyan)' : 'var(--text-secondary)',
              fontWeight: tab === t.key ? 600 : 500,
              whiteSpace: 'nowrap',
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'alerts' && <AlertsTab range={range} initialQuery={params.get('q') ?? ''} onSelect={setSelected} />}
      {tab === 'mitre' && <MitreTab range={range} />}
      {tab === 'compliance' && <ComplianceTab range={range} onSelect={setSelected} />}
      {tab === 'fim' && <FimTab range={range} onSelect={setSelected} />}
      {tab === 'sca' && <ScaTab range={range} onSelect={setSelected} />}
      {tab === 'vuln' && <VulnTab />}
      {tab === 'malware' && <MalwareTab range={range} />}
      {tab === 'auth' && <AuthTab range={range} onSelect={setSelected} />}

      <AlertDetailPanel alert={selected} onClose={() => setSelected(null)} />
    </div>
  );
}

/* ---------------------------------------------------------------- Alerts */

const LEVEL_PRESETS = [
  { label: 'All severities', min: undefined, max: undefined },
  { label: 'Critical (≥13)', min: 13, max: undefined },
  { label: 'High (10–12)', min: 10, max: 12 },
  { label: 'Medium (7–9)', min: 7, max: 9 },
  { label: 'Low (4–6)', min: 4, max: 6 },
];

function AlertsTab({ range, initialQuery, onSelect }: { range: string; initialQuery: string; onSelect: (h: AlertHit) => void }) {
  const user = useSession();
  const [search, setSearch] = useState(initialQuery);
  const [activeSearch, setActiveSearch] = useState(initialQuery);
  const [levelIdx, setLevelIdx] = useState(0);
  const [mitreOnly, setMitreOnly] = useState(false);
  const [page, setPage] = useState(0);
  const pageSize = 25;

  useEffect(() => { setPage(0); }, [activeSearch, levelIdx, mitreOnly, range]);

  const preset = LEVEL_PRESETS[levelIdx];
  const qs = useMemo(() => {
    const p = new URLSearchParams({ range, page: String(page), pageSize: String(pageSize) });
    if (activeSearch.trim()) p.set('search', activeSearch.trim());
    if (preset.min != null) p.set('minLevel', String(preset.min));
    if (preset.max != null) p.set('maxLevel', String(preset.max));
    if (mitreOnly) p.set('mitreTagged', 'true');
    return p.toString();
  }, [range, page, activeSearch, preset.min, preset.max, mitreOnly]);

  const { data, loading, error, refetch } = useApi<{ total: number; hits: AlertHit[] }>(`/api/wazuh/alerts?${qs}`, [qs]);
  const total = data?.total ?? 0;
  const maxPage = Math.max(0, Math.ceil(total / pageSize) - 1);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      {/* Filters */}
      <div className="card card-static card-pad" style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
        <form
          onSubmit={(e) => { e.preventDefault(); setActiveSearch(search); }}
          style={{ flex: 1, minWidth: 220 }}
        >
          <input className="input" placeholder="Search description, agent, IP, log…" value={search} onChange={(e) => setSearch(e.target.value)} />
        </form>
        <select className="input" style={{ width: 'auto' }} value={levelIdx} onChange={(e) => setLevelIdx(Number(e.target.value))}>
          {LEVEL_PRESETS.map((p, i) => <option key={p.label} value={i}>{p.label}</option>)}
        </select>
        <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11.5, color: 'var(--text-secondary)', cursor: 'pointer' }}>
          <input type="checkbox" checked={mitreOnly} onChange={(e) => setMitreOnly(e.target.checked)} />
          MITRE-tagged only
        </label>
        <button className="btn" onClick={() => setActiveSearch(search)}>Apply</button>
      </div>

      {error && <ErrorBanner message={error} onRetry={refetch} />}

      <div className="card card-static card-pad">
        <SectionTitle right={<span className="mono" style={{ fontSize: 10.5, color: 'var(--text-secondary)' }}>{formatNumber(total)} matches</span>}>
          Alerts
        </SectionTitle>
        {loading && !data ? <SkeletonCard height={300} /> : (
          <AlertsTable hits={data?.hits ?? []} onSelect={onSelect} showGroup={user.is_admin} />
        )}
        {/* Pagination */}
        {total > pageSize && (
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 12 }}>
            <span style={{ fontSize: 11, color: 'var(--text-secondary)' }}>Page {page + 1} of {maxPage + 1}</span>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn" disabled={page === 0} onClick={() => setPage((p) => Math.max(0, p - 1))} style={{ opacity: page === 0 ? 0.4 : 1 }}>Prev</button>
              <button className="btn" disabled={page >= maxPage} onClick={() => setPage((p) => Math.min(maxPage, p + 1))} style={{ opacity: page >= maxPage ? 0.4 : 1 }}>Next</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- MITRE */

function MitreTab({ range }: { range: string }) {
  const { data, loading, error, refetch } = useApi<{
    tactics: { key: string; count: number }[];
    techniques: { key: string; count: number }[];
    techniqueIds: { key: string; count: number }[];
  }>(`/api/wazuh/mitre?range=${range}`, [range]);

  if (error) return <ErrorBanner message={error} onRetry={refetch} />;
  if (loading && !data) return <Grid cols="repeat(3,1fr)"><SkeletonCard height={260} /><SkeletonCard height={260} /><SkeletonCard height={260} /></Grid>;
  if (data && data.tactics.length === 0 && data.techniques.length === 0) {
    return <div className="card card-static card-pad"><EmptyState title="No MITRE-tagged activity" detail="No alerts carried rule.mitre.* fields in the selected range." /></div>;
  }
  return (
    <Grid cols="repeat(3, 1fr)">
      <div className="card card-static card-pad"><SectionTitle>Tactics</SectionTitle><BarList items={data?.tactics ?? []} color="#00d8e8" /></div>
      <div className="card card-static card-pad"><SectionTitle>Techniques</SectionTitle><BarList items={data?.techniques ?? []} color="#7c3aed" /></div>
      <div className="card card-static card-pad"><SectionTitle>Technique IDs</SectionTitle><BarList items={data?.techniqueIds ?? []} color="#3b82f6" /></div>
    </Grid>
  );
}

/* ------------------------------------------------------------ Compliance */

const FRAMEWORKS = [
  { key: 'pci_dss', label: 'PCI DSS' },
  { key: 'gdpr', label: 'GDPR' },
  { key: 'hipaa', label: 'HIPAA' },
  { key: 'nist_800_53', label: 'NIST 800-53' },
  { key: 'tsc', label: 'TSC' },
  { key: 'gpg13', label: 'GPG13' },
];

function ComplianceTab({ range, onSelect }: { range: string; onSelect: (h: AlertHit) => void }) {
  const [fw, setFw] = useState('pci_dss');
  const { data, loading, error, refetch } = useApi<{
    framework: string; total: number;
    requirements: { key: string; count: number }[];
    alerts: AlertHit[];
  }>(`/api/wazuh/compliance?framework=${fw}&range=${range}`, [fw, range]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        {FRAMEWORKS.map((f) => (
          <button key={f.key} className={`btn ${fw === f.key ? 'btn-active' : ''}`} onClick={() => setFw(f.key)}>{f.label}</button>
        ))}
      </div>
      {error && <ErrorBanner message={error} onRetry={refetch} />}
      {loading && !data ? <SkeletonCard height={280} /> : data && data.total === 0 ? (
        <div className="card card-static card-pad"><EmptyState title={`No ${fw.toUpperCase()} mapped events`} detail="No alerts carried this framework's tags in range." /></div>
      ) : (
        <Grid cols="1fr 2fr">
          <div className="card card-static card-pad">
            <SectionTitle right={<span className="mono" style={{ fontSize: 10.5, color: 'var(--text-secondary)' }}>{formatNumber(data?.total ?? 0)}</span>}>Requirements</SectionTitle>
            <BarList items={data?.requirements ?? []} color="#10b981" />
          </div>
          <div className="card card-static card-pad">
            <SectionTitle>Recent Mapped Alerts</SectionTitle>
            <AlertsTable hits={data?.alerts ?? []} onSelect={onSelect} compact />
          </div>
        </Grid>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------- FIM */

function FimTab({ range, onSelect }: { range: string; onSelect: (h: AlertHit) => void }) {
  const { data, loading, error, refetch } = useApi<{ total: number; hits: AlertHit[] }>(`/api/wazuh/fim?range=${range}`, [range]);
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;
  if (loading && !data) return <SkeletonCard height={300} />;
  if (data && data.total === 0) {
    return <div className="card card-static card-pad"><EmptyState title="No file integrity events" detail="No syscheck (FIM) alerts in the selected range." /></div>;
  }
  return (
    <div className="card card-static card-pad">
      <SectionTitle right={<span className="mono" style={{ fontSize: 10.5, color: 'var(--text-secondary)' }}>{formatNumber(data?.total ?? 0)} events</span>}>File Integrity Monitoring</SectionTitle>
      <div style={{ overflowX: 'auto' }}>
        <table className="data-table">
          <thead><tr><th>Time</th><th>Agent</th><th>Event</th><th>Path</th><th>Rule</th></tr></thead>
          <tbody>
            {(data?.hits ?? []).map((h) => (
              <tr key={h._id} onClick={() => onSelect(h)}>
                <td className="mono" style={{ whiteSpace: 'nowrap', color: 'var(--text-secondary)' }}>{formatTs(get(h._source, 'timestamp'))}</td>
                <td style={{ whiteSpace: 'nowrap' }}>{get(h._source, 'agent.name') || '—'}</td>
                <td><span className="badge badge-info" style={{ textTransform: 'capitalize' }}>{get(h._source, 'syscheck.event') || '—'}</span></td>
                <td className="mono" style={{ maxWidth: 380, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{get(h._source, 'syscheck.path') || '—'}</td>
                <td style={{ maxWidth: 280, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{get(h._source, 'rule.description') || '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------- SCA */

function ScaTab({ range, onSelect }: { range: string; onSelect: (h: AlertHit) => void }) {
  const { data, loading, error, refetch } = useApi<{
    total: number;
    byAgent: { key: string; total: number; passed: number; failed: number }[];
    hits: AlertHit[];
  }>(`/api/wazuh/sca?range=${range}`, [range]);

  if (error) return <ErrorBanner message={error} onRetry={refetch} />;
  if (loading && !data) return <SkeletonCard height={300} />;
  if (data && data.total === 0) {
    return <div className="card card-static card-pad"><EmptyState title="No SCA results" detail="No security configuration assessment events in range." /></div>;
  }
  return (
    <Grid cols="1fr 1fr">
      <div className="card card-static card-pad">
        <SectionTitle>Checks by Agent</SectionTitle>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {(data?.byAgent ?? []).map((a) => {
            const pf = a.passed + a.failed || 1;
            return (
              <div key={a.key}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11.5, marginBottom: 3 }}>
                  <span>{a.key}</span>
                  <span className="mono" style={{ color: 'var(--text-secondary)' }}>{a.passed}✓ / {a.failed}✗</span>
                </div>
                <div className="bar-track" style={{ display: 'flex' }}>
                  <div style={{ width: `${(a.passed / pf) * 100}%`, background: '#10b981', height: '100%' }} />
                  <div style={{ width: `${(a.failed / pf) * 100}%`, background: '#ef4444', height: '100%' }} />
                </div>
              </div>
            );
          })}
          {(data?.byAgent ?? []).length === 0 && <div style={{ fontSize: 11, color: 'var(--text-dim)' }}>No per-agent breakdown.</div>}
        </div>
      </div>
      <div className="card card-static card-pad">
        <SectionTitle>Recent Checks</SectionTitle>
        <div style={{ overflowX: 'auto' }}>
          <table className="data-table">
            <thead><tr><th>Time</th><th>Agent</th><th>Result</th><th>Check</th></tr></thead>
            <tbody>
              {(data?.hits ?? []).map((h) => {
                const result = String(get(h._source, 'data.sca.check.result') || '');
                return (
                  <tr key={h._id} onClick={() => onSelect(h)}>
                    <td className="mono" style={{ whiteSpace: 'nowrap', color: 'var(--text-secondary)' }}>{formatTs(get(h._source, 'timestamp'))}</td>
                    <td>{get(h._source, 'agent.name') || '—'}</td>
                    <td><span className={`badge ${result === 'passed' ? 'badge-active' : result === 'failed' ? 'badge-critical' : 'badge-info'}`} style={{ textTransform: 'capitalize' }}>{result || '—'}</span></td>
                    <td style={{ maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{get(h._source, 'data.sca.check.title') || get(h._source, 'rule.description') || '—'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </Grid>
  );
}

/* --------------------------------------------------------- Vulnerabilities */

function VulnTab() {
  const { data, loading, error, refetch } = useApi<{
    total: number; indexed: boolean;
    bySeverity: { key: string; count: number }[];
    hits: AlertHit[];
  }>(`/api/wazuh/vulnerability`, []);

  if (error) return <ErrorBanner message={error} onRetry={refetch} />;
  if (loading && !data) return <SkeletonCard height={280} />;
  if (data && (!data.indexed || data.total === 0)) {
    return (
      <div className="card card-static card-pad">
        <EmptyState
          title="No vulnerability data indexed"
          detail={data.indexed ? 'The vulnerability index exists but currently holds 0 documents.' : 'No vulnerability-states index is present on this cluster yet.'}
        />
      </div>
    );
  }
  return (
    <Grid cols="1fr 2fr">
      <div className="card card-static card-pad"><SectionTitle>By Severity</SectionTitle><BarList items={data?.bySeverity ?? []} color="#f59e0b" /></div>
      <div className="card card-static card-pad">
        <SectionTitle right={<span className="mono" style={{ fontSize: 10.5, color: 'var(--text-secondary)' }}>{formatNumber(data?.total ?? 0)}</span>}>Findings</SectionTitle>
        <div style={{ overflowX: 'auto' }}>
          <table className="data-table">
            <thead><tr><th>Agent</th><th>Severity</th><th>CVE</th><th>Package</th><th>Status</th></tr></thead>
            <tbody>
              {(data?.hits ?? []).map((h, i) => (
                <tr key={i}>
                  <td>{get(h._source, 'agent.name') || '—'}</td>
                  <td>{get(h._source, 'vulnerability.severity') || '—'}</td>
                  <td className="mono">{get(h._source, 'vulnerability.cve') || '—'}</td>
                  <td>{get(h._source, 'vulnerability.name') || '—'}</td>
                  <td>{get(h._source, 'vulnerability.status') || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </Grid>
  );
}

/* --------------------------------------------------------------- Malware */

function MalwareTab({ range }: { range: string }) {
  const { data, loading, error, refetch } = useApi<{ nodes: { name: string }[]; links: { source: number; target: number; value: number }[] }>(`/api/wazuh/sankey?range=${range}`, [range]);
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;
  return (
    <div className="card card-static card-pad">
      <SectionTitle>Malware Flow · Tenant → Rule Group → Manager</SectionTitle>
      {loading && !data ? <SkeletonCard height={420} /> : <SankeyChart data={data ?? { nodes: [], links: [] }} />}
    </div>
  );
}

/* -------------------------------------------------------- Authentication */

function AuthTab({ range, onSelect }: { range: string; onSelect: (h: AlertHit) => void }) {
  const user = useSession();
  const { data, loading, error, refetch } = useApi<{ total: number; hits: AlertHit[] }>(
    `/api/wazuh/alerts?range=${range}&ruleGroup=authentication&pageSize=50`, [range],
  );
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;
  if (loading && !data) return <SkeletonCard height={300} />;
  if (data && data.total === 0) {
    return <div className="card card-static card-pad"><EmptyState title="No authentication events" detail="No alerts in the authentication rule group for this range." /></div>;
  }
  return (
    <div className="card card-static card-pad">
      <SectionTitle right={<span className="mono" style={{ fontSize: 10.5, color: 'var(--text-secondary)' }}>{formatNumber(data?.total ?? 0)} events</span>}>Authentication Events</SectionTitle>
      <AlertsTable hits={data?.hits ?? []} onSelect={onSelect} showGroup={user.is_admin} />
    </div>
  );
}
