'use client';

import { useApi } from '@/lib/useApi';
import { formatNumber, formatTs } from '@/lib/format';
import {
  StatCard, BarList, SectionTitle, SkeletonCard, EmptyState, Grid,
} from '@/components/widgets/primitives';

interface IrisCase {
  id: string; name: string; severity: string; state: string; open: boolean; openDate: string; owner: string;
}
interface IrisResult {
  reachable: boolean; cases: IrisCase[];
  stats: { total: number; open: number; closed: number; bySeverity: { key: string; count: number }[]; byState: { key: string; count: number }[] };
  detail: string;
}
interface ShuffleWorkflow {
  id: string; name: string; description: string; isValid: boolean; actionCount: number; triggerCount: number;
}
interface ShuffleResult { reachable: boolean; workflows: ShuffleWorkflow[]; detail: string; }

function ReachabilityPill({ ok, detail }: { ok: boolean; detail: string }) {
  return (
    <span className="badge" style={{ background: ok ? 'rgba(16,185,129,0.12)' : 'rgba(239,68,68,0.12)', color: ok ? '#6ee7b7' : '#fca5a5', borderColor: ok ? 'rgba(16,185,129,0.3)' : 'rgba(239,68,68,0.3)' }} title={detail}>
      <span className={ok ? 'pulse-dot' : ''} style={{ width: 6, height: 6, borderRadius: '50%', background: ok ? 'var(--green)' : 'var(--red)', display: 'inline-block' }} />
      {ok ? 'Connected' : 'Unreachable'}
    </span>
  );
}

export default function SoarPage() {
  const iris = useApi<IrisResult>('/api/soar/iris', []);
  const shuffle = useApi<ShuffleResult>('/api/soar/shuffle', []);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div>
        <h1 style={{ fontSize: 18, fontWeight: 700, margin: 0 }}>SOAR</h1>
        <div style={{ fontSize: 11.5, color: 'var(--text-secondary)', marginTop: 2 }}>
          DFIR-IRIS case management · Shuffle automation
        </div>
      </div>

      {/* IRIS */}
      <div className="card card-static card-pad">
        <SectionTitle right={iris.data ? <ReachabilityPill ok={iris.data.reachable} detail={iris.data.detail} /> : null}>
          DFIR-IRIS Cases
        </SectionTitle>

        {iris.loading && !iris.data ? (
          <SkeletonCard height={160} />
        ) : iris.data && !iris.data.reachable ? (
          <EmptyState
            title="IRIS is not reachable from the portal"
            detail="The case-management host is not currently routable (WireGuard). Showing 0 cases — this is expected until network access is restored."
          />
        ) : iris.data ? (
          <>
            <Grid cols="repeat(3, 1fr)">
              <StatCard label="Total Cases" value={iris.data.stats.total} accent="var(--cyan)" />
              <StatCard label="Open" value={iris.data.stats.open} accent="#f59e0b" />
              <StatCard label="Closed" value={iris.data.stats.closed} accent="#10b981" />
            </Grid>

            {iris.data.stats.total === 0 ? (
              <div style={{ marginTop: 12 }}><EmptyState title="No cases yet" detail="IRIS is reachable but has no cases." /></div>
            ) : (
              <Grid cols="1fr 2fr">
                <div style={{ display: 'flex', flexDirection: 'column', gap: 14, marginTop: 12 }}>
                  <div><SectionTitle>By Severity</SectionTitle><BarList items={iris.data.stats.bySeverity} color="#ef4444" /></div>
                  <div><SectionTitle>By State</SectionTitle><BarList items={iris.data.stats.byState} color="#3b82f6" /></div>
                </div>
                <div style={{ marginTop: 12, overflowX: 'auto' }}>
                  <table className="data-table">
                    <thead><tr><th>Case</th><th>Severity</th><th>State</th><th>Owner</th><th>Opened</th></tr></thead>
                    <tbody>
                      {iris.data.cases.map((c) => (
                        <tr key={c.id} style={{ cursor: 'default' }}>
                          <td style={{ maxWidth: 280, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.name || `#${c.id}`}</td>
                          <td>{c.severity}</td>
                          <td><span className={`badge ${c.open ? 'badge-high' : 'badge-active'}`}>{c.state}</span></td>
                          <td style={{ color: 'var(--text-secondary)' }}>{c.owner || '—'}</td>
                          <td className="mono" style={{ color: 'var(--text-secondary)', whiteSpace: 'nowrap' }}>{formatTs(c.openDate)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Grid>
            )}
          </>
        ) : null}
      </div>

      {/* Shuffle */}
      <div className="card card-static card-pad">
        <SectionTitle right={shuffle.data ? <ReachabilityPill ok={shuffle.data.reachable} detail={shuffle.data.detail} /> : null}>
          Shuffle Workflows
        </SectionTitle>

        {shuffle.loading && !shuffle.data ? (
          <SkeletonCard height={140} />
        ) : shuffle.data && !shuffle.data.reachable ? (
          <EmptyState title="Shuffle is not reachable" detail="The automation host did not respond. No workflows to display." />
        ) : shuffle.data && shuffle.data.workflows.length === 0 ? (
          <EmptyState title="No workflows configured" detail="Shuffle is connected but no automation workflows exist yet." />
        ) : shuffle.data ? (
          <Grid cols="repeat(3, 1fr)">
            {shuffle.data.workflows.map((w) => (
              <div key={w.id} className="card card-pad" style={{ background: 'var(--bg-secondary)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{w.name}</div>
                  <span className={`badge ${w.isValid ? 'badge-active' : 'badge-info'}`}>{w.isValid ? 'valid' : 'draft'}</span>
                </div>
                {w.description && <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginTop: 5, lineHeight: 1.4 }}>{w.description}</div>}
                <div style={{ display: 'flex', gap: 12, marginTop: 8, fontSize: 10.5, color: 'var(--text-dim)' }}>
                  <span>{formatNumber(w.actionCount)} actions</span>
                  <span>{formatNumber(w.triggerCount)} triggers</span>
                </div>
              </div>
            ))}
          </Grid>
        ) : null}
      </div>
    </div>
  );
}
