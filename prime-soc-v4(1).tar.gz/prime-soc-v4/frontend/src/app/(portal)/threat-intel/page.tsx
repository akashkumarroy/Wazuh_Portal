'use client';

import { useMemo, useState } from 'react';
import { useApi } from '@/lib/useApi';
import { useTimeRange } from '@/components/TimeRangeContext';
import { formatNumber, formatTs } from '@/lib/format';
import {
  StatCard, BarList, SectionTitle, SkeletonCard, ErrorBanner, EmptyState, Grid,
} from '@/components/widgets/primitives';
import WorldAttackMap, { type GeoPoint } from '@/components/widgets/WorldAttackMap';
import CtiRadar from '@/components/widgets/CtiRadar';

interface CtiCounts {
  indicators: number; malwares: number; reports: number; attackPatterns: number; threatActors: number;
}
interface MispEvent {
  id: string; info: string; date: string; threatLevel: 'High' | 'Medium' | 'Low' | 'Undefined';
  org: string; tags: string[]; iocCount: number;
}
interface MispSummary {
  total: number; events: MispEvent[];
  byLevel: Record<'High' | 'Medium' | 'Low' | 'Undefined', number>;
  byOrg: { key: string; count: number }[];
}

const LEVEL_BADGE: Record<string, string> = {
  High: 'badge-critical', Medium: 'badge-high', Low: 'badge-low', Undefined: 'badge-info',
};

type Tab = 'overview' | 'actors' | 'indicators';

export default function ThreatIntelPage() {
  const { range } = useTimeRange();
  const [tab, setTab] = useState<Tab>('overview');

  const cti = useApi<{ counts: CtiCounts }>('/api/intel/cti?view=overview', []);
  const misp = useApi<MispSummary>('/api/intel/misp?limit=30', []);
  const geo = useApi<{ points: GeoPoint[]; byCountry: { key: string; count: number }[] }>(`/api/wazuh/geo?range=${range}`, [range]);

  const counts = cti.data?.counts;
  const radar = useMemo(() => {
    if (!counts) return [];
    // log-scaled so the 980k indicators don't flatten the rest
    const v = (n: number) => Math.round(Math.log1p(n) * 10);
    return [
      { axis: 'Indicators', value: v(counts.indicators) },
      { axis: 'Malware', value: v(counts.malwares) },
      { axis: 'Attack Patterns', value: v(counts.attackPatterns) },
      { axis: 'Reports', value: v(counts.reports) },
      { axis: 'Actors', value: v(counts.threatActors) },
      { axis: 'MISP Events', value: v(misp.data?.total ?? 0) },
    ];
  }, [counts, misp.data]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div>
        <h1 style={{ fontSize: 18, fontWeight: 700, margin: 0 }}>Threat Intelligence</h1>
        <div style={{ fontSize: 11.5, color: 'var(--text-secondary)', marginTop: 2 }}>
          OpenCTI knowledge base · MISP feeds · live attack geography
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 6, borderBottom: '1px solid var(--border)' }}>
        {(['overview', 'actors', 'indicators'] as Tab[]).map((t) => (
          <button key={t} onClick={() => setTab(t)} className="btn btn-ghost"
            style={{ border: 'none', borderBottom: `2px solid ${tab === t ? 'var(--cyan)' : 'transparent'}`, color: tab === t ? 'var(--cyan)' : 'var(--text-secondary)', textTransform: 'capitalize', fontWeight: tab === t ? 600 : 500 }}>
            {t === 'actors' ? 'Threat Actors' : t}
          </button>
        ))}
      </div>

      {/* KPI row (always visible) */}
      {cti.error && <ErrorBanner message={`OpenCTI: ${cti.error}`} onRetry={cti.refetch} />}
      {cti.loading && !counts ? (
        <Grid cols="repeat(6,1fr)">{Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />)}</Grid>
      ) : (
        <Grid cols="repeat(6, 1fr)">
          <StatCard label="IOC Indicators" value={counts?.indicators ?? 0} accent="var(--cyan)" />
          <StatCard label="Malware Families" value={counts?.malwares ?? 0} accent="#7c3aed" />
          <StatCard label="Attack Patterns" value={counts?.attackPatterns ?? 0} accent="#3b82f6" />
          <StatCard label="Reports" value={counts?.reports ?? 0} accent="#10b981" />
          <StatCard label="Threat Actors" value={counts?.threatActors ?? 0} accent={(counts?.threatActors ?? 0) > 0 ? '#f59e0b' : 'var(--text-dim)'} sub={(counts?.threatActors ?? 0) === 0 ? 'none in OpenCTI' : undefined} />
          <StatCard label="MISP Events" value={misp.data?.total ?? 0} accent="#ef4444" />
        </Grid>
      )}

      {tab === 'overview' && (
        <>
          {/* radar + world map + feed */}
          <Grid cols="1fr 2fr">
            <div className="card card-static card-pad">
              <SectionTitle>CTI Posture</SectionTitle>
              {counts ? <CtiRadar data={radar} /> : <SkeletonCard height={220} />}
            </div>
            <div className="card card-static card-pad">
              <SectionTitle right={geo.data ? <span className="mono" style={{ fontSize: 10.5, color: 'var(--text-secondary)' }}>{formatNumber(geo.data.points.length)} sources</span> : null}>
                Live Attack Geography
              </SectionTitle>
              {geo.error ? <ErrorBanner message={geo.error} onRetry={geo.refetch} />
                : geo.loading && !geo.data ? <SkeletonCard height={420} />
                : <WorldAttackMap points={geo.data?.points ?? []} byCountry={geo.data?.byCountry ?? []} />}
            </div>
          </Grid>

          <Grid cols="2fr 1fr">
            {/* MISP CTI feed */}
            <div className="card card-static card-pad">
              <SectionTitle right={misp.data ? <span className="mono" style={{ fontSize: 10.5, color: 'var(--text-secondary)' }}>{formatNumber(misp.data.total)} events</span> : null}>
                MISP Threat Feed
              </SectionTitle>
              {misp.error ? <ErrorBanner message={misp.error} onRetry={misp.refetch} />
                : misp.loading && !misp.data ? <SkeletonCard height={300} />
                : (misp.data?.events.length ?? 0) === 0 ? <EmptyState title="No MISP events" detail="The MISP feed returned no events or is unreachable." />
                : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8, maxHeight: 420, overflowY: 'auto' }}>
                    {misp.data!.events.map((e) => (
                      <div key={e.id} className="card card-pad" style={{ background: 'var(--bg-secondary)' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, alignItems: 'flex-start' }}>
                          <div style={{ fontSize: 12.5, fontWeight: 600, lineHeight: 1.35 }}>{e.info}</div>
                          <span className={`badge ${LEVEL_BADGE[e.threatLevel]}`} style={{ whiteSpace: 'nowrap' }}>{e.threatLevel}</span>
                        </div>
                        <div style={{ display: 'flex', gap: 12, marginTop: 5, fontSize: 10.5, color: 'var(--text-secondary)', flexWrap: 'wrap' }}>
                          <span className="mono">{e.date}</span>
                          {e.org && <span>· {e.org}</span>}
                          <span>· {formatNumber(e.iocCount)} IOCs</span>
                        </div>
                        {e.tags.length > 0 && (
                          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginTop: 6 }}>
                            {e.tags.slice(0, 6).map((t, i) => (
                              <span key={i} className="badge badge-info" style={{ fontSize: 9 }}>{t}</span>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
            </div>

            {/* breakdowns */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div className="card card-static card-pad">
                <SectionTitle>MISP Threat Levels</SectionTitle>
                {misp.data ? (
                  <BarList
                    items={(['High', 'Medium', 'Low', 'Undefined'] as const).map((k) => ({ key: k, count: misp.data!.byLevel[k] }))}
                    color="#ef4444"
                  />
                ) : <SkeletonCard height={120} />}
              </div>
              <div className="card card-static card-pad">
                <SectionTitle>Top Source Countries</SectionTitle>
                {geo.data ? <BarList items={geo.data.byCountry.slice(0, 8)} color="#3b82f6" emptyText="No geo data" /> : <SkeletonCard height={120} />}
              </div>
              <div className="card card-static card-pad">
                <SectionTitle>Feed Organizations</SectionTitle>
                {misp.data ? <BarList items={misp.data.byOrg.slice(0, 6)} color="#10b981" emptyText="No org data" /> : <SkeletonCard height={120} />}
              </div>
            </div>
          </Grid>
        </>
      )}

      {tab === 'actors' && <ActorsTab />}
      {tab === 'indicators' && <IndicatorsTab />}
    </div>
  );
}

/* ---------------------------------------------------------- Threat Actors */

function ActorsTab() {
  const { data, loading, error, refetch } = useApi<{ actors: { id: string; name: string; types: string[]; sophistication: string | null; confidence: number | null }[] }>('/api/intel/cti?view=actors', []);
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;
  if (loading && !data) return <Grid cols="repeat(4,1fr)">{Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} height={120} />)}</Grid>;
  if (!data || data.actors.length === 0) {
    return (
      <div className="card card-static card-pad">
        <EmptyState title="No threat actors in OpenCTI" detail="This OpenCTI instance currently holds 0 threat-actor entities. Indicators, malware, and attack patterns are still populated." />
      </div>
    );
  }
  return (
    <Grid cols="repeat(4, 1fr)">
      {data.actors.map((a) => (
        <div key={a.id} className="card card-pad">
          <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 6 }}>{a.name}</div>
          {a.types.length > 0 && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginBottom: 8 }}>
              {a.types.map((t, i) => <span key={i} className="badge badge-info" style={{ fontSize: 9 }}>{t}</span>)}
            </div>
          )}
          <div style={{ fontSize: 10.5, color: 'var(--text-secondary)' }}>
            {a.sophistication && <div>Sophistication: {a.sophistication}</div>}
            {a.confidence != null && <div>Confidence: {a.confidence}</div>}
          </div>
        </div>
      ))}
    </Grid>
  );
}

/* ------------------------------------------------------------- Indicators */

function IndicatorsTab() {
  const { data, loading, error, refetch } = useApi<{ indicators: { id: string; name: string; pattern: string | null; patternType: string | null; score: number | null; validFrom: string | null }[] }>('/api/intel/cti?view=indicators', []);
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;
  if (loading && !data) return <SkeletonCard height={320} />;
  if (!data || data.indicators.length === 0) {
    return <div className="card card-static card-pad"><EmptyState title="No indicators returned" detail="OpenCTI returned no indicators for this query." /></div>;
  }
  return (
    <div className="card card-static card-pad">
      <SectionTitle right={<span className="mono" style={{ fontSize: 10.5, color: 'var(--text-secondary)' }}>{formatNumber(data.indicators.length)} shown</span>}>Recent Indicators</SectionTitle>
      <div style={{ overflowX: 'auto' }}>
        <table className="data-table">
          <thead><tr><th>Name / Value</th><th>Pattern Type</th><th>Score</th><th>Valid From</th></tr></thead>
          <tbody>
            {data.indicators.map((ind) => (
              <tr key={ind.id} style={{ cursor: 'default' }}>
                <td className="mono" style={{ maxWidth: 360, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={ind.pattern || ind.name}>{ind.name || ind.pattern || '—'}</td>
                <td>{ind.patternType || '—'}</td>
                <td>
                  <span className={`badge ${(ind.score ?? 0) >= 75 ? 'badge-critical' : (ind.score ?? 0) >= 40 ? 'badge-high' : 'badge-low'}`}>{ind.score ?? '—'}</span>
                </td>
                <td className="mono" style={{ color: 'var(--text-secondary)', whiteSpace: 'nowrap' }}>{formatTs(ind.validFrom)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
