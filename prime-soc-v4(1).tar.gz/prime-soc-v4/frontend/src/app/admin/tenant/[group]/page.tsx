'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useApi } from '@/lib/useApi';
import { useTimeRange } from '@/components/TimeRangeContext';
import { type AlertHit, formatNumber } from '@/lib/format';
import {
  StatCard, BarList, SeverityDonut, TimeSeriesArea, SectionTitle, SkeletonCard, ErrorBanner, EmptyState, Grid,
} from '@/components/widgets/primitives';
import AlertsTable from '@/components/widgets/AlertsTable';
import AlertDetailPanel from '@/components/AlertDetailPanel';
import RiskScoreGauge, { computeRiskScore } from '@/components/widgets/RiskScoreGauge';

interface TenantDetail {
  group: string; range: string; total: number;
  severity: { critical: number; high: number; medium: number; low: number; info: number };
  trend: { ts: number; count: number }[];
  topAgents: { key: string; count: number }[];
  topRules: { key: string; count: number }[];
  agents: any[]; activeAgents: number; disconnectedAgents: number; totalAgents: number;
  byOs: { key: string; count: number }[];
  recent: AlertHit[];
}

export default function TenantDetailPage() {
  const params = useParams();
  const group = decodeURIComponent(String(params.group));
  const { range } = useTimeRange();
  const { data, loading, error, refetch } = useApi<TenantDetail>(`/api/wazuh/tenant/${encodeURIComponent(group)}?range=${range}`, [group, range]);
  const [selected, setSelected] = useState<AlertHit | null>(null);

  const healthPct = data && data.totalAgents > 0 ? Math.round((data.activeAgents / data.totalAgents) * 100) : 0;
  const risk = data ? computeRiskScore({ critical: data.severity.critical, high: data.severity.high, total: data.total, agentHealthPct: healthPct }) : 0;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <Link href="/admin/tenants" className="btn btn-ghost" style={{ padding: '4px 9px' }}>← Tenants</Link>
        <div>
          <h1 style={{ fontSize: 18, fontWeight: 700, margin: 0 }}>{group}</h1>
          <div style={{ fontSize: 11.5, color: 'var(--text-secondary)' }}>Tenant security profile</div>
        </div>
      </div>

      {error && <ErrorBanner message={error} onRetry={refetch} />}

      {loading && !data ? (
        <Grid cols="1fr 3fr"><SkeletonCard height={200} /><SkeletonCard height={200} /></Grid>
      ) : data ? (
        <>
          <Grid cols="260px 1fr">
            <div className="card card-static card-pad" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <RiskScoreGauge score={risk} title="Composite Risk" sub={`${data.range} window`} />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <Grid cols="repeat(6, 1fr)">
                <StatCard label="Total Alerts" value={data.total} accent="var(--cyan)" />
                <StatCard label="Critical" value={data.severity.critical} accent="#ef4444" />
                <StatCard label="High" value={data.severity.high} accent="#f59e0b" />
                <StatCard label="Total Agents" value={data.totalAgents} accent="#3b82f6" />
                <StatCard label="Active Agents" value={data.activeAgents} accent="#10b981" sub={`of ${formatNumber(data.totalAgents)}`} />
                <StatCard label="Disconnected" value={data.disconnectedAgents} accent="#f59e0b" />
              </Grid>
              <div className="card card-static card-pad">
                <SectionTitle>Alert Trend</SectionTitle>
                <TimeSeriesArea data={data.trend} range={range} height={150} series={[{ key: 'count', color: '#00d8e8', label: 'Alerts' }]} />
              </div>
            </div>
          </Grid>

          <Grid cols="1fr 1fr 1fr">
            <div className="card card-static card-pad"><SectionTitle>Severity</SectionTitle><SeverityDonut severity={data.severity} /></div>
            <div className="card card-static card-pad"><SectionTitle>Top Agents</SectionTitle><BarList items={data.topAgents} color="#00d8e8" /></div>
            <div className="card card-static card-pad"><SectionTitle>Top Rules</SectionTitle><BarList items={data.topRules} color="#7c3aed" /></div>
          </Grid>

          <div className="card card-static card-pad">
            <SectionTitle right={<span className="mono" style={{ fontSize: 10.5, color: 'var(--text-secondary)' }}>{formatNumber(data.totalAgents)} agents</span>}>Operating Systems</SectionTitle>
            <Grid cols="1fr 1fr">
              <BarList items={data.byOs} color="#3b82f6" emptyText="No OS data" />
              <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 8 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}><span>Agent Health</span><span className="mono">{healthPct}%</span></div>
                <div className="bar-track"><div className="bar-fill" style={{ width: `${healthPct}%`, background: healthPct >= 80 ? '#10b981' : healthPct >= 50 ? '#f59e0b' : '#ef4444' }} /></div>
              </div>
            </Grid>
          </div>

          <div className="card card-static card-pad">
            <SectionTitle>Recent Alerts</SectionTitle>
            {data.recent.length === 0 ? <EmptyState title="No recent alerts" /> : <AlertsTable hits={data.recent} onSelect={setSelected} />}
          </div>
        </>
      ) : null}

      <AlertDetailPanel alert={selected} onClose={() => setSelected(null)} />
    </div>
  );
}
