'use client';

import { useMemo, useState } from 'react';
import { useApi } from '@/lib/useApi';
import { formatNumber } from '@/lib/format';
import { StatCard, SkeletonCard, ErrorBanner, EmptyState, Grid } from '@/components/widgets/primitives';

interface PortalUser {
  username: string;
  type: 'ADMIN' | 'CLIENT';
  backend_roles: string[];
  roles: string[];
}

export default function AdminUsersPage() {
  const { data, loading, error, refetch } = useApi<{ users: PortalUser[] }>('/api/wazuh/users', []);
  const [query, setQuery] = useState('');

  const users = data?.users ?? [];
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return users;
    return users.filter(
      (u) => u.username.toLowerCase().includes(q) || u.roles.join(' ').toLowerCase().includes(q),
    );
  }, [users, query]);

  const admins = users.filter((u) => u.type === 'ADMIN').length;
  const clients = users.length - admins;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div>
        <h1 style={{ fontSize: 18, fontWeight: 700, margin: 0 }}>Users</h1>
        <div style={{ fontSize: 11.5, color: 'var(--text-secondary)', marginTop: 2 }}>
          OpenSearch Security internal users · access model
        </div>
      </div>

      {error && <ErrorBanner message={error} onRetry={refetch} />}

      {loading && !data ? (
        <Grid cols="repeat(3,1fr)"><SkeletonCard /><SkeletonCard /><SkeletonCard /></Grid>
      ) : users.length === 0 ? (
        <div className="card card-static card-pad"><EmptyState title="No users returned" detail="The internalusers API returned no accounts." /></div>
      ) : (
        <>
          <Grid cols="repeat(3, 1fr)">
            <StatCard label="Total Users" value={users.length} accent="var(--cyan)" />
            <StatCard label="Administrators" value={admins} accent="#7c3aed" />
            <StatCard label="Client Accounts" value={clients} accent="#3b82f6" />
          </Grid>

          <div className="card card-static card-pad">
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
              <div className="card-title" style={{ marginRight: 'auto' }}>Accounts</div>
              <input className="input" placeholder="Filter by username or role…" value={query} onChange={(e) => setQuery(e.target.value)} style={{ width: 260 }} />
            </div>
            <div style={{ overflowX: 'auto' }}>
              <table className="data-table">
                <thead><tr><th>Username</th><th>Type</th><th>Backend Roles</th><th>DLS Roles</th></tr></thead>
                <tbody>
                  {filtered.map((u) => (
                    <tr key={u.username} style={{ cursor: 'default' }}>
                      <td style={{ fontWeight: 500 }}>{u.username}</td>
                      <td><span className={`badge ${u.type === 'ADMIN' ? 'badge-high' : 'badge-low'}`}>{u.type}</span></td>
                      <td style={{ color: 'var(--text-secondary)' }}>
                        {u.backend_roles.filter((r) => r && r.trim()).join(', ') || <span className="text-dim">none</span>}
                      </td>
                      <td>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                          {u.roles.length ? u.roles.map((r, i) => <span key={i} className="badge badge-info" style={{ fontSize: 9 }}>{r}</span>) : <span className="text-dim">—</span>}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div style={{ fontSize: 10.5, color: 'var(--text-dim)', marginTop: 10 }}>
              Showing {formatNumber(filtered.length)} of {formatNumber(users.length)} accounts
            </div>
          </div>
        </>
      )}
    </div>
  );
}
