import { redirect } from 'next/navigation';
import { getSession } from '@/lib/auth';
import { SessionProvider } from '@/components/SessionContext';
import { TimeRangeProvider } from '@/components/TimeRangeContext';
import TopBar from '@/components/layout/TopBar';
import Sidebar from '@/components/layout/Sidebar';
import FooterBar from '@/components/layout/FooterBar';
import AIAssistant from '@/components/AIAssistant';

export const dynamic = 'force-dynamic';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();
  if (!session) redirect('/');
  if (!session.is_admin) redirect('/dashboard');

  const user = {
    username: session.sub,
    role: session.role,
    is_admin: session.is_admin,
    group: session.group,
  };

  return (
    <SessionProvider user={user}>
      <TimeRangeProvider>
        <div className="app-shell">
          <TopBar />
          <Sidebar />
          <main className="app-main">{children}</main>
          <FooterBar />
          <AIAssistant />
        </div>
      </TimeRangeProvider>
    </SessionProvider>
  );
}
