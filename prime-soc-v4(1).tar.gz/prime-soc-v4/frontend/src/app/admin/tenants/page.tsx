'use client';

import Link from 'next/link';
import { useApi } from '@/lib/useApi';
import { useTimeRange } from '@/components/TimeRangeContext';
import { formatNumber, timeAgo } from '@/lib/format';
import { StatCard, SkeletonCard, ErrorBanner, EmptyState, Grid, SectionTitle } from '@/components/widgets/primitives';
import { computeRiskScore } from '@/components/widgets/RiskScoreGauge';

interface TenantSummary {
  group: string; total: number; critical: number; high: number; medium: number;
  sparkline: number[]; lastAlert: number | null;
}

function Sparkline({ values, color = 'var(--cyan)' }: { values: number[]; color?: string }) {
  if (!values || values.length === 0) return <div style={{ height: 28 }} />;
  const max = Math.max(...values, 1);
  const w = 100, h = 28;
  const step = values.length > 1 ? w / (values.length - 1) : w;
  const pts = values.map((v, i) => `${i * step},${h - (v / max) * h}`).join(' ');
  return (
    <svg width="100%" height={h} viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none">
      <polyline points={pts} fill="none" stroke={color} strokeWidth={1.5} />
    </svg>
  );
}

function riskBand(score: number): { color: string; label: string } {
  if (score >= 70) return { color: '#ef4444', label: 'Critical' };
  if (score >= 40) return { color: '#f59e0b', label: 'Elevated' };
  if (score >= 20) return { color: '#eab308', label: 'Guarded' };
  return { color: '#10b981', label: 'Low' };
}

export default function AdminTenantsPage() {
  const { range, label } = useTimeRange();
  const { data, loading, error, refetch } = useApi<{ tenants: TenantSummary[]; range: string }>(`/api/wazuh/tenants?range=${range}`, [range]);

  const tenants = data?.tenants ?? [];
  const totals = tenants.reduce(
    (acc, t) => ({ alerts: acc.alerts + t.total, critical: acc.critical + t.critical, high: acc.high + t.high }),
    { alerts: 0, critical: 0, high: 0 },
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div>
        <h1 style={{ fontSize: 18, fontWeight: 700, margin: 0 }}>Tenants</h1>
        <div style={{ fontSize: 11.5, color: 'var(--text-secondary)', marginTop: 2 }}>
          Auto-synced from agent.labels.group · {label}
        </div>
      </div>

      {error && <ErrorBanner message={error} onRetry={refetch} />}

      {loading && !data ? (
        <Grid cols="repeat(4,1fr)"><SkeletonCard /><SkeletonCard /><SkeletonCard /><SkeletonCard /></Grid>
      ) : tenants.length === 0 ? (
        <div className="card card-static card-pad"><EmptyState title="No tenants with activity" detail="No grouped alerts in the selected range." /></div>
      ) : (
        <>
          <Grid cols="repeat(4, 1fr)">
            <StatCard label="Active Tenants" value={tenants.length} accent="var(--cyan)" />
            <StatCard label="Total Alerts" value={totals.alerts} accent="#3b82f6" sub={label} />
            <StatCard label="Critical" value={totals.critical} accent="#ef4444" />
            <StatCard label="High" value={totals.high} accent="#f59e0b" />
          </Grid>

          <Grid cols="repeat(3, 1fr)">
            {tenants.map((t) => {
              const score = computeRiskScore({ critical: t.critical, high: t.high, total: t.total, agentHealthPct: 100 });
              const band = riskBand(score);
              return (
                <Link key={t.group} href={`/admin/tenant/${encodeURIComponent(t.group)}`} style={{ textDecoration: 'none' }}>
                  <div className="card card-pad" style={{ display: 'flex', flexDirection: 'column', gap: 10, height: '100%' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <div style={{ fontSize: 14, fontWeight: 600 }}>{t.group}</div>
                      <span className="badge" style={{ background: `${band.color}22`, color: band.color, borderColor: `${band.color}55` }}>{band.label}</span>
                    </div>

                    <Sparkline values={t.sparkline} color={band.color} />

                    <div style={{ display: 'flex', gap: 14 }}>
                      <div>
                        <div className="stat-value" style={{ fontSize: 18 }}>{formatNumber(t.total)}</div>
                        <div style={{ fontSize: 9, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>alerts</div>
                      </div>
                      <div>
                        <div className="stat-value" style={{ fontSize: 18, color: '#ef4444' }}>{formatNumber(t.critical)}</div>
                        <div style={{ fontSize: 9, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>critical</div>
                      </div>
                      <div>
                        <div className="stat-value" style={{ fontSize: 18, color: '#f59e0b' }}>{formatNumber(t.high)}</div>
                        <div style={{ fontSize: 9, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>high</div>
                      </div>
                    </div>

                    <div style={{ marginTop: 'auto', fontSize: 10, color: 'var(--text-dim)' }}>
                      Last alert: {t.lastAlert ? timeAgo(t.lastAlert) : '—'}
                    </div>
                  </div>
                </Link>
              );
            })}
          </Grid>
        </>
      )}
    </div>
  );
}
