import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { getAlerts, getAgentSummary, normalizeRange } from '@/lib/wazuh';
import { getMispEvents } from '@/lib/intel';
import { audit } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const MAX_RECORDS = 5000;

type Dataset = 'alerts' | 'assets' | 'cti';
type Format = 'csv' | 'json';

function toCsv(rows: Record<string, unknown>[]): string {
  if (rows.length === 0) return '';
  const headers = Array.from(
    rows.reduce((set, r) => { Object.keys(r).forEach((k) => set.add(k)); return set; }, new Set<string>()),
  );
  const esc = (v: unknown) => {
    const s = v == null ? '' : typeof v === 'object' ? JSON.stringify(v) : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [headers.join(','), ...rows.map((r) => headers.map((h) => esc(r[h])).join(','))].join('\n');
}

export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const p = req.nextUrl.searchParams;
  const dataset = (p.get('dataset') ?? 'alerts') as Dataset;
  const format = (p.get('format') ?? 'csv') as Format;
  const range = normalizeRange(p.get('range'));

  let rows: Record<string, unknown>[] = [];
  try {
    if (dataset === 'alerts') {
      const { hits } = await getAlerts(session, { range, pageSize: 200, page: 0 });
      // single page of 200 for export preview; cap defensive at MAX_RECORDS
      rows = hits.slice(0, MAX_RECORDS).map((h) => ({
        timestamp: h._source?.timestamp,
        agent: h._source?.agent?.name,
        group: h._source?.agent?.labels?.group,
        level: h._source?.rule?.level,
        description: h._source?.rule?.description,
        srcip: h._source?.data?.srcip,
        country: h._source?.GeoLocation?.country_name,
      }));
    } else if (dataset === 'assets') {
      const group = session.is_admin ? null : session.group ?? null;
      const summary = await getAgentSummary(group);
      rows = summary.agents.slice(0, MAX_RECORDS).map((a) => ({
        name: a.name, id: a.id, ip: a.ip, status: a.status,
        group: a.group.join('|'), os: a.osName, platform: a.osPlatform,
        lastKeepAlive: a.lastKeepAlive, dateAdd: a.dateAdd,
      }));
    } else if (dataset === 'cti') {
      const events = await getMispEvents(Math.min(MAX_RECORDS, 200));
      rows = events.map((e) => ({
        id: e.id, info: e.info, date: e.date, threatLevel: e.threatLevel,
        org: e.org, tags: e.tags.join('|'), iocCount: e.iocCount,
      }));
    } else {
      return NextResponse.json({ error: 'Unknown dataset' }, { status: 400 });
    }
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 502 });
  }

  await audit({ username: session.sub, action: 'export', resource: dataset, details: { format, count: rows.length } });

  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `prime-soc-${dataset}-${stamp}.${format}`;

  if (format === 'json') {
    return new NextResponse(JSON.stringify(rows, null, 2), {
      headers: {
        'Content-Type': 'application/json',
        'Content-Disposition': `attachment; filename="${filename}"`,
      },
    });
  }
  return new NextResponse(toCsv(rows), {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="${filename}"`,
    },
  });
}
