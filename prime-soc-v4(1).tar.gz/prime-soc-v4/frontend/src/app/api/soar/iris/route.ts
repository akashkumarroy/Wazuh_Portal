import { NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { getIrisCases } from '@/lib/soar';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  // getIrisCases never throws; returns reachable:false + empty on timeout.
  return NextResponse.json(await getIrisCases());
}
