import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createIrisCase } from '@/lib/soar';
import { audit, createIncident, attachIrisCase } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// One-click IRIS case creation from an alert/incident. IRIS may be unreachable
// (WireGuard) — createIrisCase fails gracefully, and we still record a local
// incident so nothing is lost.
export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Malformed body' }, { status: 400 });
  }

  const name = String(body?.name || '').trim();
  const description = String(body?.description || '').trim();
  const severity = Number(body?.severity ?? 5);
  const alertIds: string[] = Array.isArray(body?.alertIds) ? body.alertIds.map(String) : [];
  if (!name) return NextResponse.json({ error: 'Case name required' }, { status: 400 });

  // Record a local incident first (always succeeds if DB is up).
  let incidentId: string | null = null;
  try {
    const incident = await createIncident({
      tenant: session.is_admin ? (body?.tenant ?? null) : session.group,
      title: name,
      severity: String(severity),
      alertIds,
    });
    incidentId = incident.id;
  } catch {
    incidentId = null;
  }

  const result = await createIrisCase({ name, severity, description });

  if (result.ok && result.caseId && incidentId) {
    try { await attachIrisCase(incidentId, result.caseId); } catch { /* noop */ }
  }

  await audit({
    username: session.sub,
    action: 'iris_case_create',
    resource: result.caseId ?? incidentId ?? name,
    details: { irisOk: result.ok, detail: result.detail, alertIds },
  });

  return NextResponse.json({
    ok: result.ok,
    irisCaseId: result.caseId,
    incidentId,
    detail: result.detail,
    // 200 even when IRIS is down: the local incident is still captured.
  });
}
