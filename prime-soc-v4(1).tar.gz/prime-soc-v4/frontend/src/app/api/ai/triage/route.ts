import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { triageAlert, aiConfigured } from '@/lib/ai';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  if (!aiConfigured()) {
    return NextResponse.json({ error: 'AI triage is not configured (set ANTHROPIC_API_KEY).' }, { status: 503 });
  }
  try {
    const body = await req.json();
    const alert = body?.alert;
    if (!alert || typeof alert !== 'object') {
      return NextResponse.json({ error: 'Missing alert' }, { status: 400 });
    }
    const analysis = await triageAlert(alert);
    return NextResponse.json({ analysis });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 502 });
  }
}
