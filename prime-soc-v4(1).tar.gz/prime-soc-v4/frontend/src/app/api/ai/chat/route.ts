import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { streamAssistant, aiConfigured, type ChatMessage, type AssistantContext } from '@/lib/ai';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  if (!aiConfigured()) {
    return NextResponse.json({ error: 'AI assistant is not configured (set ANTHROPIC_API_KEY).' }, { status: 503 });
  }

  let messages: ChatMessage[] = [];
  let page = 'unknown';
  let criticalAlerts: AssistantContext['criticalAlerts'] = [];
  try {
    const body = await req.json();
    messages = Array.isArray(body?.messages) ? body.messages : [];
    page = String(body?.page ?? 'unknown');
    criticalAlerts = Array.isArray(body?.criticalAlerts) ? body.criticalAlerts.slice(0, 5) : [];
  } catch {
    return NextResponse.json({ error: 'Malformed body' }, { status: 400 });
  }

  const ctx: AssistantContext = { group: session.group, page, criticalAlerts };
  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    async start(controller) {
      try {
        for await (const delta of streamAssistant(messages, ctx)) {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify({ text: delta })}\n\n`));
        }
        controller.enqueue(encoder.encode('data: [DONE]\n\n'));
      } catch (e) {
        controller.enqueue(encoder.encode(`data: ${JSON.stringify({ error: (e as Error).message })}\n\n`));
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
    },
  });
}
