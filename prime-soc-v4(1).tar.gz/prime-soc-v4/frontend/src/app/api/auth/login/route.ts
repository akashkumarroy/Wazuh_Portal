import { NextRequest, NextResponse } from 'next/server';
import {
  validateWazuhCredentials,
  buildSession,
  signSession,
  SESSION_COOKIE,
  sessionCookieMaxAge,
} from '@/lib/auth';
import { recordSession, audit } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const INVALID = 'Invalid credentials. Check your Wazuh username and password.';

export async function POST(req: NextRequest) {
  let username = '';
  let password = '';
  try {
    const body = await req.json();
    username = String(body?.username ?? '').trim();
    password = String(body?.password ?? '');
  } catch {
    return NextResponse.json({ error: 'Malformed request body.' }, { status: 400 });
  }

  if (!username || !password) {
    return NextResponse.json({ error: INVALID }, { status: 401 });
  }

  let account;
  try {
    account = await validateWazuhCredentials(username, password);
  } catch (e) {
    return NextResponse.json(
      { error: 'Authentication service unavailable. Please try again.' },
      { status: 503 },
    );
  }

  if (!account) {
    return NextResponse.json({ error: INVALID }, { status: 401 });
  }

  const session = buildSession(account);
  const token = await signSession(session);
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || null;

  // Best-effort persistence; never block login on DB issues.
  try {
    const expiresAt = new Date(Date.now() + sessionCookieMaxAge() * 1000);
    await recordSession({
      username: session.sub,
      role: session.role,
      isAdmin: session.is_admin,
      group: session.group,
      ip,
      expiresAt,
    });
    await audit({ username: session.sub, action: 'login', ip, details: { role: session.role } });
  } catch {
    /* ignore */
  }

  const res = NextResponse.json({
    ok: true,
    user: { username: session.sub, role: session.role, is_admin: session.is_admin, group: session.group },
  });
  res.cookies.set(SESSION_COOKIE, token, {
    httpOnly: true,
    // Secure cookies require HTTPS. Default ON in production, but allow
    // explicitly disabling for HTTP-only deployments via COOKIE_SECURE=false.
    secure: process.env.COOKIE_SECURE
      ? process.env.COOKIE_SECURE === 'true'
      : process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: sessionCookieMaxAge(),
  });
  return res;
}
