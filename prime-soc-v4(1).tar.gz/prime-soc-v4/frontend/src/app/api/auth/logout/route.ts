import { NextResponse } from 'next/server';
import { SESSION_COOKIE, getSession } from '@/lib/auth';
import { audit } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST() {
  const session = await getSession();
  if (session) {
    await audit({ username: session.sub, action: 'logout' });
  }
  const res = NextResponse.json({ ok: true });
  res.cookies.set(SESSION_COOKIE, '', { httpOnly: true, path: '/', maxAge: 0 });
  return res;
}
