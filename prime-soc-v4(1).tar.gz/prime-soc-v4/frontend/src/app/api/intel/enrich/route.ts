import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { mispLookup, getIndicators } from '@/lib/intel';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// IOC enrichment: given an indicator value (IP/domain/hash), check MISP for
// matching attributes and surface any OpenCTI indicator overlap. Degrades to a
// "not found" result rather than erroring so the UI can always render.
export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const value = (req.nextUrl.searchParams.get('value') || '').trim();
  if (!value) return NextResponse.json({ error: 'Missing value' }, { status: 400 });

  const misp = await mispLookup(value);

  // Best-effort OpenCTI overlap: scan a recent indicator slice for the value.
  let ctiMatch = false;
  try {
    const indicators = await getIndicators(100);
    ctiMatch = indicators.some(
      (i) => (i.name && i.name.includes(value)) || (i.pattern && i.pattern.includes(value)),
    );
  } catch {
    ctiMatch = false;
  }

  const verdict = misp.found || ctiMatch ? 'known' : 'unknown';
  return NextResponse.json({
    value,
    verdict,
    misp: { found: misp.found, count: misp.count },
    opencti: { matched: ctiMatch },
  });
}
