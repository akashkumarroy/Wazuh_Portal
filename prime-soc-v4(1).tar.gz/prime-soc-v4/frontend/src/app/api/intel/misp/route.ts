import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { getMispSummary } from '@/lib/intel';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const limit = Math.min(100, Number(req.nextUrl.searchParams.get('limit') ?? 30) || 30);
  // MISP failures degrade to empty rather than erroring the page.
  const summary = await getMispSummary(limit);
  return NextResponse.json(summary);
}
