import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { getCtiCounts, getThreatActors, getIndicators } from '@/lib/intel';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const view = req.nextUrl.searchParams.get('view') ?? 'overview';
  try {
    if (view === 'actors') return NextResponse.json({ actors: await getThreatActors(48) });
    if (view === 'indicators') return NextResponse.json({ indicators: await getIndicators(100) });
    // overview: counts only (fast); feed/donut come from MISP route.
    return NextResponse.json({ counts: await getCtiCounts() });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 502 });
  }
}
