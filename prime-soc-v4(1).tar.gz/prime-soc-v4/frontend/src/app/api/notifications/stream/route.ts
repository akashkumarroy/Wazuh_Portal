import { NextRequest } from 'next/server';
import { getSession } from '@/lib/auth';
import { getAlerts } from '@/lib/wazuh';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// Server-Sent Events: emit the latest critical alerts every 30s. The TopBar
// bell consumes this. Tenant scope is applied via the session.
export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session) return new Response('Unauthorized', { status: 401 });

  const encoder = new TextEncoder();
  let closed = false;
  req.signal.addEventListener('abort', () => { closed = true; });

  const stream = new ReadableStream({
    async start(controller) {
      const send = (obj: unknown) =>
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(obj)}\n\n`));

      const poll = async () => {
        try {
          const { hits } = await getAlerts(session, {
            range: '24h',
            pageSize: 10,
            minLevel: 13, // critical
          });
          send({
            type: 'criticals',
            count: hits.length,
            alerts: hits.map((h) => ({
              id: h._id,
              agent: h._source?.agent?.name ?? '',
              description: h._source?.rule?.description ?? '',
              level: h._source?.rule?.level ?? 0,
              timestamp: h._source?.timestamp ?? '',
            })),
          });
        } catch (e) {
          send({ type: 'error', detail: (e as Error).message });
        }
      };

      await poll();
      const interval = setInterval(async () => {
        if (closed) { clearInterval(interval); controller.close(); return; }
        await poll();
      }, 30_000);
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
    },
  });
}
