import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { getFim, normalizeRange } from '@/lib/wazuh';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const p = req.nextUrl.searchParams;
  const page = p.get('page') ? Number(p.get('page')) : 0;
  try {
    return NextResponse.json(await getFim(session, normalizeRange(p.get('range')), page));
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 502 });
  }
}
