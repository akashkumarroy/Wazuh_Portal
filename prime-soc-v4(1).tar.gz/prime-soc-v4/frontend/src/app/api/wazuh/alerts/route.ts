import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { getAlerts, normalizeRange } from '@/lib/wazuh';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const p = req.nextUrl.searchParams;
  const num = (k: string) => (p.get(k) != null ? Number(p.get(k)) : undefined);
  try {
    const data = await getAlerts(session, {
      range: normalizeRange(p.get('range')),
      page: num('page'),
      pageSize: num('pageSize'),
      search: p.get('search') ?? undefined,
      minLevel: num('minLevel'),
      maxLevel: num('maxLevel'),
      ruleGroup: p.get('ruleGroup') ?? undefined,
      mitreTagged: p.get('mitreTagged') === 'true' ? true : undefined,
    });
    return NextResponse.json(data);
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 502 });
  }
}
