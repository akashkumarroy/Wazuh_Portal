import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { getAgentSummary } from '@/lib/wazuh';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const group = session.is_admin ? null : session.group ?? null;
  try {
    const data = await getAgentSummary(group);
    return NextResponse.json(data);
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 502 });
  }
}
