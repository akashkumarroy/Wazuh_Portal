import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { getCompliance, normalizeRange, type ComplianceFramework } from '@/lib/wazuh';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const FRAMEWORKS: ComplianceFramework[] = ['pci_dss', 'gdpr', 'hipaa', 'nist_800_53', 'tsc', 'gpg13'];

export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const p = req.nextUrl.searchParams;
  const fw = (p.get('framework') ?? 'pci_dss') as ComplianceFramework;
  if (!FRAMEWORKS.includes(fw)) {
    return NextResponse.json({ error: 'Unknown framework' }, { status: 400 });
  }
  try {
    return NextResponse.json(await getCompliance(session, fw, normalizeRange(p.get('range'))));
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 502 });
  }
}
