import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { getTenantDetail, normalizeRange } from '@/lib/wazuh';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest, { params }: { params: { group: string } }) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  if (!session.is_admin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  const range = normalizeRange(req.nextUrl.searchParams.get('range') ?? '30d');
  try {
    const data = await getTenantDetail(decodeURIComponent(params.group), range);
    return NextResponse.json(data);
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 502 });
  }
}
