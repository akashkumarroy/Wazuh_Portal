import { NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { getSecurityUsers } from '@/lib/wazuh';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  if (!session.is_admin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  try {
    const users = await getSecurityUsers();
    return NextResponse.json({ users });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 502 });
  }
}
