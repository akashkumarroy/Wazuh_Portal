import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { getAlertById } from '@/lib/wazuh';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const hit = await getAlertById(session, params.id);
    if (!hit) return NextResponse.json({ error: 'Not found' }, { status: 404 });
    return NextResponse.json(hit);
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 502 });
  }
}
