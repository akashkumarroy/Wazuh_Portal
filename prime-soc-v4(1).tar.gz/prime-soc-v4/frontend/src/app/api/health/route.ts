import { NextResponse } from 'next/server';
import { pingIndexer } from '@/lib/wazuh';
import { pingDb } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// Liveness for the Docker healthcheck (curl). Always 200 with a body so the
// container is "healthy" as soon as Next is serving; dependency detail is in
// the payload for /settings to consume.
export async function GET() {
  const [indexer, db] = [await pingIndexer(), await pingDb()];
  return NextResponse.json({
    status: 'ok',
    time: new Date().toISOString(),
    services: { indexer, db },
  });
}
