'use client';

import {
  PieChart, Pie, Cell, ResponsiveContainer,
  AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid,
} from 'recharts';
import { SEVERITY_COLORS, type Severity, formatNumber, axisTimeFormatter } from '@/lib/format';

const TOOLTIP_STYLE = {
  background: '#0d1117',
  border: '1px solid rgba(255,255,255,0.1)',
  borderRadius: 8,
  fontSize: 11,
  color: '#f1f5f9',
};

export function SectionTitle({ children, right }: { children: React.ReactNode; right?: React.ReactNode }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
      <div className="card-title">{children}</div>
      {right}
    </div>
  );
}

export function StatCard({
  label, value, accent, sub,
}: {
  label: string;
  value: string | number;
  accent?: string;
  sub?: string;
}) {
  return (
    <div className="card card-pad anim-slide-up" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <div className="card-title">{label}</div>
      <div className="stat-value" style={{ fontSize: 26, color: accent || 'var(--text-primary)', lineHeight: 1 }}>
        {typeof value === 'number' ? formatNumber(value) : value}
      </div>
      {sub && <div style={{ fontSize: 10.5, color: 'var(--text-secondary)' }}>{sub}</div>}
    </div>
  );
}

export function BarList({
  items, color = 'var(--cyan)', valueFormat = formatNumber, emptyText = 'No data in range',
}: {
  items: { key: string; count: number }[];
  color?: string;
  valueFormat?: (n: number) => string;
  emptyText?: string;
}) {
  if (!items || items.length === 0) {
    return <div style={{ fontSize: 11, color: 'var(--text-dim)', padding: '12px 0' }}>{emptyText}</div>;
  }
  const max = Math.max(...items.map((i) => i.count), 1);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
      {items.map((it) => (
        <div key={it.key}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3, gap: 8 }}>
            <span style={{ fontSize: 11.5, color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {it.key || '(unknown)'}
            </span>
            <span className="mono" style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{valueFormat(it.count)}</span>
          </div>
          <div className="bar-track">
            <div className="bar-fill" style={{ width: `${(it.count / max) * 100}%`, background: color }} />
          </div>
        </div>
      ))}
    </div>
  );
}

export function SeverityDonut({ severity }: { severity: Record<Severity, number> }) {
  const order: Severity[] = ['critical', 'high', 'medium', 'low', 'info'];
  const data = order.map((s) => ({ name: s, value: severity?.[s] ?? 0 }));
  const total = data.reduce((a, b) => a + b.value, 0);

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
      <div style={{ width: 130, height: 130, position: 'relative' }}>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie data={data} dataKey="value" nameKey="name" innerRadius={42} outerRadius={62} paddingAngle={2} stroke="none">
              {data.map((d) => <Cell key={d.name} fill={SEVERITY_COLORS[d.name as Severity]} />)}
            </Pie>
            <Tooltip contentStyle={TOOLTIP_STYLE} formatter={(v: any, n: any) => [formatNumber(v), n]} />
          </PieChart>
        </ResponsiveContainer>
        <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none' }}>
          <div className="stat-value" style={{ fontSize: 18 }}>{formatNumber(total)}</div>
          <div style={{ fontSize: 8.5, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>total</div>
        </div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 5, flex: 1 }}>
        {order.map((s) => (
          <div key={s} style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 11 }}>
            <span style={{ width: 9, height: 9, borderRadius: 2, background: SEVERITY_COLORS[s] }} />
            <span style={{ textTransform: 'capitalize', flex: 1, color: 'var(--text-secondary)' }}>{s}</span>
            <span className="mono" style={{ color: 'var(--text-primary)' }}>{formatNumber(severity?.[s] ?? 0)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function TimeSeriesArea({
  data, range, series, height = 200,
}: {
  data: any[];
  range: string;
  series: { key: string; color: string; label: string }[];
  height?: number;
}) {
  if (!data || data.length === 0) {
    return <div style={{ fontSize: 11, color: 'var(--text-dim)', padding: '24px 0', textAlign: 'center' }}>No time-series data in range</div>;
  }
  const fmt = axisTimeFormatter(range);
  return (
    <div style={{ width: '100%', height }}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 6, right: 8, bottom: 0, left: -16 }}>
          <defs>
            {series.map((s) => (
              <linearGradient key={s.key} id={`grad-${s.key}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={s.color} stopOpacity={0.35} />
                <stop offset="100%" stopColor={s.color} stopOpacity={0} />
              </linearGradient>
            ))}
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" vertical={false} />
          <XAxis dataKey="ts" tickFormatter={fmt} tick={{ fill: '#64748b', fontSize: 10 }} stroke="rgba(255,255,255,0.08)" minTickGap={28} />
          <YAxis tick={{ fill: '#64748b', fontSize: 10 }} stroke="rgba(255,255,255,0.08)" width={48} />
          <Tooltip
            contentStyle={TOOLTIP_STYLE}
            labelFormatter={(ms: any) => new Date(ms).toISOString().replace('T', ' ').replace(/\.\d+Z$/, 'Z')}
            formatter={(v: any, n: any) => [formatNumber(v), n]}
          />
          {series.map((s) => (
            <Area key={s.key} type="monotone" dataKey={s.key} name={s.label} stroke={s.color} strokeWidth={1.6} fill={`url(#grad-${s.key})`} dot={false} />
          ))}
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

export function Funnel({ stages }: { stages: { label: string; value: number; color: string }[] }) {
  if (!stages.length || stages.every((s) => s.value === 0)) {
    return <div style={{ fontSize: 11, color: 'var(--text-dim)', padding: '16px 0' }}>No processing statistics available</div>;
  }
  const max = Math.max(...stages.map((s) => s.value), 1);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      {stages.map((s, i) => {
        const pct = (s.value / max) * 100;
        const prev = i > 0 ? stages[i - 1].value : null;
        const drop = prev != null && prev > 0 ? Math.round(((prev - s.value) / prev) * 100) : null;
        return (
          <div key={s.label}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
              <span style={{ fontSize: 11.5 }}>{s.label}</span>
              <span className="mono" style={{ fontSize: 11, color: 'var(--text-secondary)' }}>
                {formatNumber(s.value)}{drop != null ? `  (−${drop}%)` : ''}
              </span>
            </div>
            <div style={{ height: 22, background: 'rgba(255,255,255,0.04)', borderRadius: 6, overflow: 'hidden' }}>
              <div style={{ width: `${pct}%`, height: '100%', background: `linear-gradient(90deg, ${s.color}, ${s.color}aa)`, borderRadius: 6, transition: 'width 0.4s ease' }} />
            </div>
          </div>
        );
      })}
    </div>
  );
}

export function EmptyState({ title, detail }: { title: string; detail?: string }) {
  return (
    <div style={{ textAlign: 'center', padding: '40px 16px', color: 'var(--text-secondary)' }}>
      <div style={{ fontSize: 28, opacity: 0.3, marginBottom: 8 }}>∅</div>
      <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>{title}</div>
      {detail && <div style={{ fontSize: 11, marginTop: 4 }}>{detail}</div>}
    </div>
  );
}

export function SkeletonCard({ height = 90 }: { height?: number }) {
  return <div className="skeleton" style={{ height, width: '100%' }} />;
}

export function ErrorBanner({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="card card-pad card-static" style={{ borderColor: 'rgba(239,68,68,0.3)', background: 'rgba(239,68,68,0.06)' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
        <div>
          <div style={{ fontSize: 12, fontWeight: 600, color: '#fca5a5' }}>Could not load data</div>
          <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginTop: 2 }}>{message}</div>
        </div>
        {onRetry && <button className="btn btn-ghost" onClick={onRetry}>Retry</button>}
      </div>
    </div>
  );
}

export function Grid({ cols, gap = 14, children }: { cols: string; gap?: number; children: React.ReactNode }) {
  return <div style={{ display: 'grid', gridTemplateColumns: cols, gap }}>{children}</div>;
}
