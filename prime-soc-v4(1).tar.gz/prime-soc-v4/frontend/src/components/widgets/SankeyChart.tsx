'use client';

import { useEffect, useRef, useState } from 'react';
import { sankey, sankeyLinkHorizontal } from 'd3-sankey';

interface SankeyInput {
  nodes: { name: string }[];
  links: { source: number; target: number; value: number }[];
}

const COLUMN_COLORS = ['#00d8e8', '#7c3aed', '#3b82f6', '#10b981'];

export default function SankeyChart({ data, height = 420 }: { data: SankeyInput; height?: number }) {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const [width, setWidth] = useState(800);

  useEffect(() => {
    if (!wrapRef.current) return;
    const ro = new ResizeObserver((entries) => {
      const w = entries[0]?.contentRect?.width;
      if (w) setWidth(Math.max(320, Math.floor(w)));
    });
    ro.observe(wrapRef.current);
    return () => ro.disconnect();
  }, []);

  if (!data || data.nodes.length === 0 || data.links.length === 0) {
    return (
      <div ref={wrapRef} style={{ fontSize: 12, color: 'var(--text-dim)', textAlign: 'center', padding: '48px 0' }}>
        No malware-tagged flow in the selected range.
      </div>
    );
  }

  // d3-sankey mutates its input; deep-copy first.
  const graph = {
    nodes: data.nodes.map((n) => ({ ...n })),
    links: data.links.map((l) => ({ ...l })),
  };

  let layout;
  try {
    const generator = sankey<any, any>()
      .nodeWidth(14)
      .nodePadding(12)
      .extent([[1, 8], [width - 1, height - 8]]);
    layout = generator(graph as any);
  } catch {
    return (
      <div ref={wrapRef} style={{ fontSize: 12, color: 'var(--text-dim)', textAlign: 'center', padding: '48px 0' }}>
        Flow graph could not be rendered (cyclic or disconnected data).
      </div>
    );
  }

  const { nodes, links } = layout as any;

  return (
    <div ref={wrapRef} style={{ width: '100%', overflowX: 'auto' }}>
      <svg width={width} height={height} style={{ display: 'block' }}>
        <g>
          {links.map((l: any, i: number) => {
            const color = COLUMN_COLORS[(l.source.depth ?? 0) % COLUMN_COLORS.length];
            return (
              <path
                key={i}
                d={sankeyLinkHorizontal()(l) as string}
                fill="none"
                stroke={color}
                strokeOpacity={0.22}
                strokeWidth={Math.max(1, l.width)}
              >
                <title>{`${l.source.name} → ${l.target.name}: ${l.value.toLocaleString()}`}</title>
              </path>
            );
          })}
        </g>
        <g>
          {nodes.map((n: any, i: number) => {
            const color = COLUMN_COLORS[(n.depth ?? 0) % COLUMN_COLORS.length];
            const nodeHeight = Math.max(2, n.y1 - n.y0);
            const labelLeft = n.x0 < width / 2;
            return (
              <g key={i}>
                <rect x={n.x0} y={n.y0} width={n.x1 - n.x0} height={nodeHeight} fill={color} rx={2}>
                  <title>{`${n.name}: ${(n.value ?? 0).toLocaleString()}`}</title>
                </rect>
                <text
                  x={labelLeft ? n.x1 + 6 : n.x0 - 6}
                  y={(n.y0 + n.y1) / 2}
                  dy="0.35em"
                  textAnchor={labelLeft ? 'start' : 'end'}
                  fill="#cbd5e1"
                  fontSize={10.5}
                  style={{ fontFamily: 'Inter, sans-serif' }}
                >
                  {n.name}
                </text>
              </g>
            );
          })}
        </g>
      </svg>
    </div>
  );
}
