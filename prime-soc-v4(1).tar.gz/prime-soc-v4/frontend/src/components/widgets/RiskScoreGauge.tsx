'use client';

import { useEffect, useState } from 'react';

/**
 * Composite risk gauge. Pure SVG (no chart lib) semicircular arc that animates
 * from 0 to the target score. Score is 0-100; color bands: <40 green, <70 amber,
 * else red. Caller computes the score from live signals (severity mix, agent
 * health, critical volume).
 */

function band(score: number): { color: string; label: string } {
  if (score >= 70) return { color: '#ef4444', label: 'Critical' };
  if (score >= 40) return { color: '#f59e0b', label: 'Elevated' };
  if (score >= 20) return { color: '#eab308', label: 'Guarded' };
  return { color: '#10b981', label: 'Low' };
}

export default function RiskScoreGauge({
  score, size = 180, title = 'Risk Score', sub,
}: {
  score: number;
  size?: number;
  title?: string;
  sub?: string;
}) {
  const target = Math.max(0, Math.min(100, Math.round(score)));
  const [shown, setShown] = useState(0);

  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const from = shown;
    const dur = 700;
    const step = (t: number) => {
      const p = Math.min(1, (t - start) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      setShown(Math.round(from + (target - from) * eased));
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [target]);

  const { color, label } = band(shown);
  const stroke = 14;
  const r = (size - stroke) / 2;
  const cx = size / 2;
  const cy = size / 2;
  // Semicircle: 180deg sweep from left (180) to right (0).
  const circumference = Math.PI * r;
  const offset = circumference * (1 - shown / 100);

  const polar = (deg: number) => {
    const rad = (deg * Math.PI) / 180;
    return [cx + r * Math.cos(rad), cy - r * Math.sin(rad)];
  };
  const [sx, sy] = polar(180);
  const [ex, ey] = polar(0);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
      <svg width={size} height={size / 2 + 24} viewBox={`0 0 ${size} ${size / 2 + 24}`}>
        {/* track */}
        <path d={`M ${sx} ${sy} A ${r} ${r} 0 0 1 ${ex} ${ey}`} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth={stroke} strokeLinecap="round" />
        {/* value arc */}
        <path
          d={`M ${sx} ${sy} A ${r} ${r} 0 0 1 ${ex} ${ey}`}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: 'stroke 0.3s ease' }}
        />
        <text x={cx} y={cy - 4} textAnchor="middle" className="mono" style={{ fill: 'var(--text-primary)', fontSize: size * 0.22, fontWeight: 700 }}>
          {shown}
        </text>
        <text x={cx} y={cy + 14} textAnchor="middle" style={{ fill: color, fontSize: 11, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
          {label}
        </text>
      </svg>
      <div className="card-title">{title}</div>
      {sub && <div style={{ fontSize: 10, color: 'var(--text-secondary)' }}>{sub}</div>}
    </div>
  );
}

/**
 * Derive a 0-100 composite risk score from live dashboard signals.
 * Weighted: critical alerts dominate, then high, then agent health deficit.
 */
export function computeRiskScore(input: {
  critical: number;
  high: number;
  total: number;
  agentHealthPct: number;
}): number {
  const { critical, high, total, agentHealthPct } = input;
  if (total <= 0) return 0;
  const critRatio = Math.min(1, critical / Math.max(1, total * 0.02)); // 2% critical => maxed
  const highRatio = Math.min(1, high / Math.max(1, total * 0.1));       // 10% high => maxed
  const healthDeficit = Math.max(0, (100 - agentHealthPct) / 100);
  const score = critRatio * 55 + highRatio * 30 + healthDeficit * 15;
  return Math.round(Math.max(0, Math.min(100, score)));
}
