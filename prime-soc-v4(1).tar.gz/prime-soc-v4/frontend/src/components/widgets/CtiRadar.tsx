'use client';

import { Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer } from 'recharts';

export default function CtiRadar({ data, height = 220 }: { data: { axis: string; value: number }[]; height?: number }) {
  if (!data || data.length === 0 || data.every((d) => d.value === 0)) {
    return <div style={{ fontSize: 11, color: 'var(--text-dim)', textAlign: 'center', padding: '40px 0' }}>No CTI category data</div>;
  }
  return (
    <div style={{ width: '100%', height }}>
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart data={data} outerRadius="72%">
          <PolarGrid stroke="rgba(255,255,255,0.08)" />
          <PolarAngleAxis dataKey="axis" tick={{ fill: '#94a3b8', fontSize: 10 }} />
          <Radar dataKey="value" stroke="#00d8e8" fill="#00d8e8" fillOpacity={0.28} strokeWidth={1.6} />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}
