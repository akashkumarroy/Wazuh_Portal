'use client';

import { type AlertHit, severityFromLevel, severityBadgeClass, formatTs, timeAgo, get } from '@/lib/format';

interface Column {
  key: string;
  label: string;
}

const DEFAULT_COLUMNS: Column[] = [
  { key: 'time', label: 'Time' },
  { key: 'sev', label: 'Severity' },
  { key: 'agent', label: 'Agent' },
  { key: 'description', label: 'Rule' },
  { key: 'srcip', label: 'Source IP' },
];

export default function AlertsTable({
  hits, onSelect, showGroup = false, compact = false, emptyText = 'No alerts in range',
}: {
  hits: AlertHit[];
  onSelect: (hit: AlertHit) => void;
  showGroup?: boolean;
  compact?: boolean;
  emptyText?: string;
}) {
  if (!hits || hits.length === 0) {
    return <div style={{ fontSize: 11, color: 'var(--text-dim)', padding: '20px 0', textAlign: 'center' }}>{emptyText}</div>;
  }

  return (
    <div style={{ overflowX: 'auto' }}>
      <table className="data-table">
        <thead>
          <tr>
            <th>Time</th>
            <th>Severity</th>
            <th>Agent</th>
            {showGroup && <th>Group</th>}
            <th>Rule</th>
            {!compact && <th>Source IP</th>}
            {!compact && <th>Country</th>}
          </tr>
        </thead>
        <tbody>
          {hits.map((h) => {
            const sev = severityFromLevel(get(h._source, 'rule.level'));
            return (
              <tr key={h._id} onClick={() => onSelect(h)}>
                <td className="mono" style={{ whiteSpace: 'nowrap', color: 'var(--text-secondary)' }} title={formatTs(get(h._source, 'timestamp'))}>
                  {timeAgo(get(h._source, 'timestamp'))}
                </td>
                <td>
                  <span className={severityBadgeClass(sev)} style={{ textTransform: 'capitalize' }}>
                    {sev} · {get(h._source, 'rule.level') ?? 0}
                  </span>
                </td>
                <td style={{ whiteSpace: 'nowrap' }}>{get(h._source, 'agent.name') || '—'}</td>
                {showGroup && <td>{get(h._source, 'agent.labels.group') || <span className="text-dim">none</span>}</td>}
                <td style={{ maxWidth: 360, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {get(h._source, 'rule.description') || '—'}
                </td>
                {!compact && <td className="mono" style={{ color: 'var(--text-secondary)' }}>{get(h._source, 'data.srcip') || '—'}</td>}
                {!compact && <td style={{ color: 'var(--text-secondary)' }}>{get(h._source, 'GeoLocation.country_name') || '—'}</td>}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
