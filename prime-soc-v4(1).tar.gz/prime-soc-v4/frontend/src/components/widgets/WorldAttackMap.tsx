'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import * as d3 from 'd3';
import { feature } from 'topojson-client';

export interface GeoPoint {
  country: string;
  city: string;
  lat: number;
  lon: number;
  count: number;
  topRule: string;
}

interface Props {
  points: GeoPoint[];
  byCountry: { key: string; count: number }[];
  height?: number;
}

// Approx centroids for the heaviest-traffic countries so the choropleth can
// shade even when only country_name (no geo_point) is available. The live arcs
// still use the precise geo_point centroids from `points`.
const COUNTRY_CENTROIDS: Record<string, [number, number]> = {
  'United States': [-98, 39], 'China': [104, 35], 'Russia': [90, 61], 'India': [79, 22],
  'Germany': [10, 51], 'Netherlands': [5, 52], 'France': [2, 46], 'United Kingdom': [-2, 54],
  'Brazil': [-51, -10], 'Singapore': [103, 1], 'Japan': [138, 36], 'South Korea': [127, 36],
  'Vietnam': [108, 14], 'Indonesia': [113, -1], 'Ukraine': [31, 49], 'Iran': [53, 32],
  'Canada': [-106, 56], 'Hong Kong': [114, 22], 'Bulgaria': [25, 42], 'Romania': [25, 45],
};

export default function WorldAttackMap({ points, byCountry, height = 420 }: Props) {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const [width, setWidth] = useState(900);
  const [topo, setTopo] = useState<any>(null);
  const [hover, setHover] = useState<{ x: number; y: number; label: string } | null>(null);
  const [tick, setTick] = useState(0);

  // Responsive width
  useEffect(() => {
    if (!wrapRef.current) return;
    const ro = new ResizeObserver((e) => {
      const w = e[0]?.contentRect?.width;
      if (w) setWidth(Math.max(360, Math.floor(w)));
    });
    ro.observe(wrapRef.current);
    return () => ro.disconnect();
  }, []);

  // Load vendored topology once
  useEffect(() => {
    let alive = true;
    fetch('/geo/countries-110m.json', { cache: 'force-cache' })
      .then((r) => r.json())
      .then((d) => { if (alive) setTopo(d); })
      .catch(() => { if (alive) setTopo(null); });
    return () => { alive = false; };
  }, []);

  // Pulse animation clock
  useEffect(() => {
    const id = setInterval(() => setTick((t) => (t + 1) % 1000), 90);
    return () => clearInterval(id);
  }, []);

  const projection = useMemo(
    () => d3.geoEquirectangular().fitExtent([[2, 2], [width - 2, height - 2]], { type: 'Sphere' } as any),
    [width, height],
  );
  const path = useMemo(() => d3.geoPath(projection as any), [projection]);

  const countries = useMemo(() => {
    if (!topo) return [];
    try {
      const fc = feature(topo, topo.objects.countries) as any;
      return fc.features as any[];
    } catch {
      return [];
    }
  }, [topo]);

  const countByName = useMemo(() => {
    const m = new Map<string, number>();
    for (const c of byCountry) m.set(c.key, c.count);
    return m;
  }, [byCountry]);

  const maxCountry = Math.max(1, ...byCountry.map((c) => c.count));
  const colorScale = useMemo(
    () => d3.scaleSequential(d3.interpolate('#0f2030', '#00d8e8')).domain([0, Math.log1p(maxCountry)]),
    [maxCountry],
  );

  // Build arcs from the densest source points to a notional SOC hub (India).
  const HUB: [number, number] = [88.36, 22.57]; // Kolkata
  const arcs = useMemo(() => {
    const top = [...points].sort((a, b) => b.count - a.count).slice(0, 40);
    return top
      .map((p) => {
        const s = projection([p.lon, p.lat]);
        const t = projection(HUB);
        if (!s || !t) return null;
        return { s, t, count: p.count, label: `${p.city || p.country || 'Unknown'} → SOC · ${p.count.toLocaleString()}` };
      })
      .filter(Boolean) as { s: [number, number]; t: [number, number]; count: number; label: string }[];
  }, [points, projection]);

  const maxPoint = Math.max(1, ...points.map((p) => p.count));

  if (!topo) {
    return (
      <div ref={wrapRef} style={{ height, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-dim)', fontSize: 12 }}>
        Loading world topology…
      </div>
    );
  }

  return (
    <div ref={wrapRef} style={{ position: 'relative', width: '100%' }}>
      <svg width={width} height={height} style={{ display: 'block' }}>
        {/* graticule sphere */}
        <path d={path({ type: 'Sphere' } as any) || ''} fill="#070d16" stroke="rgba(255,255,255,0.05)" />

        {/* countries choropleth */}
        <g>
          {countries.map((c, i) => {
            const name = c.properties?.name ?? '';
            const count = countByName.get(name) ?? 0;
            const fill = count > 0 ? (colorScale(Math.log1p(count)) as string) : '#0d1828';
            return (
              <path
                key={i}
                d={path(c) || ''}
                fill={fill}
                stroke="rgba(255,255,255,0.06)"
                strokeWidth={0.4}
                onMouseEnter={(e) => {
                  const rect = wrapRef.current?.getBoundingClientRect();
                  setHover({ x: e.clientX - (rect?.left ?? 0), y: e.clientY - (rect?.top ?? 0), label: `${name}: ${count.toLocaleString()} alerts` });
                }}
                onMouseMove={(e) => {
                  const rect = wrapRef.current?.getBoundingClientRect();
                  setHover((h) => (h ? { ...h, x: e.clientX - (rect?.left ?? 0), y: e.clientY - (rect?.top ?? 0) } : h));
                }}
                onMouseLeave={() => setHover(null)}
              />
            );
          })}
        </g>

        {/* attack arcs */}
        <g>
          {arcs.map((a, i) => {
            const mx = (a.s[0] + a.t[0]) / 2;
            const my = (a.s[1] + a.t[1]) / 2 - Math.hypot(a.t[0] - a.s[0], a.t[1] - a.s[1]) * 0.18;
            const d = `M${a.s[0]},${a.s[1]} Q${mx},${my} ${a.t[0]},${a.t[1]}`;
            const w = 0.4 + (a.count / maxPoint) * 2.2;
            return (
              <path key={i} d={d} fill="none" stroke="#ef4444" strokeOpacity={0.28} strokeWidth={w}>
                <title>{a.label}</title>
              </path>
            );
          })}
        </g>

        {/* SOC hub */}
        {(() => {
          const h = projection(HUB);
          if (!h) return null;
          return (
            <g>
              <circle cx={h[0]} cy={h[1]} r={4} fill="#00d8e8" />
              <circle cx={h[0]} cy={h[1]} r={4 + (tick % 12)} fill="none" stroke="#00d8e8" strokeOpacity={0.5 - (tick % 12) / 24} />
            </g>
          );
        })()}

        {/* source markers (pulsing) */}
        <g>
          {points.slice(0, 120).map((p, i) => {
            const xy = projection([p.lon, p.lat]);
            if (!xy) return null;
            const base = 1.5 + (p.count / maxPoint) * 5;
            const pulse = ((tick + i * 7) % 14) / 14;
            return (
              <g key={i}>
                <circle cx={xy[0]} cy={xy[1]} r={base + pulse * 6} fill="#ef4444" fillOpacity={0.12 * (1 - pulse)} />
                <circle
                  cx={xy[0]} cy={xy[1]} r={base} fill="#ef4444" fillOpacity={0.8}
                  onMouseEnter={(e) => {
                    const rect = wrapRef.current?.getBoundingClientRect();
                    setHover({ x: e.clientX - (rect?.left ?? 0), y: e.clientY - (rect?.top ?? 0), label: `${p.city || p.country || 'Unknown'} · ${p.count.toLocaleString()} · ${p.topRule || ''}`.trim() });
                  }}
                  onMouseLeave={() => setHover(null)}
                />
              </g>
            );
          })}
        </g>
      </svg>

      {hover && (
        <div
          className="card"
          style={{
            position: 'absolute', left: Math.min(hover.x + 12, width - 220), top: hover.y + 12,
            pointerEvents: 'none', zIndex: 5, padding: '6px 9px', fontSize: 11, maxWidth: 220,
          }}
        >
          {hover.label}
        </div>
      )}

      {points.length === 0 && (
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-dim)', fontSize: 12, pointerEvents: 'none' }}>
          No geo-located attack sources in range
        </div>
      )}
    </div>
  );
}
