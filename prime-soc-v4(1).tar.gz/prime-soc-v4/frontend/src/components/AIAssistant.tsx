'use client';

import { useEffect, useRef, useState } from 'react';
import { usePathname } from 'next/navigation';
import { useSession } from '@/components/SessionContext';

interface Msg { role: 'user' | 'assistant'; content: string; }

const SUGGESTIONS = [
  'Summarize the current threat landscape',
  'What MITRE tactics are trending?',
  'How should I respond to a brute-force alert?',
];

export default function AIAssistant() {
  const pathname = usePathname();
  const user = useSession();
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState('');
  const [streaming, setStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, streaming]);

  useEffect(() => () => abortRef.current?.abort(), []);

  const pageName = (pathname || '/').split('/').filter(Boolean)[0] || 'dashboard';

  async function send(text: string) {
    const content = text.trim();
    if (!content || streaming) return;
    setError(null);
    setInput('');

    const nextMessages: Msg[] = [...messages, { role: 'user', content }];
    setMessages([...nextMessages, { role: 'assistant', content: '' }]);
    setStreaming(true);

    const controller = new AbortController();
    abortRef.current = controller;

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: nextMessages,
          page: pageName,
          criticalAlerts: [],
        }),
        signal: controller.signal,
      });

      if (res.status === 503) {
        setError('AI assistant is not configured on this deployment.');
        setMessages(nextMessages); // drop the empty assistant bubble
        setStreaming(false);
        return;
      }
      if (!res.ok || !res.body) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j?.error || `HTTP ${res.status}`);
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let assistantText = '';

      // Parse the text/event-stream: lines beginning with "data: ".
      // eslint-disable-next-line no-constant-condition
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith('data:')) continue;
          const payload = trimmed.slice(5).trim();
          if (payload === '[DONE]') continue;
          try {
            const obj = JSON.parse(payload);
            if (obj.error) { setError(obj.error); continue; }
            if (obj.text) {
              assistantText += obj.text;
              setMessages((prev) => {
                const copy = [...prev];
                copy[copy.length - 1] = { role: 'assistant', content: assistantText };
                return copy;
              });
            }
          } catch {
            /* ignore malformed chunk */
          }
        }
      }
    } catch (e) {
      if ((e as Error)?.name !== 'AbortError') setError((e as Error).message);
    } finally {
      setStreaming(false);
    }
  }

  return (
    <>
      {/* Launcher */}
      <button
        onClick={() => setOpen((o) => !o)}
        aria-label="AI assistant"
        style={{
          position: 'fixed', right: 20, bottom: 40, zIndex: 45,
          width: 52, height: 52, borderRadius: '50%', border: 'none', cursor: 'pointer',
          background: 'linear-gradient(135deg, #7c3aed, #00d8e8)',
          color: '#04121a', fontSize: 20, fontWeight: 700,
          boxShadow: '0 8px 28px rgba(124,58,237,0.45)',
          display: open ? 'none' : 'flex', alignItems: 'center', justifyContent: 'center',
        }}
      >
        ✦
      </button>

      {/* Panel */}
      {open && (
        <div
          className="anim-slide-in-right"
          style={{
            position: 'fixed', right: 20, bottom: 40, zIndex: 46,
            width: 380, maxWidth: '92vw', height: 560, maxHeight: '78vh',
            background: 'var(--bg-secondary)', border: '1px solid rgba(124,58,237,0.3)',
            borderRadius: 14, display: 'flex', flexDirection: 'column',
            boxShadow: '0 24px 70px rgba(0,0,0,0.55)', overflow: 'hidden',
          }}
        >
          {/* Header */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 14px', borderBottom: '1px solid var(--border)', background: 'rgba(124,58,237,0.08)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ width: 24, height: 24, borderRadius: 7, background: 'linear-gradient(135deg,#7c3aed,#00d8e8)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: '#04121a', fontWeight: 700 }}>✦</span>
              <div>
                <div style={{ fontSize: 12.5, fontWeight: 600 }}>SOC Assistant</div>
                <div style={{ fontSize: 9.5, color: 'var(--text-secondary)' }}>Context: {pageName}{user.is_admin ? ' · all tenants' : ` · ${user.group ?? ''}`}</div>
              </div>
            </div>
            <button className="btn btn-ghost" onClick={() => setOpen(false)} style={{ padding: '3px 8px' }}>✕</button>
          </div>

          {/* Messages */}
          <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', padding: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
            {messages.length === 0 && (
              <div style={{ color: 'var(--text-secondary)', fontSize: 12 }}>
                <div style={{ marginBottom: 10 }}>Ask about alerts, MITRE techniques, or incident response. The assistant sees your current page context.</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {SUGGESTIONS.map((s) => (
                    <button key={s} className="btn btn-ghost" onClick={() => send(s)} style={{ justifyContent: 'flex-start', fontSize: 11.5, textAlign: 'left' }}>{s}</button>
                  ))}
                </div>
              </div>
            )}
            {messages.map((m, i) => (
              <div key={i} style={{ display: 'flex', justifyContent: m.role === 'user' ? 'flex-end' : 'flex-start' }}>
                <div
                  style={{
                    maxWidth: '85%', padding: '8px 11px', borderRadius: 10, fontSize: 12, lineHeight: 1.5, whiteSpace: 'pre-wrap',
                    background: m.role === 'user' ? 'var(--cyan)' : 'var(--bg-card)',
                    color: m.role === 'user' ? '#04121a' : 'var(--text-primary)',
                    border: m.role === 'user' ? 'none' : '1px solid var(--border)',
                  }}
                >
                  {m.content || (streaming && i === messages.length - 1 ? <span className="pulse-dot">▍</span> : '')}
                </div>
              </div>
            ))}
            {error && <div style={{ fontSize: 11, color: '#fca5a5', background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.25)', borderRadius: 8, padding: '7px 9px' }}>{error}</div>}
          </div>

          {/* Composer */}
          <form
            onSubmit={(e) => { e.preventDefault(); send(input); }}
            style={{ borderTop: '1px solid var(--border)', padding: 10, display: 'flex', gap: 8 }}
          >
            <input
              className="input"
              placeholder="Ask the SOC assistant…"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              disabled={streaming}
            />
            <button type="submit" className="btn btn-primary" disabled={streaming || !input.trim()} style={{ opacity: streaming || !input.trim() ? 0.6 : 1 }}>
              {streaming ? '…' : 'Send'}
            </button>
          </form>
        </div>
      )}
    </>
  );
}
