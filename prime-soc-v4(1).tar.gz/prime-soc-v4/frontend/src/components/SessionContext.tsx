'use client';

import { createContext, useContext } from 'react';

export interface PortalUser {
  username: string;
  role: 'admin' | 'client';
  is_admin: boolean;
  group: string | null;
}

const SessionContext = createContext<PortalUser | null>(null);

export function SessionProvider({
  user,
  children,
}: {
  user: PortalUser;
  children: React.ReactNode;
}) {
  return <SessionContext.Provider value={user}>{children}</SessionContext.Provider>;
}

export function useSession(): PortalUser {
  const ctx = useContext(SessionContext);
  if (!ctx) {
    // Should never happen inside the (portal)/admin trees, which always wrap
    // their children in a SessionProvider seeded from the server session.
    return { username: 'unknown', role: 'client', is_admin: false, group: null };
  }
  return ctx;
}
