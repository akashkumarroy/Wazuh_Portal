'use client';

import { createContext, useContext, useState } from 'react';

export type TimeRange = '1h' | '6h' | '24h' | '7d' | '30d';

export const RANGE_LABELS: Record<TimeRange, string> = {
  '1h': 'Last 1 Hour',
  '6h': 'Last 6 Hours',
  '24h': 'Last 24 Hours',
  '7d': 'Last 7 Days',
  '30d': 'Last 30 Days',
};

interface TimeRangeCtx {
  range: TimeRange;
  setRange: (r: TimeRange) => void;
  label: string;
}

const Ctx = createContext<TimeRangeCtx | null>(null);

export function TimeRangeProvider({ children }: { children: React.ReactNode }) {
  const [range, setRange] = useState<TimeRange>('24h');
  return (
    <Ctx.Provider value={{ range, setRange, label: RANGE_LABELS[range] }}>
      {children}
    </Ctx.Provider>
  );
}

export function useTimeRange(): TimeRangeCtx {
  const ctx = useContext(Ctx);
  if (!ctx) return { range: '24h', setRange: () => {}, label: RANGE_LABELS['24h'] };
  return ctx;
}
