'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useSession } from '@/components/SessionContext';

interface NavItem {
  href: string;
  label: string;
  icon: string; // simple glyph; replaced by icon set later if desired
}

const PORTAL_NAV: NavItem[] = [
  { href: '/dashboard', label: 'Dashboard', icon: '▤' },
  { href: '/siem', label: 'SIEM', icon: '◫' },
  { href: '/threat-intel', label: 'Threat Intel', icon: '◎' },
  { href: '/soar', label: 'SOAR', icon: '⚙' },
  { href: '/assets', label: 'Assets', icon: '▣' },
  { href: '/reports', label: 'Reports', icon: '⊞' },
  { href: '/settings', label: 'Settings', icon: '⚒' },
];

const ADMIN_NAV: NavItem[] = [
  { href: '/admin/tenants', label: 'Tenants', icon: '◈' },
  { href: '/admin/users', label: 'Users', icon: '◑' },
];

function NavLink({ item, active }: { item: NavItem; active: boolean }) {
  return (
    <Link
      href={item.href}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        padding: '9px 14px 9px 16px',
        fontSize: 12.5,
        fontWeight: active ? 600 : 500,
        color: active ? 'var(--text-primary)' : 'var(--text-secondary)',
        borderLeft: `2px solid ${active ? 'var(--cyan)' : 'transparent'}`,
        background: active ? 'rgba(0,216,232,0.06)' : 'transparent',
        textDecoration: 'none',
        transition: 'all 0.15s ease',
      }}
    >
      <span style={{ width: 16, textAlign: 'center', color: active ? 'var(--cyan)' : 'var(--text-dim)' }}>
        {item.icon}
      </span>
      {item.label}
    </Link>
  );
}

export default function Sidebar() {
  const pathname = usePathname();
  const user = useSession();
  const isActive = (href: string) => pathname === href || pathname.startsWith(href + '/');

  return (
    <nav
      className="app-sidebar"
      style={{
        width: 'var(--sidebar-w)',
        background: 'var(--bg-secondary)',
        borderRight: '1px solid var(--border)',
        display: 'flex',
        flexDirection: 'column',
        paddingTop: 8,
        overflowY: 'auto',
      }}
    >
      <div style={{ padding: '8px 16px 4px', fontSize: 9, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--text-dim)' }}>
        Operations
      </div>
      {PORTAL_NAV.map((item) => (
        <NavLink key={item.href} item={item} active={isActive(item.href)} />
      ))}

      {user.is_admin && (
        <>
          <div
            style={{
              padding: '14px 16px 4px',
              fontSize: 9,
              letterSpacing: '0.1em',
              textTransform: 'uppercase',
              color: 'var(--purple)',
            }}
          >
            Administration
          </div>
          {ADMIN_NAV.map((item) => (
            <NavLink key={item.href} item={item} active={isActive(item.href)} />
          ))}
        </>
      )}

      <div style={{ marginTop: 'auto', padding: 16 }}>
        <div className="mono" style={{ fontSize: 9, color: 'var(--text-dim)' }}>
          PRIME SOC v4.0
        </div>
      </div>
    </nav>
  );
}
