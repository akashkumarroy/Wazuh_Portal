'use client';

import { useEffect, useState } from 'react';

interface HealthState {
  ok: boolean;
  label: string;
}

export default function FooterBar() {
  const [utc, setUtc] = useState<string>('');
  const [health, setHealth] = useState<HealthState>({ ok: true, label: 'System nominal' });

  useEffect(() => {
    const tick = () => setUtc(new Date().toISOString().replace('T', ' ').replace(/\.\d+Z$/, ' UTC'));
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    let alive = true;
    const probe = async () => {
      try {
        const res = await fetch('/api/health', { cache: 'no-store' });
        const data = await res.json();
        if (!alive) return;
        const indexerOk = data?.services?.indexer?.ok;
        setHealth(
          indexerOk
            ? { ok: true, label: 'Indexer connected' }
            : { ok: false, label: 'Indexer degraded' },
        );
      } catch {
        if (alive) setHealth({ ok: false, label: 'Health probe failed' });
      }
    };
    probe();
    const t = setInterval(probe, 60_000);
    return () => { alive = false; clearInterval(t); };
  }, []);

  return (
    <footer
      className="app-footer"
      style={{
        height: 'var(--footer-h)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 16px',
        background: 'var(--bg-secondary)',
        borderTop: '1px solid var(--border)',
        fontSize: 10,
        color: 'var(--text-secondary)',
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span
          className={health.ok ? 'pulse-dot' : ''}
          style={{
            width: 7,
            height: 7,
            borderRadius: '50%',
            background: health.ok ? 'var(--green)' : 'var(--red)',
            display: 'inline-block',
          }}
        />
        <span>{health.label}</span>
        <span style={{ color: 'var(--text-dim)' }}>·</span>
        <span>Prime Infoserv MSSP</span>
      </div>
      <div className="mono" style={{ color: 'var(--text-dim)' }}>{utc}</div>
    </footer>
  );
}
