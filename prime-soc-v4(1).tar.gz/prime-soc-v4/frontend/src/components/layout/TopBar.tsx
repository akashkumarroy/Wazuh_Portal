'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from '@/components/SessionContext';
import { useTimeRange, type TimeRange, RANGE_LABELS } from '@/components/TimeRangeContext';
import NotificationBell from '@/components/layout/NotificationBell';

const RANGES: TimeRange[] = ['1h', '6h', '24h', '7d', '30d'];

function utcNow(): string {
  return new Date().toISOString().replace('T', ' ').replace(/\.\d+Z$/, ' UTC');
}

export default function TopBar() {
  const user = useSession();
  const router = useRouter();
  const { range, setRange } = useTimeRange();
  const [clock, setClock] = useState<string>(utcNow());
  const [search, setSearch] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const t = setInterval(() => setClock(utcNow()), 1000);
    return () => clearInterval(t);
  }, []);

  async function logout() {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } finally {
      router.push('/');
      router.refresh();
    }
  }

  function submitSearch(e: React.FormEvent) {
    e.preventDefault();
    const q = search.trim();
    if (q) router.push(`/siem?q=${encodeURIComponent(q)}`);
  }

  return (
    <header
      className="app-topbar"
      style={{
        height: 'var(--topbar-h)',
        display: 'flex',
        alignItems: 'center',
        gap: 16,
        padding: '0 16px',
        background: 'var(--bg-secondary)',
        borderBottom: '1px solid var(--border)',
      }}
    >
      {/* Brand — logo image used as-is (Rule 13) */}
      <div style={{ display: 'flex', alignItems: 'center', minWidth: 'var(--sidebar-w)' }}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/logo.png" height={32} alt="Prime Infoserv" style={{ height: 32, width: 'auto' }} />
      </div>

      {/* Center search */}
      <form onSubmit={submitSearch} style={{ flex: 1, maxWidth: 520, margin: '0 auto' }}>
        <input
          className="input"
          placeholder="Search alerts, agents, IPs…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ height: 34 }}
        />
      </form>

      {/* Right cluster: time range, clock, user */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <select
          className="input"
          aria-label="Time range"
          value={range}
          onChange={(e) => setRange(e.target.value as TimeRange)}
          style={{ width: 'auto', height: 32, paddingRight: 28 }}
        >
          {RANGES.map((r) => (
            <option key={r} value={r}>
              {RANGE_LABELS[r]}
            </option>
          ))}
        </select>

        <span className="mono" style={{ fontSize: 11, color: 'var(--text-secondary)', whiteSpace: 'nowrap' }}>
          {clock}
        </span>

        <NotificationBell />

        <div style={{ position: 'relative' }}>
          <button
            className="btn btn-ghost"
            onClick={() => setMenuOpen((o) => !o)}
            style={{ padding: '4px 10px', height: 32 }}
          >
            <span
              style={{
                width: 22,
                height: 22,
                borderRadius: 6,
                background: user.is_admin ? 'var(--purple)' : 'var(--cyan)',
                color: '#04121a',
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontWeight: 700,
                fontSize: 11,
              }}
            >
              {user.username.charAt(0).toUpperCase()}
            </span>
            <span style={{ fontSize: 12 }}>{user.username}</span>
          </button>

          {menuOpen && (
            <div
              className="card"
              style={{ position: 'absolute', right: 0, top: 38, width: 200, zIndex: 60, padding: 8 }}
            >
              <div style={{ padding: '6px 8px' }}>
                <div style={{ fontSize: 12, fontWeight: 600 }}>{user.username}</div>
                <div style={{ fontSize: 10, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                  {user.is_admin ? 'Administrator' : `Client · ${user.group ?? '—'}`}
                </div>
              </div>
              <div className="divider" style={{ margin: '6px 0' }} />
              <button className="btn btn-ghost" onClick={logout} style={{ width: '100%', justifyContent: 'flex-start' }}>
                Sign out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
