'use client';

import { useEffect, useRef, useState } from 'react';
import { timeAgo } from '@/lib/format';

interface CriticalAlert {
  id: string;
  agent: string;
  description: string;
  level: number;
  timestamp: string;
}

/**
 * Live critical-alert bell. Uses the EventSource API against the SSE route
 * (/api/notifications/stream), which re-polls the indexer every 30s scoped to
 * the session's tenant. Tracks "seen" ids so the badge reflects only new ones.
 */
export default function NotificationBell() {
  const [alerts, setAlerts] = useState<CriticalAlert[]>([]);
  const [open, setOpen] = useState(false);
  const [connected, setConnected] = useState(false);
  const seenRef = useRef<Set<string>>(new Set());
  const [unseen, setUnseen] = useState(0);
  const esRef = useRef<EventSource | null>(null);

  useEffect(() => {
    let retry: ReturnType<typeof setTimeout> | null = null;

    const connect = () => {
      const es = new EventSource('/api/notifications/stream');
      esRef.current = es;

      es.onopen = () => setConnected(true);
      es.onmessage = (ev) => {
        try {
          const data = JSON.parse(ev.data);
          if (data.type !== 'criticals' || !Array.isArray(data.alerts)) return;
          const incoming: CriticalAlert[] = data.alerts;
          setAlerts(incoming);
          // Count ids we have not seen yet.
          let newCount = 0;
          for (const a of incoming) if (!seenRef.current.has(a.id)) newCount++;
          setUnseen((prev) => (open ? 0 : prev + newCount));
          // If the panel is open, mark everything seen immediately.
          if (open) incoming.forEach((a) => seenRef.current.add(a.id));
        } catch {
          /* ignore malformed event */
        }
      };
      es.onerror = () => {
        setConnected(false);
        es.close();
        // Auto-reconnect with a short backoff.
        retry = setTimeout(connect, 5000);
      };
    };

    connect();
    return () => {
      esRef.current?.close();
      if (retry) clearTimeout(retry);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function toggle() {
    setOpen((o) => {
      const next = !o;
      if (next) {
        alerts.forEach((a) => seenRef.current.add(a.id));
        setUnseen(0);
      }
      return next;
    });
  }

  return (
    <div style={{ position: 'relative' }}>
      <button className="btn btn-ghost" onClick={toggle} aria-label="Notifications" style={{ padding: '5px 9px', height: 32, position: 'relative' }}>
        <span style={{ fontSize: 15, lineHeight: 1 }}>🔔</span>
        {unseen > 0 && (
          <span style={{
            position: 'absolute', top: 1, right: 1, minWidth: 15, height: 15, padding: '0 3px',
            background: 'var(--red)', color: '#fff', borderRadius: 999, fontSize: 9, fontWeight: 700,
            display: 'flex', alignItems: 'center', justifyContent: 'center', lineHeight: 1,
          }}>
            {unseen > 99 ? '99+' : unseen}
          </span>
        )}
      </button>

      {open && (
        <div className="card anim-slide-up" style={{ position: 'absolute', right: 0, top: 40, width: 340, zIndex: 60, padding: 0, overflow: 'hidden' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 12px', borderBottom: '1px solid var(--border)' }}>
            <div style={{ fontSize: 12, fontWeight: 600 }}>Critical Alerts</div>
            <span className="badge" style={{ background: connected ? 'rgba(16,185,129,0.12)' : 'rgba(239,68,68,0.12)', color: connected ? '#6ee7b7' : '#fca5a5' }}>
              <span className={connected ? 'pulse-dot' : ''} style={{ width: 6, height: 6, borderRadius: '50%', background: connected ? 'var(--green)' : 'var(--red)', display: 'inline-block' }} />
              {connected ? 'Live' : 'Reconnecting'}
            </span>
          </div>

          <div style={{ maxHeight: 360, overflowY: 'auto' }}>
            {alerts.length === 0 ? (
              <div style={{ padding: '24px 12px', textAlign: 'center', fontSize: 11.5, color: 'var(--text-secondary)' }}>
                No critical alerts in the last 24 hours.
              </div>
            ) : (
              alerts.map((a) => (
                <div key={a.id} style={{ padding: '10px 12px', borderBottom: '1px solid rgba(255,255,255,0.03)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, alignItems: 'flex-start' }}>
                    <span className="badge badge-critical">L{a.level}</span>
                    <span className="mono" style={{ fontSize: 9.5, color: 'var(--text-dim)', whiteSpace: 'nowrap' }}>{timeAgo(a.timestamp)}</span>
                  </div>
                  <div style={{ fontSize: 11.5, marginTop: 5, lineHeight: 1.4 }}>{a.description || 'Critical alert'}</div>
                  <div style={{ fontSize: 10, color: 'var(--text-secondary)', marginTop: 3 }}>{a.agent || 'unknown agent'}</div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
