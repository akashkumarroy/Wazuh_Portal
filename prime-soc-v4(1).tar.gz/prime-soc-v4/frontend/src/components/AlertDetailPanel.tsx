'use client';

import { useEffect, useState } from 'react';
import {
  type AlertHit, severityFromLevel, severityBadgeClass, formatTs, get, asArray,
} from '@/lib/format';

function Field({ label, value, mono }: { label: string; value: React.ReactNode; mono?: boolean }) {
  if (value == null || value === '' || (Array.isArray(value) && value.length === 0)) return null;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      <span style={{ fontSize: 9, textTransform: 'uppercase', letterSpacing: '0.07em', color: 'var(--text-dim)' }}>{label}</span>
      <span className={mono ? 'mono' : ''} style={{ fontSize: 12, color: 'var(--text-primary)', wordBreak: 'break-word' }}>{value}</span>
    </div>
  );
}

function TagRow({ label, tags, color }: { label: string; tags: string[]; color: string }) {
  if (!tags.length) return null;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
      <span style={{ fontSize: 9, textTransform: 'uppercase', letterSpacing: '0.07em', color: 'var(--text-dim)' }}>{label}</span>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
        {tags.map((t, i) => (
          <span key={`${t}-${i}`} className="badge" style={{ background: `${color}22`, color, borderColor: `${color}55` }}>{t}</span>
        ))}
      </div>
    </div>
  );
}

export default function AlertDetailPanel({
  alert, onClose,
}: {
  alert: AlertHit | null;
  onClose: () => void;
}) {
  const [triage, setTriage] = useState<string | null>(null);
  const [triageLoading, setTriageLoading] = useState(false);
  const [triageError, setTriageError] = useState<string | null>(null);
  const [showRaw, setShowRaw] = useState(false);
  const [enrich, setEnrich] = useState<{ verdict: string; misp: { found: boolean; count: number }; opencti: { matched: boolean } } | null>(null);
  const [enrichLoading, setEnrichLoading] = useState(false);
  const [caseState, setCaseState] = useState<{ ok: boolean; detail: string; irisCaseId: string | null } | null>(null);
  const [caseLoading, setCaseLoading] = useState(false);

  // Reset transient state whenever a different alert is opened.
  useEffect(() => {
    setTriage(null);
    setTriageError(null);
    setTriageLoading(false);
    setShowRaw(false);
    setEnrich(null);
    setEnrichLoading(false);
    setCaseState(null);
    setCaseLoading(false);
  }, [alert?._id]);

  // Close on Escape.
  useEffect(() => {
    if (!alert) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [alert, onClose]);

  if (!alert) return null;

  const s = alert._source || {};
  const level: number = get(s, 'rule.level') ?? 0;
  const sev = severityFromLevel(level);
  const mitreIds = asArray<string>(get(s, 'rule.mitre.id'));
  const mitreTech = asArray<string>(get(s, 'rule.mitre.technique'));
  const mitreTactics = asArray<string>(get(s, 'rule.mitre.tactic'));
  const ruleGroups = asArray<string>(get(s, 'rule.groups'));
  const pci = asArray<string>(get(s, 'rule.pci_dss'));
  const gdpr = asArray<string>(get(s, 'rule.gdpr'));
  const hipaa = asArray<string>(get(s, 'rule.hipaa'));
  const nist = asArray<string>(get(s, 'rule.nist_800_53'));
  const compliance = [
    ...pci.map((v) => `PCI ${v}`),
    ...gdpr.map((v) => `GDPR ${v}`),
    ...hipaa.map((v) => `HIPAA ${v}`),
    ...nist.map((v) => `NIST ${v}`),
  ];

  async function runTriage() {
    setTriageLoading(true);
    setTriageError(null);
    setTriage(null);
    try {
      const res = await fetch('/api/ai/triage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ alert: s }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.status === 503) {
        setTriageError('AI triage is not configured on this deployment.');
        return;
      }
      if (!res.ok) throw new Error(data?.error || `HTTP ${res.status}`);
      setTriage(data.analysis || '(no analysis returned)');
    } catch (e) {
      setTriageError((e as Error).message);
    } finally {
      setTriageLoading(false);
    }
  }

  const srcip = get(s, 'data.srcip');

  async function runEnrich() {
    if (!srcip) return;
    setEnrichLoading(true);
    setEnrich(null);
    try {
      const res = await fetch(`/api/intel/enrich?value=${encodeURIComponent(srcip)}`);
      const data = await res.json().catch(() => ({}));
      if (res.ok) setEnrich(data);
    } catch {
      /* ignore — leave enrich null */
    } finally {
      setEnrichLoading(false);
    }
  }

  async function createCase() {
    setCaseLoading(true);
    setCaseState(null);
    try {
      const res = await fetch('/api/soar/iris/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: `[L${level}] ${get(s, 'rule.description') || 'Alert'}`.slice(0, 120),
          description: `Auto-created from alert ${alert?._id}.\nAgent: ${get(s, 'agent.name')}\nRule: ${get(s, 'rule.id')} — ${get(s, 'rule.description')}\nSource IP: ${srcip ?? 'n/a'}`,
          severity: level,
          alertIds: alert?._id ? [alert._id] : [],
          tenant: get(s, 'agent.labels.group') ?? null,
        }),
      });
      const data = await res.json().catch(() => ({}));
      setCaseState({ ok: !!data.ok, detail: data.detail || (data.ok ? 'created' : 'IRIS unavailable — incident saved locally'), irisCaseId: data.irisCaseId ?? null });
    } catch (e) {
      setCaseState({ ok: false, detail: (e as Error).message, irisCaseId: null });
    } finally {
      setCaseLoading(false);
    }
  }

  return (
    <>
      <div className="panel-overlay" onClick={onClose} />
      <aside className="slide-panel anim-slide-in-right" style={{ width: 460, maxWidth: '92vw' }}>
        {/* Header */}
        <div style={{ position: 'sticky', top: 0, zIndex: 2, background: 'var(--bg-secondary)', borderBottom: '1px solid var(--border)', padding: 16 }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span className={severityBadgeClass(sev)} style={{ textTransform: 'uppercase' }}>{sev} · L{level}</span>
                <span className="mono" style={{ fontSize: 10, color: 'var(--text-dim)' }}>#{get(s, 'rule.id') ?? '—'}</span>
              </div>
              <div style={{ fontSize: 13.5, fontWeight: 600, lineHeight: 1.35 }}>{get(s, 'rule.description') || 'Alert'}</div>
            </div>
            <button className="btn btn-ghost" onClick={onClose} style={{ padding: '4px 9px' }} aria-label="Close">✕</button>
          </div>
        </div>

        {/* Body */}
        <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* AI triage */}
          <div className="card card-static card-pad" style={{ background: 'rgba(124,58,237,0.06)', borderColor: 'rgba(124,58,237,0.25)' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: triage || triageError ? 10 : 0 }}>
              <div className="card-title" style={{ color: '#c4b5fd' }}>AI Analyst Triage</div>
              <button className="btn" onClick={runTriage} disabled={triageLoading}
                style={{ padding: '5px 11px', borderColor: 'rgba(124,58,237,0.4)', color: '#c4b5fd' }}>
                {triageLoading ? 'Analyzing…' : triage ? 'Re-run' : 'Run Triage'}
              </button>
            </div>
            {triageError && <div style={{ fontSize: 11.5, color: '#fca5a5' }}>{triageError}</div>}
            {triage && (
              <div className="anim-slide-up" style={{ fontSize: 12, lineHeight: 1.6, color: 'var(--text-primary)', whiteSpace: 'pre-wrap' }}>{triage}</div>
            )}
          </div>

          {/* Advanced actions: IOC enrichment + one-click IRIS case */}
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {srcip && (
              <button className="btn" onClick={runEnrich} disabled={enrichLoading}>
                {enrichLoading ? 'Enriching…' : `Enrich ${srcip}`}
              </button>
            )}
            <button className="btn btn-primary" onClick={createCase} disabled={caseLoading}>
              {caseLoading ? 'Creating…' : 'Create IRIS Case'}
            </button>
          </div>

          {enrich && (
            <div className="card card-static card-pad anim-slide-up" style={{ background: 'var(--bg-secondary)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                <span className="card-title">IOC Enrichment</span>
                <span className={`badge ${enrich.verdict === 'known' ? 'badge-critical' : 'badge-active'}`}>{enrich.verdict === 'known' ? 'Known Threat' : 'No Match'}</span>
              </div>
              <div style={{ fontSize: 11.5, color: 'var(--text-secondary)' }}>
                MISP: {enrich.misp.found ? `${enrich.misp.count} matching attribute(s)` : 'no match'} · OpenCTI: {enrich.opencti.matched ? 'indicator match' : 'no match'}
              </div>
            </div>
          )}

          {caseState && (
            <div className="card card-static card-pad anim-slide-up" style={{ background: caseState.ok ? 'rgba(16,185,129,0.06)' : 'rgba(245,158,11,0.06)', borderColor: caseState.ok ? 'rgba(16,185,129,0.25)' : 'rgba(245,158,11,0.25)' }}>
              <div style={{ fontSize: 11.5, color: caseState.ok ? '#6ee7b7' : '#fcd34d' }}>
                {caseState.ok ? `IRIS case created (#${caseState.irisCaseId}).` : caseState.detail}
              </div>
            </div>
          )}

          {/* Core metadata */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Field label="Timestamp" value={formatTs(get(s, 'timestamp'))} mono />
            <Field label="Location" value={get(s, 'location')} mono />
            <Field label="Agent" value={get(s, 'agent.name')} />
            <Field label="Agent ID" value={get(s, 'agent.id')} mono />
            <Field label="Agent IP" value={get(s, 'agent.ip')} mono />
            <Field label="Tenant Group" value={get(s, 'agent.labels.group')} />
            <Field label="Manager" value={get(s, 'manager.name')} />
            <Field label="Rule Level" value={level} mono />
          </div>

          {(get(s, 'data.srcip') || get(s, 'data.dstip') || get(s, 'GeoLocation.country_name')) && (
            <>
              <div className="divider" />
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <Field label="Source IP" value={get(s, 'data.srcip')} mono />
                <Field label="Dest IP" value={get(s, 'data.dstip')} mono />
                <Field label="Source Country" value={get(s, 'GeoLocation.country_name')} />
                <Field label="Source City" value={get(s, 'GeoLocation.city_name')} />
              </div>
            </>
          )}

          {(mitreTactics.length > 0 || mitreTech.length > 0 || mitreIds.length > 0) && (
            <>
              <div className="divider" />
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                <TagRow label="MITRE Tactics" tags={mitreTactics} color="#00d8e8" />
                <TagRow label="MITRE Techniques" tags={mitreTech} color="#7c3aed" />
                <TagRow label="Technique IDs" tags={mitreIds} color="#3b82f6" />
              </div>
            </>
          )}

          {ruleGroups.length > 0 && (
            <>
              <div className="divider" />
              <TagRow label="Rule Groups" tags={ruleGroups} color="#94a3b8" />
            </>
          )}

          {compliance.length > 0 && (
            <>
              <div className="divider" />
              <TagRow label="Compliance" tags={compliance} color="#10b981" />
            </>
          )}

          {get(s, 'full_log') && (
            <>
              <div className="divider" />
              <Field label="Full Log" value={<span className="mono" style={{ fontSize: 11, lineHeight: 1.5 }}>{String(get(s, 'full_log')).slice(0, 1200)}</span>} />
            </>
          )}

          {/* Raw JSON */}
          <div>
            <button className="btn btn-ghost" onClick={() => setShowRaw((v) => !v)} style={{ fontSize: 11 }}>
              {showRaw ? 'Hide' : 'Show'} raw document
            </button>
            {showRaw && (
              <pre className="mono anim-slide-up" style={{ marginTop: 8, fontSize: 10.5, lineHeight: 1.5, background: 'var(--bg-primary)', border: '1px solid var(--border)', borderRadius: 8, padding: 12, overflowX: 'auto', maxHeight: 360, color: 'var(--text-secondary)' }}>
                {JSON.stringify(alert._source, null, 2)}
              </pre>
            )}
          </div>
        </div>
      </aside>
    </>
  );
}
