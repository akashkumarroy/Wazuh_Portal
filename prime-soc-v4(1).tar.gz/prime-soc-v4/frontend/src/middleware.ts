import { NextRequest, NextResponse } from 'next/server';
import { jwtVerify } from 'jose';
import { SESSION_COOKIE } from '@/lib/auth';

/**
 * Route protection. We verify the JWT inline (Edge-safe via jose) rather than
 * importing the Node-only auth helpers. Unauthenticated users hitting a
 * protected page are redirected to the login page; non-admins hitting /admin
 * are redirected to the dashboard.
 */

const PUBLIC_PATHS = ['/', '/api/auth/login'];

function isPublic(pathname: string): boolean {
  return PUBLIC_PATHS.includes(pathname);
}

async function readSession(req: NextRequest): Promise<{ is_admin: boolean } | null> {
  const token = req.cookies.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const secret = process.env.JWT_SECRET;
  if (!secret) return null;
  try {
    const { payload } = await jwtVerify(token, new TextEncoder().encode(secret));
    return { is_admin: payload.is_admin === true };
  } catch {
    return null;
  }
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Allow public paths and Next internals through untouched.
  if (isPublic(pathname) || pathname.startsWith('/_next') || pathname.startsWith('/api/auth')) {
    return NextResponse.next();
  }

  const session = await readSession(req);

  // API routes return 401 JSON when unauthenticated (handled in routes too,
  // but this short-circuits cheaply). Pages redirect to login.
  if (!session) {
    if (pathname.startsWith('/api/')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const url = req.nextUrl.clone();
    url.pathname = '/';
    url.searchParams.set('next', pathname);
    return NextResponse.redirect(url);
  }

  // Admin area is admin-only.
  if (pathname.startsWith('/admin') && !session.is_admin) {
    const url = req.nextUrl.clone();
    url.pathname = '/dashboard';
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  // Run on everything except static assets and the favicon/logo.
  matcher: ['/((?!_next/static|_next/image|favicon.ico|logo.png).*)'],
};
