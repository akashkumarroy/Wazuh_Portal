/** @type {import('next').NextConfig} */
// IMPORTANT (Rule 2): NODE_TLS_REJECT_UNAUTHORIZED is NOT set here — Next 14
// throws a build error if it is. It is set only in the Dockerfile ENV and in
// docker-compose environment (self-signed Wazuh Indexer TLS).
const nextConfig = {
  reactStrictMode: true,
  output: 'standalone',
  poweredByHeader: false,
  eslint: { ignoreDuringBuilds: true },
};

module.exports = nextConfig;
