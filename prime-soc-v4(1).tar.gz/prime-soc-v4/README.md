# Prime SOC Portal v4

**Our Expertise, Your Shield.**

A unified, real-time, multi-tenant Security Operations Center portal for **Prime Infoserv** (MSSP). It replaces the stock Wazuh Dashboard with a purpose-built console that unifies SIEM, threat intelligence, SOAR, asset inventory, and an AI analyst assistant — every metric driven by **live** data, no placeholders.

---

## Architecture

```
                         ┌─────────────┐
   Browser ──HTTP──▶  nginx  ──▶  Next.js 14 (standalone)  ──┐
                         └─────────────┘                      │
                                                              ├─▶ Wazuh Indexer (OpenSearch)   — alerts, monitoring, stats
                                                              ├─▶ OpenCTI (GraphQL)            — IOC/malware/attack-pattern KB
                                                              ├─▶ MISP (REST)                  — threat feeds
                                                              ├─▶ DFIR-IRIS (REST)             — case management
                                                              ├─▶ Shuffle (REST)               — SOAR workflows
                                                              ├─▶ Anthropic / OpenAI / Gemini  — AI assistant (configurable)
                                                              └─▶ PostgreSQL                    — portal-local state only
```

- **Frontend:** Next.js 14 App Router, TypeScript, React 18, Recharts + D3 (sankey, geo), raw SSE for streaming.
- **Auth:** credentials are validated **directly against the Wazuh Indexer** Security API (no separate user store); the portal then issues an 8-hour JWT cookie. Admin vs. client and tenant scope are derived from the account's roles.
- **Multi-tenancy:** every alert query is scoped server-side by `agent.labels.group`. Admins see all tenants; clients see only their own.
- **State store:** PostgreSQL holds only portal-local data (sessions, audit log, watchlist, saved searches, incidents). **No** security telemetry is duplicated there.

## Key data-source decisions

These were verified against the live cluster and are baked into `src/lib/`:

- **Tenants** are auto-synced from a terms aggregation on `agent.labels.group` (not the Kibana tenants API).
- **Time-bounded aggregations only** — every query carries a time range so shards skip; unbounded scans are avoided.
- **`ignore_unavailable=true`** is appended to every indexer request (daily-index gaps exist).
- **Monitoring** (`wazuh-monitoring-*`) has `group`/`status` as *text*, which cannot be aggregated server-side; the portal fetches the latest snapshot and tallies agent status/OS/group in JS.
- **Compliance** is matched by field existence (e.g. `rule.pci_dss`), not by `rule.groups`.
- **OpenCTI** counts use `pageInfo.globalCount` (true totals). Threat-actor count may legitimately be 0 → honest empty state.
- **MISP** uses `metadata:true` event search (some feeds carry thousands of attributes) and MISP's own level scale (1=High … 4=Undefined).
- **IRIS / Shuffle** degrade gracefully: timeouts/unreachable return empty, reachable-but-no-data renders honest empty states.

## Repository layout

```
.
├── docker-compose.yml         # postgres + frontend + nginx (no `version:` key)
├── .env.example               # placeholders only — copy to .env
├── db/
│   └── init.sql               # portal schema (runs once on first DB init)
├── nginx/
│   └── nginx.conf             # reverse proxy; SSE-safe routes
└── frontend/
    ├── Dockerfile             # multi-stage Next standalone build
    ├── public/                # logo.png, favicon.ico, geo/ atlas
    └── src/
        ├── app/               # routes (pages) + app/api (route handlers)
        ├── components/        # layout, widgets, panels, assistant
        ├── lib/               # auth, wazuh, intel, soar, ai/, db, format
        └── middleware.ts      # route protection + admin gating
```

## Quick start

```bash
# 1. Configure secrets
cp .env.example .env
$EDITOR .env            # fill every FILL_IN_* value

# 2. Build & run
docker compose up -d --build

# 3. Open the portal
#    http://<host>:${HTTP_PORT:-8080}
```

Log in with any **Wazuh Indexer** account. Admin accounts (non-blank backend role or `all_access`) get the full multi-tenant view and the Administration menu; client accounts are scoped to their own tenant.

### Health

- Container healthcheck: `GET /api/health` (used by Docker + nginx `/healthz`).
- The footer and Settings surface live indexer/DB connectivity.

## Configuration reference

All variables live in `.env`. See `.env.example` for the annotated list. Highlights:

| Variable | Purpose |
|---|---|
| `JWT_SECRET` | Session cookie signing (64+ random chars) |
| `WAZUH_INDEXER_URL/USER/PASS` | Indexer connection (self-signed TLS accepted) |
| `OPENCTI_*`, `MISP_*` | Threat intelligence |
| `IRIS_*`, `SHUFFLE_*` | SOAR (graceful when unreachable) |
| `AI_PROVIDER` | `anthropic` \| `openai` \| `gemini` |
| `ANTHROPIC_/OPENAI_/GEMINI_*` | Provider key + optional model/base-url |
| `POSTGRES_*` | Portal state DB |

### Swapping the AI provider

The assistant is provider-agnostic. To switch, set `AI_PROVIDER` and that provider's key (and optionally model). The OpenAI adapter speaks the standard `/chat/completions` contract, so `OPENAI_BASE_URL` also targets OpenRouter, LiteLLM, Azure-style gateways, or a local vLLM/Ollama server — no code change.

## Security notes

- **Self-signed indexer TLS:** `NODE_TLS_REJECT_UNAUTHORIZED=0` is set **only** in the Docker image ENV and compose `environment` — never in `next.config.js`. For production, prefer mounting the indexer CA and removing this flag.
- **Rotate the credentials** that were used during development before go-live.
- The portal runs as a non-root user inside the container.
- Enable TLS at nginx (mount certs, uncomment the 443 block) for any internet-facing deployment.

## Tech stack

Next.js 14.2 · React 18 · TypeScript · Recharts · D3 v7 (sankey, geo) · jose (JWT) · raw `pg` · `@anthropic-ai/sdk` · Node 20 Alpine · nginx 1.27 · PostgreSQL 16.
