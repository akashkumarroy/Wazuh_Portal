export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getStatistics, getDashboardStats, getGeoData } from '@/lib/wazuh';
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  const p = token ? await verifyToken(token) : null;
  if (!p) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const group = p.is_admin ? null : p.group;
  try {
    let stats = null, perf: any[] = [], geo = null;
    try { perf  = await getStatistics(); }           catch { /* non-fatal */ }
    try { stats = await getDashboardStats(group, 7); } catch { /* non-fatal */ }
    try { geo   = await getGeoData(group); }         catch { /* non-fatal */ }
    return NextResponse.json({ stats, perf, geo });
  } catch (err) { return NextResponse.json({ error: String(err) }, { status: 502 }); }
}
