export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getDashboardStats, getAgentStatusSummary, getStatistics } from '@/lib/wazuh';

export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  const p = token ? await verifyToken(token) : null;
  if (!p) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const group = p.is_admin ? null : p.group;

  // Sequential — not parallel — to avoid concurrent heap pressure on indexer
  let stats = null, agentData = null, perfData: any[] = [];
  try { stats     = await getDashboardStats(group); } catch(e) { console.error('[dash:stats]', e); }
  try { agentData = await getAgentStatusSummary(group); } catch(e) { console.error('[dash:agents]', e); }
  try { perfData  = await getStatistics(); } catch(e) { console.error('[dash:perf]', e); }

  return NextResponse.json({ stats, agents: agentData, perf: perfData, group, is_admin: p.is_admin });
}
