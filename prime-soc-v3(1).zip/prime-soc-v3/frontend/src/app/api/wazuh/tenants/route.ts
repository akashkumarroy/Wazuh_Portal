export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getAllTenantsSummary, getIndexerUsers, getIndexerRoles } from '@/lib/wazuh';

export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  const p = token ? await verifyToken(token) : null;
  if (!p || !p.is_admin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

  let tenants: any[] = [], users: any[] = [], roles: any[] = [];
  try { tenants = await getAllTenantsSummary(); } catch(e) { console.error('[tenants]', e); }
  try { users   = await getIndexerUsers(); } catch(e) { console.error('[users]', e); }
  try { roles   = await getIndexerRoles(); } catch(e) { console.error('[roles]', e); }

  return NextResponse.json({ tenants, users, roles });
}
