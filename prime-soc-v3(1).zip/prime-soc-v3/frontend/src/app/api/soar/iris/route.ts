export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getIRISStats, getIRISCases, getIRISAlerts } from '@/lib/soar';

export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  const p = token ? await verifyToken(token) : null;
  if (!p) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const type = searchParams.get('type') ?? 'stats';
  if (type === 'cases')  return NextResponse.json({ cases: await getIRISCases() });
  if (type === 'alerts') return NextResponse.json({ alerts: await getIRISAlerts() });
  const [stats, cases] = await Promise.all([getIRISStats(), getIRISCases()]);
  return NextResponse.json({ stats, cases: (cases as any[]).slice(0, 10) });
}
