export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getShuffleStats, getShuffleWorkflows } from '@/lib/soar';

export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  const p = token ? await verifyToken(token) : null;
  if (!p) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { searchParams } = new URL(req.url);
  if (searchParams.get('workflows') === 'true') {
    const workflows = await getShuffleWorkflows();
    return NextResponse.json({ workflows });
  }
  const stats = await getShuffleStats();
  return NextResponse.json(stats);
}
