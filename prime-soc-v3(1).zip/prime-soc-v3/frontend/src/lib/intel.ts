// Intel client — MISP + OpenCTI with timeouts and correct GraphQL

async function fetchWithTimeout(url: string, options: RequestInit, ms = 10000) {
  const ctrl = new AbortController();
  const id   = setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await fetch(url, { ...options, signal: ctrl.signal });
    clearTimeout(id);
    return res;
  } catch (err) { clearTimeout(id); throw err; }
}

// ── MISP ───────────────────────────────────────────────────────
async function mispFetch<T>(path: string, body?: Record<string, unknown>): Promise<T> {
  const url = process.env.MISP_URL ?? '';
  const key = process.env.MISP_API_KEY ?? '';
  const res = await fetchWithTimeout(`${url}${path}`, {
    method: body ? 'POST' : 'GET',
    headers: { Authorization: key, Accept: 'application/json', 'Content-Type': 'application/json' },
    ...(body ? { body: JSON.stringify(body) } : {}),
  }, 10000);
  if (!res.ok) throw new Error(`MISP ${res.status}`);
  return res.json() as Promise<T>;
}

export async function getMISPEvents(limit = 20) {
  try {
    const data = await mispFetch<{ response?: any[] }>('/events/restSearch', {
      limit, page: 1, published: 1, returnFormat: 'json',
    });
    return (data.response ?? []).map((e: any) => {
      const ev = e.Event ?? e;
      return {
        id:              ev.id,
        info:            ev.info,
        threat_level:    parseInt(ev.threat_level_id ?? '4', 10),
        date:            ev.date,
        timestamp:       ev.timestamp,
        org:             ev.Orgc?.name ?? ev.Org?.name ?? 'Unknown',
        tags:            (ev.Tag ?? []).slice(0, 5).map((t: any) => t.name),
        attribute_count: parseInt(ev.attribute_count ?? '0', 10),
      };
    });
  } catch { return []; }
}

// ── OpenCTI GraphQL ────────────────────────────────────────────
// Fixed: use correct field names from OpenCTI 5.x schema
async function ctiGQL<T>(query: string): Promise<T> {
  const res = await fetchWithTimeout(`${process.env.OPENCTI_URL ?? ''}/graphql`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.OPENCTI_API_KEY ?? ''}` },
    body: JSON.stringify({ query }),
  }, 10000);
  if (!res.ok) throw new Error(`OpenCTI ${res.status}`);
  const json = await res.json() as { data?: T; errors?: any[] };
  if (json.errors?.length && !json.data) throw new Error(JSON.stringify(json.errors[0]));
  return json.data as T;
}

export async function getCTIThreatActors(limit = 15) {
  try {
    const d = await ctiGQL<any>(`{
      threatActors(first:${limit}) {
        edges { node { id name description threat_actor_types sophistication first_seen last_seen confidence } }
      }
    }`);
    return d?.threatActors?.edges?.map((e: any) => e.node) ?? [];
  } catch { return []; }
}

export async function getCTIIndicators(limit = 30) {
  try {
    const d = await ctiGQL<any>(`{
      indicators(first:${limit}) {
        edges { node { id name pattern pattern_type valid_from confidence x_opencti_score } }
      }
    }`);
    return d?.indicators?.edges?.map((e: any) => e.node) ?? [];
  } catch { return []; }
}

// Fixed stats — use edges count instead of totalCount (field doesn't exist in this version)
export async function getCTIStats() {
  try {
    const d = await ctiGQL<any>(`{
      threatActors(first:100) { edges { node { id } } }
      malwares(first:100)     { edges { node { id } } }
      reports(first:100)      { edges { node { id } } }
      attackPatterns(first:100) { edges { node { id } } }
    }`);
    return {
      threat_actors:   d?.threatActors?.edges?.length ?? 0,
      malwares:        d?.malwares?.edges?.length ?? 0,
      reports:         d?.reports?.edges?.length ?? 0,
      attack_patterns: d?.attackPatterns?.edges?.length ?? 0,
      indicators:      0, // fetched separately to avoid heavy query
      total_objects:   0,
    };
  } catch { return { threat_actors:0, malwares:0, reports:0, attack_patterns:0, indicators:0, total_objects:0 }; }
}

export async function getCTIReports(limit = 10) {
  try {
    const d = await ctiGQL<any>(`{
      reports(first:${limit}) {
        edges { node { id name description published confidence report_types } }
      }
    }`);
    return d?.reports?.edges?.map((e: any) => e.node) ?? [];
  } catch { return []; }
}
