// Wazuh Indexer client — wildcard index + mandatory date filter
// ignore_unavailable=true on all queries prevents missing-index errors

const INDEXER_URL = () => {
  const u = process.env.WAZUH_INDEXER_URL;
  if (!u) throw new Error('WAZUH_INDEXER_URL not set');
  return u;
};

const ADMIN_CREDS = () =>
  Buffer.from(`${process.env.WAZUH_INDEXER_USER ?? 'admin'}:${process.env.WAZUH_INDEXER_PASS ?? ''}`).toString('base64');

async function fetchWithTimeout(url: string, options: RequestInit, ms = 15000) {
  const ctrl = new AbortController();
  const id   = setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await fetch(url, { ...options, signal: ctrl.signal });
    clearTimeout(id);
    return res;
  } catch (err) { clearTimeout(id); throw err; }
}

export async function indexerFetch<T>(path: string, body?: Record<string, unknown>): Promise<T> {
  const sep      = path.includes('?') ? '&' : '?';
  const fullPath = `${path}${sep}ignore_unavailable=true`;
  const res = await fetchWithTimeout(`${INDEXER_URL()}${fullPath}`, {
    method: body ? 'POST' : 'GET',
    headers: { Authorization: `Basic ${ADMIN_CREDS()}`, 'Content-Type': 'application/json' },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  if (!res.ok) throw new Error(`Indexer ${res.status} on ${path}`);
  return res.json() as Promise<T>;
}

export function tenantFilter(group: string | null | undefined) {
  if (!group) return null;
  return { match: { 'agent.labels.group': group } };
}

// Always 24h default — same as Wazuh dashboard
export function timeRangeFilter(hours = 24) {
  return { range: { timestamp: { gte: `now-${hours}h`, lte: 'now' } } };
}

export function severityFromLevel(level: number): 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO' {
  if (level >= 13) return 'CRITICAL';
  if (level >= 10) return 'HIGH';
  if (level >= 7)  return 'MEDIUM';
  if (level >= 4)  return 'LOW';
  return 'INFO';
}

// ── Dashboard stats — last 24h ─────────────────────────────────
export async function getDashboardStats(group?: string | null) {
  const filter = tenantFilter(group);
  const timeF  = timeRangeFilter(24);
  const base   = [...(filter ? [filter] : []), timeF];
  return indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
    size: 0,
    query: { bool: { must: base } },
    aggs: {
      total:    { value_count: { field: '_id' } },
      critical: { filter: { bool: { must: [...base, { range: { 'rule.level': { gte: 13 } } }] } } },
      high:     { filter: { bool: { must: [...base, { range: { 'rule.level': { gte: 10, lt: 13 } } }] } } },
      medium:   { filter: { bool: { must: [...base, { range: { 'rule.level': { gte: 7, lt: 10 } } }] } } },
      alerts_over_time: { date_histogram: { field: 'timestamp', fixed_interval: '1h', min_doc_count: 1 } },
      top_agents:       { terms: { field: 'agent.name', size: 10 } },
      top_rules:        { terms: { field: 'rule.description.keyword', size: 10 } },
      geo_countries:    { terms: { field: 'GeoLocation.country_name.keyword', size: 15 } },
      mitre_tactics:    { terms: { field: 'rule.mitre.tactic', size: 15 } },
    },
  });
}

// ── Recent alerts ──────────────────────────────────────────────
export async function getAlerts(group?: string | null, size = 50, from = 0, extraFilters: any[] = [], hours = 24) {
  const filter = tenantFilter(group);
  const timeF  = timeRangeFilter(hours);
  const must   = [...(filter ? [filter] : []), timeF, ...extraFilters];
  const data   = await indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
    size, from,
    sort: [{ timestamp: { order: 'desc' } }],
    query: { bool: { must } },
    _source: ['timestamp','agent.name','agent.id','agent.ip','agent.labels.group','rule.id','rule.level','rule.description','rule.groups','rule.pci_dss','rule.gdpr','rule.hipaa','rule.nist_800_53','rule.tsc','rule.gpg13','rule.mitre','data.srcip','data.dstip','full_log','location','GeoLocation','manager.name'],
  });
  return (data.hits?.hits ?? []).map((h: any) => ({ id: h._id, index: h._index, ...h._source, severity: severityFromLevel(h._source?.rule?.level ?? 0) }));
}

// ── Alert by ID ────────────────────────────────────────────────
export async function getAlertById(id: string) {
  const search = await indexerFetch<any>('/wazuh-alerts-4.x-*/_search', { size: 1, query: { ids: { values: [id] } } });
  const hit = search?.hits?.hits?.[0];
  if (!hit) return null;
  return { id: hit._id, index: hit._index, ...hit._source, severity: severityFromLevel(hit._source?.rule?.level ?? 0) };
}

// ── Agents ────────────────────────────────────────────────────
export async function getAgents(group?: string | null, size = 500) {
  const filter = group ? [{ term: { 'group': group } }] : [];
  const data = await indexerFetch<any>('/wazuh-monitoring-*/_search', {
    size,
    sort: [{ lastKeepAlive: { order: 'desc' } }],
    query: filter.length ? { bool: { must: filter } } : { match_all: {} },
    _source: ['name','id','ip','status','group','os.name','os.platform','os.version','lastKeepAlive','dateAdd','manager','node_name','version'],
    collapse: { field: 'id' },
  });
  return { agents: data.hits?.hits?.map((h: any) => h._source) ?? [], total: data.hits?.total?.value ?? 0 };
}

// ── Agent status summary ───────────────────────────────────────
export async function getAgentStatusSummary(group?: string | null) {
  const filter = group ? [{ term: { 'group': group } }] : [];
  return indexerFetch<any>('/wazuh-monitoring-*/_search', {
    size: 0,
    query: filter.length ? { bool: { must: filter } } : { match_all: {} },
    aggs: {
      by_status:     { terms: { field: 'status', size: 5 } },
      unique_agents: { cardinality: { field: 'id' } },
    },
  });
}

// ── Tenant overview (30 days) ──────────────────────────────────
export async function getTenantOverview(tenantGroup: string) {
  const timeF = timeRangeFilter(24 * 30);
  const must  = [{ match: { 'agent.labels.group': tenantGroup } }, timeF];
  const [alertData, agentData] = await Promise.all([
    indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
      size: 0, query: { bool: { must } },
      aggs: {
        total:    { value_count: { field: '_id' } },
        critical: { filter: { range: { 'rule.level': { gte: 13 } } } },
        high:     { filter: { range: { 'rule.level': { gte: 10, lt: 13 } } } },
        medium:   { filter: { range: { 'rule.level': { gte: 7, lt: 10 } } } },
        alerts_over_time: { date_histogram: { field: 'timestamp', calendar_interval: 'day', min_doc_count: 1 } },
        top_agents: { terms: { field: 'agent.name', size: 10 } },
        top_rules:  { terms: { field: 'rule.description.keyword', size: 10 } },
      },
    }),
    indexerFetch<any>('/wazuh-monitoring-*/_search', {
      size: 0, query: { term: { 'group': tenantGroup } },
      aggs: { by_status: { terms: { field: 'status', size: 5 } }, by_os: { terms: { field: 'os.platform', size: 10 } }, agent_count: { cardinality: { field: 'id' } } },
    }),
  ]);
  return { alerts: alertData, agents: agentData };
}

// ── All tenants summary ────────────────────────────────────────
export async function getAllTenantsSummary() {
  const timeF = timeRangeFilter(24);
  return indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
    size: 0, query: { bool: { must: [timeF] } },
    aggs: {
      by_tenant: {
        terms: { field: 'agent.labels.group', size: 50 },
        aggs: {
          critical: { filter: { range: { 'rule.level': { gte: 13 } } } },
          high:     { filter: { range: { 'rule.level': { gte: 10, lt: 13 } } } },
          medium:   { filter: { range: { 'rule.level': { gte: 7, lt: 10 } } } },
          last_alert: { max: { field: 'timestamp' } },
          alerts_over_time: { date_histogram: { field: 'timestamp', calendar_interval: 'hour', min_doc_count: 1 } },
        },
      },
    },
  });
}

// ── MITRE ─────────────────────────────────────────────────────
export async function getMitreSummary(group?: string | null) {
  const filter = tenantFilter(group);
  const timeF  = timeRangeFilter(24);
  const must   = [...(filter ? [filter] : []), timeF];
  return indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
    size: 0, query: { bool: { must } },
    aggs: { techniques: { terms: { field: 'rule.mitre.id', size: 30 } }, tactics: { terms: { field: 'rule.mitre.tactic', size: 20 } } },
  });
}

// ── Compliance ─────────────────────────────────────────────────
export async function getComplianceSummary(group?: string | null) {
  const filter = tenantFilter(group);
  const timeF  = timeRangeFilter(24 * 7);
  const must   = [...(filter ? [filter] : []), timeF];
  return indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
    size: 0, query: { bool: { must } },
    aggs: {
      pci_dss:     { filter: { exists: { field: 'rule.pci_dss' } },     aggs: { requirements: { terms: { field: 'rule.pci_dss', size: 30 } } } },
      gdpr:        { filter: { exists: { field: 'rule.gdpr' } },        aggs: { requirements: { terms: { field: 'rule.gdpr', size: 30 } } } },
      hipaa:       { filter: { exists: { field: 'rule.hipaa' } },       aggs: { requirements: { terms: { field: 'rule.hipaa', size: 30 } } } },
      nist_800_53: { filter: { exists: { field: 'rule.nist_800_53' } }, aggs: { requirements: { terms: { field: 'rule.nist_800_53', size: 30 } } } },
      tsc:         { filter: { exists: { field: 'rule.tsc' } },         aggs: { requirements: { terms: { field: 'rule.tsc', size: 30 } } } },
      gpg13:       { filter: { exists: { field: 'rule.gpg13' } },       aggs: { requirements: { terms: { field: 'rule.gpg13', size: 30 } } } },
    },
  });
}

export async function getComplianceAlerts(framework: 'pci_dss'|'gdpr'|'hipaa'|'nist_800_53'|'tsc'|'gpg13', group?: string | null, size = 50) {
  const filter = tenantFilter(group);
  const timeF  = timeRangeFilter(24 * 7);
  const must   = [{ exists: { field: `rule.${framework}` } }, timeF, ...(filter ? [filter] : [])];
  const data   = await indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
    size, sort: [{ timestamp: { order: 'desc' } }], query: { bool: { must } },
    _source: [`rule.${framework}`, 'rule.description', 'rule.level', 'agent.name', 'agent.labels.group', 'timestamp'],
  });
  return (data.hits?.hits ?? []).map((h: any) => ({ id: h._id, ...h._source, severity: severityFromLevel(h._source?.rule?.level ?? 0) }));
}

// ── FIM ────────────────────────────────────────────────────────
export async function getFIMEvents(group?: string | null, size = 100) {
  const filter = tenantFilter(group);
  const timeF  = timeRangeFilter(24);
  const must   = [{ term: { 'rule.groups': 'syscheck' } }, timeF, ...(filter ? [filter] : [])];
  const data   = await indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
    size, sort: [{ timestamp: { order: 'desc' } }], query: { bool: { must } },
    _source: ['agent.name','agent.labels.group','syscheck.path','syscheck.event','syscheck.md5_after','rule.description','rule.level','timestamp'],
  });
  return (data.hits?.hits ?? []).map((h: any) => ({ id: h._id, ...h._source }));
}

// ── SCA ────────────────────────────────────────────────────────
export async function getSCAEvents(group?: string | null, size = 100) {
  const filter = tenantFilter(group);
  const timeF  = timeRangeFilter(24 * 7);
  const must   = [{ term: { 'rule.groups': 'sca' } }, timeF, ...(filter ? [filter] : [])];
  return indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
    size, sort: [{ timestamp: { order: 'desc' } }], query: { bool: { must } },
    _source: ['agent.name','agent.labels.group','data.sca.check.title','data.sca.check.result','data.sca.policy','data.sca.score','rule.description','rule.level','timestamp'],
    aggs: { by_result: { terms: { field: 'data.sca.check.result.keyword', size: 5 } }, by_agent: { terms: { field: 'agent.name', size: 20 }, aggs: { latest_score: { max: { field: 'data.sca.score' } } } } },
  });
}

// ── Vulnerability ──────────────────────────────────────────────
export async function getVulnerabilities(group?: string | null) {
  const filter = tenantFilter(group);
  const must   = filter ? [filter] : [];
  try {
    const data = await indexerFetch<any>('/wazuh-states-vulnerabilities-*/_search', {
      size: 0, query: must.length ? { bool: { must } } : { match_all: {} },
      aggs: { critical: { filter: { term: { 'vulnerability.severity': 'Critical' } } }, high: { filter: { term: { 'vulnerability.severity': 'High' } } }, medium: { filter: { term: { 'vulnerability.severity': 'Medium' } } }, low: { filter: { term: { 'vulnerability.severity': 'Low' } } } },
    });
    if ((data.hits?.total?.value ?? 0) > 0) return data;
  } catch { /* no vuln index */ }
  return null;
}

// ── Geo data ───────────────────────────────────────────────────
export async function getGeoData(group?: string | null) {
  const filter = tenantFilter(group);
  const timeF  = timeRangeFilter(24);
  const must   = [{ exists: { field: 'GeoLocation.location' } }, timeF, ...(filter ? [filter] : [])];
  return indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
    size: 0, query: { bool: { must } },
    aggs: { top_countries: { terms: { field: 'GeoLocation.country_name.keyword', size: 20 } } },
  });
}

// ── Statistics ─────────────────────────────────────────────────
export async function getStatistics() {
  try {
    const data = await indexerFetch<any>('/wazuh-statistics-*/_search', {
      size: 10, sort: [{ timestamp: { order: 'desc' } }],
      _source: ['analysisd.events_received','analysisd.alerts_written','timestamp','nodeName'],
    });
    return data.hits?.hits?.map((h: any) => h._source) ?? [];
  } catch { return []; }
}

// ── Sankey ─────────────────────────────────────────────────────
export async function getSankeyData(group?: string | null) {
  const filter = tenantFilter(group);
  const timeF  = timeRangeFilter(24);
  const must   = [...(filter ? [filter] : []), timeF];
  return indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
    size: 0, query: { bool: { must } },
    aggs: { by_group: { terms: { field: 'agent.labels.group', size: 15 }, aggs: { by_rule_group: { terms: { field: 'rule.groups', size: 10 }, aggs: { by_manager: { terms: { field: 'manager.name', size: 5 } } } } } } },
  });
}

// ── Admin ──────────────────────────────────────────────────────
export async function getIndexerUsers() {
  const data = await indexerFetch<any>('/_plugins/_security/api/internalusers');
  return Object.entries(data ?? {}).map(([username, info]: [string, any]) => ({ username, backend_roles: info.backend_roles ?? [], roles: info.roles ?? [] }));
}
export async function getIndexerRoles() {
  const data = await indexerFetch<any>('/_plugins/_security/api/roles');
  return Object.entries(data ?? {}).map(([name]: [string, any]) => ({ name }));
}
