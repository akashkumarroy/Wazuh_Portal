# Prime SOC Portal v2

Production-ready unified MSSP security operations portal.

## What Changed in v2 (All Troubleshooting Issues Fixed)

| Issue | Fix Applied |
|-------|------------|
| `jsonwebtoken` not Edge compatible | Replaced with `jose` throughout |
| Cookie `secure: true` on HTTP | `secure: false` until HTTPS configured |
| `useSearchParams` needs Suspense | Login form wrapped in `<Suspense>` |
| `ssl: true` DB connection error | `ssl: false` — Docker internal network |
| `envsubst` corrupted nginx vars | Removed envsubst entirely — static nginx.conf |
| `NODE_TLS_REJECT_UNAUTHORIZED` | Set in Dockerfile CMD for self-signed certs |
| Iframe 404 / X-Frame-Options blocked | Proxy via `/api/proxy/[tool]/` strips headers |
| Fake data / mock numbers | All data fetched from Wazuh API in real-time |
| No tenant isolation | Every API call filters by `wazuh_group` |
| Login not using Wazuh IAM | `authenticateUser()` calls Wazuh `/security/user/authenticate` |

---

## Quick Deploy

```bash
# 1. Clone and setup
cp .env.example .env
nano .env   # Fill in your values (see below)

# 2. Build and start
docker compose up -d --build

# 3. Check logs
docker logs primesoc_frontend --tail 50
docker logs primesoc_nginx    --tail 20
docker logs primesoc_db       --tail 20

# Portal runs at: http://YOUR_SERVER_IP:8181
```

---

## Required .env Values

```bash
# Change these — everything else has sane defaults
POSTGRES_PASSWORD=your_strong_password_here
JWT_SECRET=generate_with__openssl_rand_hex_32__then_double_it

WAZUH_API_URL=https://YOUR_WAZUH_API_IP:55000
WAZUH_API_USER=wazuh
WAZUH_API_PASS=your_wazuh_api_password
WAZUH_DASHBOARD_URL=https://your-wazuh-dashboard-domain

OPENCTI_URL=http://10.0.7.93:8080
OPENCTI_API_KEY=your_opencti_key

IRIS_URL=https://10.0.7.93:4433
IRIS_API_KEY=your_iris_key

SHUFFLE_URL=https://shuffler.io
SHUFFLE_API_KEY=your_shuffle_key
```

Generate JWT_SECRET:
```bash
echo $(openssl rand -hex 32)$(openssl rand -hex 32)
```

---

## Login

Users log in with their **Wazuh credentials** (same username/password as Wazuh dashboard).

On first login, a portal record is auto-created with `client` role.

To give a user `admin` role, register them via **Admin → Users** and set role to `admin`.

---

## Tenant Setup

### Onboarding a new client:
1. Create agent group in Wazuh (or the portal does it automatically)
2. Go to **Admin → Tenants → Onboard Tenant**
3. Set `Wazuh Agent Group` — must match exactly
4. Go to **Admin → Users → Register User**
5. Enter the client's Wazuh username, set role `client`, assign tenant

Client will only see data from agents in their Wazuh group.

### Wazuh group creation (your existing process):
```
Wazuh Dashboard → Indexer Management → Securities → Tenants
Roles → [Role] → Action → Duplicate → assign group
```

---

## Module Access

| Module | URL | How It Opens |
|--------|-----|-------------|
| SIEM | `/siem` | Wazuh data via API + all sub-modules |
| SOAR | `/soar` | Shuffle iframe via `/api/proxy/shuffle/` |
| Threat Intel | `/threat-intel` | OpenCTI iframe via `/api/proxy/opencti/` |
| Cases | `/cases` | IRIS iframe via `/api/proxy/iris/` |
| Reports | `/reports` | Live CSV/JSON download from Wazuh |
| Assets | `/assets` | Wazuh agents API |

### Why iframes work now:
All tool requests go through `/api/proxy/[tool]/` which:
- Adds auth headers
- Strips `X-Frame-Options` and `Content-Security-Policy` headers
- Handles self-signed TLS certificates

---

## Updating Tool IPs/URLs

When your tool IPs change:
1. Edit `.env` — change the relevant URL
2. Run: `docker compose up -d --build frontend`

---

## Adding HTTPS / Domain

1. Get SSL certificate (Let's Encrypt or your CA)
2. Place in `./nginx/ssl/cert.pem` and `./nginx/ssl/key.pem`
3. Update `nginx/nginx.conf` to add HTTPS server block
4. Change in `.env`: `COOKIE_SECURE=true`
5. Update `src/lib/auth.ts`: set `secure: true` in COOKIE_OPTIONS
6. `docker compose restart nginx`

---

## Troubleshooting

**Portal shows blank page:**
```bash
docker logs primesoc_frontend --tail 100
# Look for: DATABASE_URL, JWT_SECRET missing
```

**Wazuh data not loading:**
```bash
# Test from the container
docker exec primesoc_frontend wget -qO- --no-check-certificate \
  "https://YOUR_WAZUH_IP:55000/security/user/authenticate?raw=true" \
  --header "Authorization: Basic $(echo -n 'wazuh:PASSWORD' | base64)"
```

**Iframe showing 502:**
```bash
# Check proxy route is reachable
curl http://localhost:8181/api/proxy/opencti/ -v
# If tool is unreachable from Docker network, check firewall rules
```

**DB connection refused:**
```bash
docker logs primesoc_db
# Ensure POSTGRES_PASSWORD in .env matches DATABASE_URL
```

**nginx crash loop:**
```bash
docker logs primesoc_nginx
# nginx.conf is static — no envsubst, no variable issues
```
