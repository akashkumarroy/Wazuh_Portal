/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',

  // Expose tool URLs to client-side iframes
  env: {
    NEXT_PUBLIC_WAZUH_DASHBOARD_URL: process.env.WAZUH_DASHBOARD_URL ?? '',
    NEXT_PUBLIC_OPENCTI_URL:         process.env.OPENCTI_URL ?? '',
    NEXT_PUBLIC_IRIS_URL:            process.env.IRIS_URL ?? '',
    NEXT_PUBLIC_SHUFFLE_URL:         process.env.SHUFFLE_URL ?? '',
  },

  // Required for pg + bcryptjs in server components
  experimental: {
    serverComponentsExternalPackages: ['pg', 'bcryptjs'],
  },

  // Allow self-signed certs in server-side fetch (Wazuh, IRIS)
  // Node.js level: set via NODE_TLS_REJECT_UNAUTHORIZED in Dockerfile
  // (Not a Next.js config — handled in Dockerfile CMD)

  webpack: (config) => {
    // Prevent bundling Node.js built-ins
    config.resolve.fallback = {
      ...config.resolve.fallback,
      net:  false,
      tls:  false,
      fs:   false,
      dns:  false,
      crypto: false,
    };
    return config;
  },

  // Minimal security headers (nginx adds the rest)
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
        ],
      },
    ];
  },
};

module.exports = nextConfig;
