export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { COOKIE_NAME, verifyToken } from '@/lib/auth';
import { query } from '@/lib/db';
export const runtime = 'nodejs';
export async function POST(request: NextRequest) {
  const token = request.cookies.get(COOKIE_NAME)?.value;
  if (token) {
    const p = await verifyToken(token);
    if (p?.jti) await query('DELETE FROM sessions WHERE jti = $1', [p.jti]).catch(()=>{});
  }
  const res = NextResponse.json({ ok: true });
  res.cookies.delete(COOKIE_NAME);
  return res;
}
