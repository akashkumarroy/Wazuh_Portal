export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { authenticateUser } from '@/lib/wazuh';
import { signToken, COOKIE_NAME, COOKIE_OPTIONS } from '@/lib/auth';
import { query, queryOne } from '@/lib/db';
import { v4 as uuidv4 } from 'uuid';

export async function POST(request: NextRequest) {
  try {
    const { username, password } = await request.json() as { username: string; password: string };

    if (!username?.trim() || !password) {
      return NextResponse.json({ error: 'Username and password required' }, { status: 400 });
    }

    const normalizedUser = username.trim().toLowerCase();

    // 1. Validate credentials against Wazuh
    const wazuhOk = await authenticateUser(normalizedUser, password);
    if (!wazuhOk) {
      return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
    }

    // 2. Get or create portal user record
    let portalUser = await queryOne<{
      id: string; portal_role: string; tenant_id: string | null;
      wazuh_group: string | null; full_name: string | null; is_active: boolean;
    }>(
      `SELECT pu.id, pu.portal_role, pu.tenant_id, pu.full_name, pu.is_active,
              t.wazuh_group
       FROM portal_users pu
       LEFT JOIN tenants t ON t.id = pu.tenant_id
       WHERE pu.wazuh_username = $1`,
      [normalizedUser],
    );

    if (!portalUser) {
      // Auto-create on first login as 'client'
      const [created] = await query<{ id: string; portal_role: string; tenant_id: string | null }>(
        `INSERT INTO portal_users (wazuh_username, portal_role) VALUES ($1, 'client')
         ON CONFLICT (wazuh_username) DO UPDATE SET wazuh_username = EXCLUDED.wazuh_username
         RETURNING id, portal_role, tenant_id`,
        [normalizedUser],
      );
      portalUser = { ...created, wazuh_group: null, full_name: normalizedUser, is_active: true };
    }

    if (!portalUser.is_active) {
      return NextResponse.json({ error: 'Account disabled' }, { status: 403 });
    }

    // 3. Issue portal JWT using jose
    const jti = uuidv4();
    const token = await signToken({
      sub:          portalUser.id,
      username:     normalizedUser,
      role:         portalUser.portal_role as 'admin' | 'client',
      tenant_id:    portalUser.tenant_id ?? undefined,
      wazuh_group:  portalUser.wazuh_group ?? undefined,
      jti,
    });

    // 4. Store session for audit
    const ip = request.headers.get('x-forwarded-for')?.split(',')[0].trim()
            ?? request.headers.get('x-real-ip') ?? 'unknown';
    const ua = request.headers.get('user-agent') ?? '';
    await query(
      `INSERT INTO sessions (user_id, jti, ip_address, user_agent, expires_at)
       VALUES ($1, $2, $3, $4, NOW() + INTERVAL '8 hours')`,
      [portalUser.id, jti, ip, ua],
    ).catch(() => {}); // non-critical

    // 5. Update last_login
    await query(`UPDATE portal_users SET last_login = NOW() WHERE id = $1`, [portalUser.id]).catch(() => {});

    // 6. Audit
    await query(
      `INSERT INTO audit_logs (username, action, ip_address) VALUES ($1, 'LOGIN', $2)`,
      [normalizedUser, ip],
    ).catch(() => {});

    const response = NextResponse.json({
      user: {
        id:         portalUser.id,
        username:   normalizedUser,
        role:       portalUser.portal_role,
        tenant_id:  portalUser.tenant_id,
        full_name:  portalUser.full_name ?? normalizedUser,
        wazuh_group: portalUser.wazuh_group,
      },
    });

    response.cookies.set(COOKIE_NAME, token, COOKIE_OPTIONS);
    return response;
  } catch (err) {
    console.error('[LOGIN]', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
