export const dynamic = 'force-dynamic';
// frontend/src/app/api/wazuh/alerts/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getAlerts } from '@/lib/wazuh';

export const runtime = 'nodejs';

export async function GET(request: NextRequest) {
  const token = request.cookies.get(COOKIE_NAME)?.value;
  const payload = token ? await verifyToken(token) : null;
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const limit = Math.min(parseInt(searchParams.get('limit') ?? '50'), 500);
  const minLevel = parseInt(searchParams.get('level') ?? '0');
  const group = payload.role === 'admin' ? undefined : (payload.wazuh_group as string | undefined);

  try {
    const data = await getAlerts(group, limit, minLevel);
    // Normalize for frontend
    const alerts = data.items.map((a: any) => {
      const level = a.rule?.level ?? 0;
      return {
        id:         a.id ?? a._id ?? String(Math.random()),
        timestamp:  a.timestamp,
        severity:   level >= 13 ? 'CRITICAL' : level >= 10 ? 'HIGH' : level >= 7 ? 'MEDIUM' : level >= 4 ? 'LOW' : 'INFO',
        source:     a.agent?.name ?? 'unknown',
        agent_id:   a.agent?.id,
        agent_ip:   a.agent?.ip,
        rule_desc:  a.rule?.description ?? '',
        rule_level: level,
        rule_id:    a.rule?.id,
        rule_groups: a.rule?.groups ?? [],
        mitre:      a.rule?.mitre,
        location:   a.location,
      };
    });
    return NextResponse.json({ alerts, total: data.total });
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 502 });
  }
}
