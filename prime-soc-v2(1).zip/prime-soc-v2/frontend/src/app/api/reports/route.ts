export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getAlerts, getAgents, getFIMEvents, getSCAResults, getMitreStats, getComplianceStats } from '@/lib/wazuh';

export const runtime = 'nodejs';

function toPeriodRange(period: string, start?: string, end?: string): { from: Date; to: Date } {
  const to = end ? new Date(end) : new Date();
  let from: Date;
  switch (period) {
    case 'today': from = new Date(to); from.setHours(0, 0, 0, 0); break;
    case '7d':    from = new Date(to.getTime() - 7 * 86400_000); break;
    case '30d':   from = new Date(to.getTime() - 30 * 86400_000); break;
    case '90d':   from = new Date(to.getTime() - 90 * 86400_000); break;
    case 'custom': from = start ? new Date(start) : new Date(to.getTime() - 7 * 86400_000); break;
    default:       from = new Date(to.getTime() - 7 * 86400_000);
  }
  return { from, to };
}

function toCSV(rows: Record<string, unknown>[]): string {
  if (rows.length === 0) return '';
  const headers = Object.keys(rows[0]);
  const lines = [
    headers.join(','),
    ...rows.map(r => headers.map(h => {
      const v = r[h] ?? '';
      const s = typeof v === 'object' ? JSON.stringify(v) : String(v);
      return s.includes(',') || s.includes('"') || s.includes('\n') ? `"${s.replace(/"/g, '""')}"` : s;
    }).join(',')),
  ];
  return lines.join('\n');
}

export async function GET(request: NextRequest) {
  const token = request.cookies.get(COOKIE_NAME)?.value;
  const payload = token ? await verifyToken(token) : null;
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const type   = searchParams.get('type') ?? 'alerts';
  const period = searchParams.get('period') ?? '7d';
  const format = searchParams.get('format') ?? 'csv';
  const start  = searchParams.get('start') ?? undefined;
  const end    = searchParams.get('end') ?? undefined;

  const wazuhGroup = payload.role === 'admin' ? undefined : (payload.wazuh_group as string | undefined);
  const { from, to } = toPeriodRange(period, start, end);

  try {
    let rows: Record<string, unknown>[] = [];

    if (type === 'alerts') {
      const data = await getAlerts(wazuhGroup, 1000, 0);
      rows = data.items
        .filter((a: any) => !a.timestamp || new Date(a.timestamp) >= from)
        .map((a: any) => ({
          timestamp: a.timestamp,
          agent_id:  a.agent?.id,
          agent_name: a.agent?.name,
          agent_ip:  a.agent?.ip,
          rule_id:   a.rule?.id,
          rule_level: a.rule?.level,
          description: a.rule?.description,
          groups:    (a.rule?.groups ?? []).join('|'),
          mitre_id:  (a.rule?.mitre?.id ?? []).join('|'),
        }));
    }

    else if (type === 'agents') {
      const data = await getAgents(wazuhGroup, 1000);
      rows = data.items.map((a: any) => ({
        id: a.id, name: a.name, ip: a.ip, status: a.status,
        os_name: a.os?.name, os_version: a.os?.version,
        version: a.version,
        groups: (a.group ?? []).join('|'),
        last_keepalive: a.lastKeepAlive,
        date_added: a.dateAdd,
      }));
    }

    else if (type === 'fim') {
      const data = await getFIMEvents(wazuhGroup, 500);
      rows = data.map((f: any) => ({
        date: f.date, agent_id: f.agent_id, file: f.file,
        event_type: f.type, size: f.size, md5: f.md5, sha256: f.sha256,
      }));
    }

    else if (type === 'sca') {
      const data = await getSCAResults(wazuhGroup);
      rows = data.map((p: any) => ({
        agent_id: p.agent_id, policy_id: p.policy_id, name: p.name,
        score: p.score, passed: p.passed, failed: p.failed, total: p.total_checks,
      }));
    }

    else if (type === 'mitre') {
      const data = await getMitreStats(wazuhGroup);
      rows = data.map((m: any) => ({
        technique_id: m.id, technique: m.name, count: m.count, max_level: m.maxLevel,
      }));
    }

    else if (type === 'compliance') {
      const data = await getComplianceStats(wazuhGroup);
      rows = data.map((c: any) => ({ framework: c.name, event_count: c.count }));
    }

    else if (type === 'executive') {
      const [agentData, alertData] = await Promise.all([
        getAgents(wazuhGroup, 500),
        getAlerts(wazuhGroup, 500, 0),
      ]);
      const agents  = agentData.items as any[];
      const alerts  = alertData.items as any[];
      const active  = agents.filter(a => a.status === 'active').length;
      const critCount = alerts.filter((a: any) => (a.rule?.level ?? 0) >= 13).length;
      rows = [{
        report_date: new Date().toISOString(),
        total_agents: agentData.total,
        active_agents: active,
        disconnected_agents: agents.filter(a => a.status === 'disconnected').length,
        endpoint_health_pct: agentData.total > 0 ? ((active / agentData.total) * 100).toFixed(1) : 0,
        total_alerts: alertData.total,
        critical_alerts: critCount,
        high_alerts: alerts.filter((a: any) => { const l = a.rule?.level ?? 0; return l >= 10 && l < 13; }).length,
        medium_alerts: alerts.filter((a: any) => { const l = a.rule?.level ?? 0; return l >= 7 && l < 10; }).length,
        period_from: from.toISOString(),
        period_to:   to.toISOString(),
      }];
    }

    if (format === 'json') {
      return new NextResponse(JSON.stringify({ report: type, period, generated: new Date().toISOString(), data: rows }, null, 2), {
        status: 200,
        headers: {
          'Content-Type': 'application/json',
          'Content-Disposition': `attachment; filename="primesoc_${type}_${period}.json"`,
        },
      });
    }

    // CSV (default)
    const csv = toCSV(rows);
    return new NextResponse(csv, {
      status: 200,
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': `attachment; filename="primesoc_${type}_${period}.csv"`,
      },
    });
  } catch (err) {
    console.error('[REPORTS]', err);
    return NextResponse.json({ error: String(err) }, { status: 502 });
  }
}
