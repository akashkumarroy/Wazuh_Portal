export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { query } from '@/lib/db';
import { getGroups, createGroup } from '@/lib/wazuh';

export const runtime = 'nodejs';

function auth(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifyToken(token);
}

// GET /api/tenants
export async function GET(request: NextRequest) {
  const payload = await auth(request);
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  if (payload.role === 'admin') {
    const tenants = await query(`SELECT * FROM tenants ORDER BY name ASC`);
    return NextResponse.json({ tenants });
  }
  // Client: own tenant only
  if (!payload.tenant_id) return NextResponse.json({ tenants: [] });
  const tenants = await query(`SELECT * FROM tenants WHERE id = $1`, [payload.tenant_id]);
  return NextResponse.json({ tenants });
}

// POST /api/tenants — admin only
export async function POST(request: NextRequest) {
  const payload = await auth(request);
  if (!payload || payload.role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

  const { name, wazuh_group, industry } = await request.json();
  if (!name || !wazuh_group) return NextResponse.json({ error: 'name and wazuh_group required' }, { status: 400 });

  // Auto-create group in Wazuh if it doesn't exist
  try {
    await createGroup(wazuh_group);
  } catch {
    // Group may already exist — that's fine
  }

  try {
    const [tenant] = await query(
      `INSERT INTO tenants (name, wazuh_group, industry) VALUES ($1, $2, $3) RETURNING *`,
      [name, wazuh_group, industry || null],
    );
    return NextResponse.json({ tenant }, { status: 201 });
  } catch (err: any) {
    if (err.code === '23505') return NextResponse.json({ error: 'Wazuh group already mapped to a tenant' }, { status: 409 });
    throw err;
  }
}
