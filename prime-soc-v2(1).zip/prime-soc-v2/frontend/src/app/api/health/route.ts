export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { pool } from '@/lib/db';
export const runtime = 'nodejs';
export async function GET() {
  try { await pool.query('SELECT 1'); return NextResponse.json({ status:'ok', ts: new Date().toISOString() }); }
  catch { return NextResponse.json({ status:'degraded' }, { status: 503 }); }
}
