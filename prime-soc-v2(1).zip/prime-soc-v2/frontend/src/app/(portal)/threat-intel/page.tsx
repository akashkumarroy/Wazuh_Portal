'use client';
import { useState, useEffect } from 'react';

interface ThreatActor { id: string; name: string; description?: string; threat_actor_types?: string[]; }
interface Indicator { id: string; name: string; pattern_type: string; x_opencti_score: number; }

export default function ThreatIntelPage() {
  const [authenticated, setAuth] = useState(false);
  const [creds, setCreds] = useState({ u: '', p: '' });
  const [actors, setActors] = useState<ThreatActor[]>([]);
  const [indicators, setIndicators] = useState<Indicator[]>([]);
  const [iframeLoaded, setLoaded] = useState(false);
  const [authLoading, setAuthLoading] = useState(false);
  const [activeSubTab, setSubTab] = useState<'actors' | 'indicators' | 'reports'>('actors');

  useEffect(() => {
    if (!authenticated) return;
    fetch('/api/threat-intel/feed?type=actors').then(r => r.json())
      .then(d => setActors(d.actors ?? [])).catch(() => {});
    fetch('/api/threat-intel/feed?type=indicators').then(r => r.json())
      .then(d => setIndicators(d.indicators ?? [])).catch(() => {});
  }, [authenticated]);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    await new Promise(r => setTimeout(r, 500));
    setAuthLoading(false);
    setAuth(true);
  };

  const OPENCTI_PROXY = '/api/proxy/opencti/';

  return (
    <div className="flex flex-col h-full">
      <div className="px-5 pt-4 pb-3 shrink-0 border-b" style={{ borderColor: 'var(--border)' }}>
        <div className="flex items-center gap-3">
          <h1 className="font-bold text-white" style={{ fontSize: 20, letterSpacing: '-0.02em' }}>Threat Intelligence</h1>
          <span className="badge badge-info">OpenCTI</span>
        </div>
      </div>

      <div className="flex-1 flex min-h-0 overflow-hidden">
        {/* Main iframe area */}
        <div className="flex-1 relative overflow-hidden">
          {!authenticated ? (
            <div className="absolute inset-0 flex items-center justify-center"
              style={{ background: 'rgba(8,12,20,0.92)', backdropFilter: 'blur(8px)', zIndex: 20 }}>
              <div className="card p-8 w-full max-w-md animate-up">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-4"
                  style={{ background: 'rgba(0,216,232,0.12)', border: '1px solid rgba(0,216,232,0.3)' }}>
                  <svg className="w-6 h-6" style={{ color: 'var(--cyan)' }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                      d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064" />
                  </svg>
                </div>
                <h2 className="text-center font-bold text-white mb-1" style={{ fontSize: 16 }}>OpenCTI — Threat Intelligence</h2>
                <p className="text-center mono text-secondary mb-5" style={{ fontSize: 12 }}>
                  Authenticate to access threat intelligence platform
                </p>
                <form onSubmit={handleAuth} className="space-y-3">
                  <input className="field" type="text" placeholder="Email / Username" value={creds.u}
                    onChange={e => setCreds(p => ({ ...p, u: e.target.value }))} required />
                  <input className="field" type="password" placeholder="Password" value={creds.p}
                    onChange={e => setCreds(p => ({ ...p, p: e.target.value }))} required />
                  <button type="submit" disabled={authLoading || !creds.u || !creds.p}
                    className="w-full py-3 rounded-lg font-bold label-caps flex items-center justify-center gap-2 disabled:opacity-40"
                    style={{ background: 'var(--cyan)', color: '#001a1e', fontSize: 10 }}>
                    {authLoading
                      ? <><div className="w-3.5 h-3.5 border border-[#001a1e] border-t-transparent rounded-full animate-spin" />Authorizing…</>
                      : 'Access OpenCTI'}
                  </button>
                </form>
              </div>
            </div>
          ) : (
            <>
              {!iframeLoaded && (
                <div className="absolute inset-0 flex items-center justify-center z-10"
                  style={{ background: 'var(--bg-primary)' }}>
                  <div className="w-7 h-7 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
                </div>
              )}
              <iframe
                src={OPENCTI_PROXY}
                title="OpenCTI Threat Intelligence"
                className="tool-frame"
                onLoad={() => setLoaded(true)}
              />
            </>
          )}
        </div>

        {/* Intel Feed Sidebar */}
        {authenticated && (
          <div className="w-72 shrink-0 border-l flex flex-col overflow-hidden"
            style={{ borderColor: 'var(--border)', background: 'rgba(8,12,20,0.7)' }}>
            {/* Sub-tabs */}
            <div className="flex border-b shrink-0" style={{ borderColor: 'var(--border)' }}>
              {(['actors', 'indicators', 'reports'] as const).map(t => (
                <button key={t} onClick={() => setSubTab(t)}
                  className="flex-1 py-2 label-caps transition-colors"
                  style={{
                    fontSize: 8,
                    color: activeSubTab === t ? 'var(--cyan)' : 'var(--text-dim)',
                    borderBottom: activeSubTab === t ? '1px solid var(--cyan)' : '1px solid transparent',
                    marginBottom: -1,
                  }}>
                  {t}
                </button>
              ))}
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {/* Actors */}
              {activeSubTab === 'actors' && (
                actors.length === 0
                  ? <p className="mono text-dim text-center py-8" style={{ fontSize: 11 }}>Fetching threat actors…</p>
                  : actors.slice(0, 15).map((a) => (
                    <div key={a.id} className="card-hover p-3 rounded-lg cursor-pointer">
                      <p className="font-semibold text-white mb-1" style={{ fontSize: 12 }}>{a.name}</p>
                      {a.threat_actor_types?.length && (
                        <div className="flex gap-1 flex-wrap mb-1">
                          {a.threat_actor_types.slice(0, 2).map(t => (
                            <span key={t} className="badge badge-info" style={{ fontSize: 8 }}>{t}</span>
                          ))}
                        </div>
                      )}
                      {a.description && (
                        <p className="mono text-secondary" style={{ fontSize: 10, lineHeight: 1.4 }}>
                          {a.description.slice(0, 90)}…
                        </p>
                      )}
                    </div>
                  ))
              )}

              {/* Indicators / IOCs */}
              {activeSubTab === 'indicators' && (
                indicators.length === 0
                  ? <p className="mono text-dim text-center py-8" style={{ fontSize: 11 }}>Fetching IOCs…</p>
                  : indicators.slice(0, 20).map((ind) => (
                    <div key={ind.id} className="card-hover p-3 rounded-lg cursor-pointer">
                      <div className="flex items-center justify-between mb-1">
                        <span className="badge badge-warning" style={{ fontSize: 8 }}>{ind.pattern_type}</span>
                        <span className="mono" style={{ fontSize: 9, color: ind.x_opencti_score >= 80 ? 'var(--red)' : ind.x_opencti_score >= 50 ? 'var(--amber)' : 'var(--green)' }}>
                          Score: {ind.x_opencti_score}
                        </span>
                      </div>
                      <p className="mono text-secondary" style={{ fontSize: 10 }}>{ind.name?.slice(0, 60)}</p>
                    </div>
                  ))
              )}

              {/* Reports */}
              {activeSubTab === 'reports' && (
                <p className="mono text-dim text-center py-8" style={{ fontSize: 11 }}>
                  Reports available inside OpenCTI interface →
                </p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
