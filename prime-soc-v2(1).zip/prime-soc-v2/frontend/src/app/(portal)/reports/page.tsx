'use client';
import { useState } from 'react';

const REPORTS = [
  { id: 'alerts',       title: 'Security Alerts Report',         desc: 'All alerts by severity, rule, agent. Grouped by time period.',     color: 'var(--red)' },
  { id: 'agents',       title: 'Endpoint Health Report',         desc: 'Agent status, OS, version, last keepalive, group membership.',     color: 'var(--cyan)' },
  { id: 'fim',          title: 'File Integrity Report',          desc: 'All FIM events: modified, added, deleted files per agent.',        color: 'var(--amber)' },
  { id: 'sca',          title: 'Configuration Assessment',       desc: 'SCA scores per policy, failed checks, agent compliance summary.',  color: 'var(--green)' },
  { id: 'vulnerability',title: 'Vulnerability Report',           desc: 'CVEs by severity, affected agents, CVSS scores.',                 color: '#f59e0b' },
  { id: 'compliance',   title: 'Compliance Report',              desc: 'PCI-DSS, HIPAA, GDPR, NIST 800-53, TSC alert mapping.',           color: '#a78bfa' },
  { id: 'mitre',        title: 'MITRE ATT&CK Coverage',         desc: 'Detected techniques, tactic mapping, top techniques by frequency.', color: 'var(--cyan)' },
  { id: 'executive',    title: 'Executive Summary',              desc: 'Risk score, critical incidents, SLA, compliance status overview.', color: 'var(--green)' },
];

type Period = 'today' | '7d' | '30d' | '90d' | 'custom';
type Format = 'pdf' | 'csv' | 'json';

export default function ReportsPage() {
  const [period, setPeriod] = useState<Period>('7d');
  const [format, setFormat] = useState<Format>('pdf');
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd]     = useState('');
  const [generating, setGenerating]   = useState<string | null>(null);

  const handleGenerate = async (reportId: string) => {
    setGenerating(reportId);
    try {
      const params = new URLSearchParams({ type: reportId, period, format });
      if (period === 'custom' && customStart && customEnd) {
        params.set('start', customStart);
        params.set('end', customEnd);
      }
      const res = await fetch(`/api/reports?${params.toString()}`);
      if (!res.ok) { alert('Report generation failed. Check Wazuh API connectivity.'); return; }
      const blob = await res.blob();
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a');
      a.href     = url;
      a.download = `primesoc_${reportId}_${period}_${new Date().toISOString().split('T')[0]}.${format}`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      alert('Error generating report: ' + String(e));
    } finally {
      setGenerating(null);
    }
  };

  return (
    <div className="p-5 space-y-5">
      <div>
        <h1 className="font-bold text-white" style={{ fontSize: 20, letterSpacing: '-0.02em' }}>Security Reports</h1>
        <p className="mono text-secondary mt-0.5" style={{ fontSize: 11 }}>
          Generate and download reports. Data fetched live from Wazuh.
        </p>
      </div>

      {/* Controls */}
      <div className="card p-4 flex flex-wrap items-end gap-4">
        <div>
          <p className="label-caps text-dim mb-2" style={{ fontSize: 8 }}>Time Period</p>
          <div className="flex gap-1.5">
            {(['today', '7d', '30d', '90d', 'custom'] as Period[]).map(p => (
              <button key={p} onClick={() => setPeriod(p)}
                className="label-caps px-3 py-1.5 rounded-lg transition-colors"
                style={{
                  fontSize: 8,
                  background: period === p ? 'rgba(0,216,232,0.15)' : 'transparent',
                  border: `1px solid ${period === p ? 'rgba(0,216,232,0.4)' : 'var(--border)'}`,
                  color: period === p ? 'var(--cyan)' : 'var(--text-dim)',
                }}>
                {p === 'today' ? 'Today' : p === '7d' ? '7 Days' : p === '30d' ? '30 Days' : p === '90d' ? '90 Days' : 'Custom'}
              </button>
            ))}
          </div>
        </div>

        {period === 'custom' && (
          <div className="flex items-end gap-2">
            <div>
              <p className="label-caps text-dim mb-2" style={{ fontSize: 8 }}>From</p>
              <input type="datetime-local" value={customStart} onChange={e => setCustomStart(e.target.value)}
                className="field py-1.5" style={{ fontSize: 12, width: 180 }} />
            </div>
            <div>
              <p className="label-caps text-dim mb-2" style={{ fontSize: 8 }}>To</p>
              <input type="datetime-local" value={customEnd} onChange={e => setCustomEnd(e.target.value)}
                className="field py-1.5" style={{ fontSize: 12, width: 180 }} />
            </div>
          </div>
        )}

        <div>
          <p className="label-caps text-dim mb-2" style={{ fontSize: 8 }}>Format</p>
          <div className="flex gap-1.5">
            {(['pdf', 'csv', 'json'] as Format[]).map(f => (
              <button key={f} onClick={() => setFormat(f)}
                className="label-caps px-3 py-1.5 rounded-lg uppercase transition-colors"
                style={{
                  fontSize: 8,
                  background: format === f ? 'rgba(0,216,232,0.12)' : 'transparent',
                  border: `1px solid ${format === f ? 'rgba(0,216,232,0.35)' : 'var(--border)'}`,
                  color: format === f ? 'var(--cyan)' : 'var(--text-dim)',
                }}>
                {f}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Report cards */}
      <div className="grid grid-cols-4 gap-4">
        {REPORTS.map(r => (
          <div key={r.id} className="card-hover p-4 flex flex-col rounded-xl cursor-default">
            <div className="w-9 h-9 rounded-lg flex items-center justify-center mb-3 shrink-0"
              style={{ background: `${r.color}15`, border: `1px solid ${r.color}30` }}>
              <svg className="w-4 h-4" style={{ color: r.color }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8}
                  d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <p className="font-semibold text-white mb-1" style={{ fontSize: 13 }}>{r.title}</p>
            <p className="mono text-secondary mb-4 leading-relaxed flex-1" style={{ fontSize: 10 }}>{r.desc}</p>
            <button onClick={() => handleGenerate(r.id)}
              disabled={generating === r.id}
              className="w-full py-2 rounded-lg label-caps flex items-center justify-center gap-1.5 transition-all disabled:opacity-40"
              style={{ border: `1px solid ${r.color}40`, color: r.color, background: `${r.color}08`, fontSize: 8 }}>
              {generating === r.id
                ? <><div className="w-3 h-3 border border-current border-t-transparent rounded-full animate-spin" />Generating…</>
                : <><svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>Download {format.toUpperCase()}</>}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
