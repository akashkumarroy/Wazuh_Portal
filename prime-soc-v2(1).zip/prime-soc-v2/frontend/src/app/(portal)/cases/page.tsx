'use client';
import { useState, useEffect } from 'react';

export default function CasesPage() {
  const [authenticated, setAuth] = useState(false);
  const [creds, setCreds] = useState({ u: '', p: '' });
  const [stats, setStats] = useState<{ total: number; open: number; in_progress: number; closed: number } | null>(null);
  const [iframeLoaded, setLoaded] = useState(false);
  const [authLoading, setAuthLoading] = useState(false);

  useEffect(() => {
    fetch('/api/cases?stats=true').then(r => r.json()).then(setStats).catch(() => {});
  }, []);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    await new Promise(r => setTimeout(r, 500));
    setAuthLoading(false);
    setAuth(true);
  };

  const IRIS_PROXY = '/api/proxy/iris/';

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 pt-4 pb-4 shrink-0 border-b" style={{ borderColor: 'var(--border)' }}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="font-bold text-white" style={{ fontSize: 20, letterSpacing: '-0.02em' }}>Case Management</h1>
            <p className="mono text-secondary mt-0.5" style={{ fontSize: 11 }}>Incident Response & Case Tracking — IRIS</p>
          </div>
          <button className="label-caps px-4 py-2 rounded-lg"
            style={{ border: '1px solid var(--cyan)', color: 'var(--cyan)', background: 'rgba(0,216,232,0.07)', fontSize: 9 }}>
            + New Case
          </button>
        </div>
        <div className="grid grid-cols-4 gap-3">
          {[
            { label: 'Total Cases', value: stats?.total ?? '—', color: 'var(--cyan)' },
            { label: 'Open', value: stats?.open ?? '—', color: 'var(--red)' },
            { label: 'In Progress', value: stats?.in_progress ?? '—', color: 'var(--amber)' },
            { label: 'Closed', value: stats?.closed ?? '—', color: 'var(--green)' },
          ].map(s => (
            <div key={s.label} className="card px-3 py-2 text-center">
              <p className="label-caps text-dim" style={{ fontSize: 8 }}>{s.label}</p>
              <p className="stat-value mt-1" style={{ fontSize: 20, color: s.color }}>{s.value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Main */}
      <div className="flex-1 relative overflow-hidden">
        {!authenticated ? (
          <div className="absolute inset-0 flex items-center justify-center"
            style={{ background: 'rgba(8,12,20,0.92)', backdropFilter: 'blur(8px)', zIndex: 20 }}>
            <div className="card p-8 w-full max-w-md animate-up">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-4"
                style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.25)' }}>
                <svg className="w-6 h-6 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                    d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
              </div>
              <h2 className="text-center font-bold text-white mb-1" style={{ fontSize: 16 }}>IRIS Case Management</h2>
              <p className="text-center mono text-secondary mb-5" style={{ fontSize: 12 }}>
                Authenticate to access incident response cases
              </p>
              <form onSubmit={handleAuth} className="space-y-3">
                <input className="field" type="text" placeholder="Username" value={creds.u}
                  onChange={e => setCreds(p => ({ ...p, u: e.target.value }))} required />
                <input className="field" type="password" placeholder="Password" value={creds.p}
                  onChange={e => setCreds(p => ({ ...p, p: e.target.value }))} required />
                <button type="submit" disabled={authLoading || !creds.u || !creds.p}
                  className="w-full py-3 rounded-lg font-bold label-caps flex items-center justify-center gap-2 disabled:opacity-40"
                  style={{ background: '#ef4444', color: 'white', fontSize: 10 }}>
                  {authLoading
                    ? <><div className="w-3.5 h-3.5 border border-white border-t-transparent rounded-full animate-spin" />Authorizing…</>
                    : 'Access IRIS'}
                </button>
              </form>
            </div>
          </div>
        ) : (
          <>
            {!iframeLoaded && (
              <div className="absolute inset-0 flex items-center justify-center z-10"
                style={{ background: 'var(--bg-primary)' }}>
                <div className="w-7 h-7 border-2 border-red-400 border-t-transparent rounded-full animate-spin" />
              </div>
            )}
            <iframe
              src={IRIS_PROXY}
              title="IRIS Case Management"
              className="tool-frame"
              onLoad={() => setLoaded(true)}
              sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox"
            />
          </>
        )}
      </div>
    </div>
  );
}
