'use client';
import { useState, useEffect } from 'react';

interface User { id:string; wazuh_username:string; portal_role:string; full_name:string|null; email:string|null; is_active:boolean; last_login:string|null; tenant_name:string|null; wazuh_group:string|null; created_at:string; }
interface Tenant { id:string; name:string; wazuh_group:string; }

export default function AdminUsersPage() {
  const [users, setUsers]     = useState<User[]>([]);
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [creating, setCreating]     = useState(false);
  const [form, setForm] = useState({ wazuh_username:'', portal_role:'client', tenant_id:'', full_name:'', email:'' });
  const [error, setError]   = useState('');
  const [success, setSuccess] = useState('');

  const fetchAll = async () => {
    const [ur, tr] = await Promise.allSettled([
      fetch('/api/users').then(r=>r.json()),
      fetch('/api/tenants').then(r=>r.json()),
    ]);
    if (ur.status==='fulfilled') setUsers(ur.value.users??[]);
    if (tr.status==='fulfilled') setTenants(tr.value.tenants??[]);
    setLoading(false);
  };

  useEffect(() => { fetchAll(); }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault(); setCreating(true); setError(''); setSuccess('');
    try {
      const res = await fetch('/api/users', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(form) });
      const d = await res.json();
      if (!res.ok) { setError(d.error ?? 'Failed'); return; }
      setSuccess(`User "${form.wazuh_username}" registered. They can now login with their Wazuh credentials.`);
      setShowCreate(false); setForm({ wazuh_username:'', portal_role:'client', tenant_id:'', full_name:'', email:'' });
      fetchAll();
    } finally { setCreating(false); }
  };

  const handleToggle = async (id: string, active: boolean) => {
    await fetch(`/api/users/${id}`, { method:'PATCH', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ is_active: !active }) });
    fetchAll();
  };

  return (
    <div className="p-5 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-bold text-white" style={{ fontSize:20, letterSpacing:'-0.02em' }}>User Management</h1>
          <p className="mono text-secondary mt-0.5" style={{ fontSize:11 }}>
            {users.length} portal users · Authentication via Wazuh IAM
          </p>
        </div>
        <button onClick={()=>{setShowCreate(true);setError('');setSuccess('');}}
          className="label-caps px-4 py-2 rounded-lg" style={{ background:'var(--cyan)', color:'#001a1e', fontSize:9 }}>
          + Register User
        </button>
      </div>

      {success && (
        <div className="px-4 py-3 rounded-xl mono" style={{ background:'rgba(16,185,129,0.1)', border:'1px solid rgba(16,185,129,0.25)', color:'#6ee7b7', fontSize:12 }}>
          ✓ {success}
        </div>
      )}

      {/* Info box */}
      <div className="px-4 py-3 rounded-xl flex items-start gap-2"
        style={{ background:'rgba(0,216,232,0.06)', border:'1px solid rgba(0,216,232,0.15)' }}>
        <svg className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
        <p className="mono text-secondary" style={{ fontSize:11 }}>
          Users authenticate using their <strong className="text-white">Wazuh credentials</strong>. Register their Wazuh username here to assign them a portal role and tenant.
        </p>
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        {loading ? (
          <div className="py-12 flex items-center justify-center">
            <div className="w-6 h-6 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <table className="data-table">
            <thead>
              <tr><th>Username</th><th>Full Name</th><th>Role</th><th>Tenant</th><th>Last Login</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id}>
                  <td>
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full flex items-center justify-center font-bold"
                        style={{ fontSize:9, background: u.portal_role==='admin'?'rgba(0,216,232,0.2)':'rgba(124,58,237,0.2)', color: u.portal_role==='admin'?'var(--cyan)':'#a78bfa' }}>
                        {u.wazuh_username.slice(0,2).toUpperCase()}
                      </div>
                      <span className="mono text-white font-semibold" style={{ fontSize:12 }}>{u.wazuh_username}</span>
                    </div>
                  </td>
                  <td className="text-secondary" style={{ fontSize:12 }}>{u.full_name ?? '—'}</td>
                  <td>
                    <span className="label-caps px-2 py-0.5 rounded"
                      style={{ fontSize:8, background: u.portal_role==='admin'?'rgba(0,216,232,0.12)':'rgba(124,58,237,0.12)', color: u.portal_role==='admin'?'var(--cyan)':'#a78bfa' }}>
                      {u.portal_role}
                    </span>
                  </td>
                  <td className="text-secondary" style={{ fontSize:12 }}>{u.tenant_name ?? '—'}</td>
                  <td className="mono text-dim" style={{ fontSize:11 }}>
                    {u.last_login ? new Date(u.last_login).toLocaleString() : 'Never'}
                  </td>
                  <td>
                    <span className="label-caps px-2 py-0.5 rounded"
                      style={{ fontSize:8, background: u.is_active?'rgba(16,185,129,0.12)':'rgba(71,85,105,0.2)', color: u.is_active?'var(--green)':'var(--text-dim)' }}>
                      {u.is_active ? 'Active' : 'Disabled'}
                    </span>
                  </td>
                  <td>
                    <button onClick={()=>handleToggle(u.id, u.is_active)}
                      className="label-caps px-2 py-0.5 rounded transition-colors hover:text-white text-dim"
                      style={{ border:'1px solid var(--border)', fontSize:8 }}>
                      {u.is_active ? 'Disable' : 'Enable'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Create Modal */}
      {showCreate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center"
          style={{ background:'rgba(0,0,0,0.75)', backdropFilter:'blur(8px)' }}>
          <div className="card p-7 w-full max-w-md rounded-2xl animate-up">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-bold text-white" style={{ fontSize:16 }}>Register Portal User</h3>
              <button onClick={()=>setShowCreate(false)} className="text-dim hover:text-white">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/></svg>
              </button>
            </div>
            {error && <div className="mb-4 px-3 py-2 rounded-lg mono" style={{ background:'rgba(239,68,68,0.1)', border:'1px solid rgba(239,68,68,0.25)', color:'#fca5a5', fontSize:12 }}>{error}</div>}
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="label-caps text-dim block mb-1.5" style={{ fontSize:8 }}>Wazuh Username *</label>
                <input className="field" placeholder="Must match Wazuh username exactly" value={form.wazuh_username}
                  onChange={e=>setForm(p=>({...p,wazuh_username:e.target.value.toLowerCase()}))} required/>
              </div>
              <div>
                <label className="label-caps text-dim block mb-1.5" style={{ fontSize:8 }}>Full Name</label>
                <input className="field" placeholder="Display name" value={form.full_name}
                  onChange={e=>setForm(p=>({...p,full_name:e.target.value}))}/>
              </div>
              <div>
                <label className="label-caps text-dim block mb-1.5" style={{ fontSize:8 }}>Email</label>
                <input className="field" type="email" placeholder="user@company.com" value={form.email}
                  onChange={e=>setForm(p=>({...p,email:e.target.value}))}/>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label-caps text-dim block mb-1.5" style={{ fontSize:8 }}>Portal Role *</label>
                  <select className="field" value={form.portal_role} onChange={e=>setForm(p=>({...p,portal_role:e.target.value}))}>
                    <option value="client">Client</option>
                    <option value="admin">Admin</option>
                  </select>
                </div>
                {form.portal_role === 'client' && (
                  <div>
                    <label className="label-caps text-dim block mb-1.5" style={{ fontSize:8 }}>Tenant</label>
                    <select className="field" value={form.tenant_id} onChange={e=>setForm(p=>({...p,tenant_id:e.target.value}))}>
                      <option value="">Select tenant…</option>
                      {tenants.map(t=><option key={t.id} value={t.id}>{t.name}</option>)}
                    </select>
                  </div>
                )}
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={()=>setShowCreate(false)}
                  className="flex-1 py-2.5 rounded-lg label-caps text-secondary" style={{ border:'1px solid var(--border)', fontSize:9 }}>
                  Cancel
                </button>
                <button type="submit" disabled={creating}
                  className="flex-1 py-2.5 rounded-lg label-caps disabled:opacity-40" style={{ background:'var(--cyan)', color:'#001a1e', fontSize:9 }}>
                  {creating ? 'Registering…' : 'Register User'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
