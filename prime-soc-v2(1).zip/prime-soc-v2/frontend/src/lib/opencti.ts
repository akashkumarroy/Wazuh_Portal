// OpenCTI GraphQL client
async function gql<T>(query: string, variables?: Record<string,unknown>): Promise<T> {
  const res = await fetch(`${process.env.OPENCTI_URL}/graphql`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.OPENCTI_API_KEY}`,
    },
    body: JSON.stringify({ query, variables }),
  });
  if (!res.ok) throw new Error(`OpenCTI ${res.status}`);
  const json = await res.json() as { data?: T; errors?: unknown[] };
  if (json.errors?.length) throw new Error(`OpenCTI GraphQL error: ${JSON.stringify(json.errors[0])}`);
  return json.data as T;
}

export async function getThreatActors(limit = 20) {
  try {
    const d = await gql<any>(`query{threatActors(first:${limit},orderBy:modified,orderMode:desc){edges{node{id name description threat_actor_types sophistication first_seen last_seen}}}}`);
    return d?.threatActors?.edges?.map((e:any) => e.node) ?? [];
  } catch { return []; }
}

export async function getIndicators(limit = 30) {
  try {
    const d = await gql<any>(`query{indicators(first:${limit},orderBy:modified,orderMode:desc){edges{node{id name pattern pattern_type valid_from confidence x_opencti_score}}}}`);
    return d?.indicators?.edges?.map((e:any) => e.node) ?? [];
  } catch { return []; }
}

export async function getReports(limit = 20) {
  try {
    const d = await gql<any>(`query{reports(first:${limit},orderBy:published,orderMode:desc){edges{node{id name description published confidence report_types}}}}`);
    return d?.reports?.edges?.map((e:any) => e.node) ?? [];
  } catch { return []; }
}
