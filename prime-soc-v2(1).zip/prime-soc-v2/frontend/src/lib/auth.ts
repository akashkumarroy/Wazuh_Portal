// Uses `jose` — NOT `jsonwebtoken` — Edge Runtime compatible
import { SignJWT, jwtVerify, type JWTPayload } from 'jose';

export const COOKIE_NAME = 'primesoc_token';

export interface PortalJWT extends JWTPayload {
  sub: string;         // portal_user.id
  username: string;
  role: 'admin' | 'client';
  tenant_id?: string;
  wazuh_group?: string;
  jti: string;
}

function getSecret(): Uint8Array {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error('JWT_SECRET not set');
  return new TextEncoder().encode(secret);
}

export async function signToken(payload: Omit<PortalJWT, 'iat' | 'exp'>): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('8h')
    .sign(getSecret());
}

export async function verifyToken(token: string): Promise<PortalJWT | null> {
  try {
    const { payload } = await jwtVerify(token, getSecret());
    return payload as PortalJWT;
  } catch {
    return null;
  }
}

export const COOKIE_OPTIONS = {
  httpOnly: true,
  secure: false,          // false until HTTPS configured — from troubleshooting doc
  sameSite: 'lax' as const,
  path: '/',
  maxAge: 8 * 60 * 60,   // 8 hours in seconds
};
