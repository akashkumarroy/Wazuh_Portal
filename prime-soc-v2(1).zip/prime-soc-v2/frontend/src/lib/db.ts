import { Pool } from 'pg';

declare global {
  // eslint-disable-next-line no-var
  var __pool: Pool | undefined;
}

// Lazy singleton — pool is only created on first actual query, not at module load.
// This prevents "DATABASE_URL not set" errors during Next.js build-time static analysis.
function getPool(): Pool {
  if (global.__pool) return global.__pool;
  const url = process.env.DATABASE_URL;
  if (!url) throw new Error('DATABASE_URL not set — check your .env file');
  const p = new Pool({
    connectionString: url,
    ssl: false,
    max: 20,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 10_000,
  });
  global.__pool = p;
  return p;
}

export const pool = {
  query: (...args: Parameters<Pool['query']>) => getPool().query(...(args as [any])),
  connect: () => getPool().connect(),
};

export async function query<T = Record<string, unknown>>(
  sql: string,
  params?: unknown[],
): Promise<T[]> {
  const client = await getPool().connect();
  try {
    const { rows } = await client.query(sql, params);
    return rows as T[];
  } finally {
    client.release();
  }
}

export async function queryOne<T = Record<string, unknown>>(
  sql: string,
  params?: unknown[],
): Promise<T | null> {
  const rows = await query<T>(sql, params);
  return rows[0] ?? null;
}

export async function query<T = Record<string, unknown>>(
  sql: string,
  params?: unknown[],
): Promise<T[]> {
  const client = await pool.connect();
  try {
    const { rows } = await client.query(sql, params);
    return rows as T[];
  } finally {
    client.release();
  }
}

export async function queryOne<T = Record<string, unknown>>(
  sql: string,
  params?: unknown[],
): Promise<T | null> {
  const rows = await query<T>(sql, params);
  return rows[0] ?? null;
}
