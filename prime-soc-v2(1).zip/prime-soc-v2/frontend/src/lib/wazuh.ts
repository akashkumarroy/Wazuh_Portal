import https from 'https';

const WAZUH_API   = process.env.WAZUH_API_URL!;
const WAZUH_USER  = process.env.WAZUH_API_USER ?? 'wazuh';
const WAZUH_PASS  = process.env.WAZUH_API_PASS!;

// Bypass self-signed cert for Wazuh API
const agent = new https.Agent({ rejectUnauthorized: false });

// Token cache — reuse across requests (expires in ~900s)
let _token: string | null = null;
let _tokenExpiry = 0;

async function getToken(): Promise<string> {
  if (_token && Date.now() < _tokenExpiry) return _token;
  const creds = Buffer.from(`${WAZUH_USER}:${WAZUH_PASS}`).toString('base64');
  const res = await fetch(`${WAZUH_API}/security/user/authenticate?raw=true`, {
    method: 'POST',
    headers: { Authorization: `Basic ${creds}` },
    // @ts-ignore
    agent,
  });
  if (!res.ok) throw new Error(`Wazuh auth failed: ${res.status}`);
  _token = (await res.text()).trim();
  _tokenExpiry = Date.now() + 870_000; // 14.5 min cache
  return _token!;
}

async function wazuh<T>(path: string, opts: { method?: string; body?: unknown } = {}): Promise<T> {
  const token = await getToken();
  const res = await fetch(`${WAZUH_API}${path}`, {
    method: opts.method ?? 'GET',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
    // @ts-ignore
    agent,
  });
  if (res.status === 401) { _token = null; return wazuh<T>(path, opts); }
  if (!res.ok) throw new Error(`Wazuh ${path} → ${res.status}`);
  return res.json() as Promise<T>;
}

// ── Authenticate a user against Wazuh (for portal login) ─────
export async function authenticateUser(username: string, password: string): Promise<boolean> {
  try {
    const creds = Buffer.from(`${username}:${password}`).toString('base64');
    const res = await fetch(`${WAZUH_API}/security/user/authenticate?raw=true`, {
      method: 'POST',
      headers: { Authorization: `Basic ${creds}` },
      // @ts-ignore
      agent,
    });
    return res.ok;
  } catch {
    return false;
  }
}

// ── Agent summary ─────────────────────────────────────────────
export async function getAgentSummary(wazuhGroup?: string) {
  if (wazuhGroup) {
    const r = await wazuh<any>(`/agents?groups_list=${wazuhGroup}&limit=1`);
    const all = await wazuh<any>(`/agents?groups_list=${wazuhGroup}&limit=500`);
    const items: any[] = all.data?.affected_items ?? [];
    return {
      total:        r.data?.total_affected_items ?? 0,
      active:       items.filter((a: any) => a.status === 'active').length,
      disconnected: items.filter((a: any) => a.status === 'disconnected').length,
      never:        items.filter((a: any) => a.status === 'never_connected').length,
      pending:      items.filter((a: any) => a.status === 'pending').length,
    };
  }
  const r = await wazuh<any>('/agents/summary/status');
  const conn = r.data?.connection ?? {};
  return {
    total:        conn.total ?? 0,
    active:       conn.active ?? 0,
    disconnected: conn.disconnected ?? 0,
    never:        conn.never_connected ?? 0,
    pending:      conn.pending ?? 0,
  };
}

// ── Agents list ───────────────────────────────────────────────
export async function getAgents(wazuhGroup?: string, limit = 500) {
  const group = wazuhGroup ? `&groups_list=${wazuhGroup}` : '';
  const r = await wazuh<any>(`/agents?limit=${limit}&offset=0${group}&sort=name`);
  return { items: r.data?.affected_items ?? [], total: r.data?.total_affected_items ?? 0 };
}

// ── Get agent IDs for a group ─────────────────────────────────
async function getGroupAgentIds(wazuhGroup: string): Promise<string[]> {
  const r = await getAgents(wazuhGroup, 1000);
  return r.items.map((a: any) => a.id);
}

// ── Alerts ────────────────────────────────────────────────────
export async function getAlerts(wazuhGroup?: string, limit = 100, minLevel = 0) {
  let agentFilter = '';
  if (wazuhGroup) {
    const ids = await getGroupAgentIds(wazuhGroup);
    if (ids.length === 0) return { items: [], total: 0 };
    agentFilter = `&agents_list=${ids.slice(0, 100).join(',')}`;
  }
  const levelFilter = minLevel > 0 ? `&level=${minLevel}-15` : '';
  const r = await wazuh<any>(`/alerts?limit=${limit}&sort=-timestamp${levelFilter}${agentFilter}`);
  return { items: r.data?.affected_items ?? [], total: r.data?.total_affected_items ?? 0 };
}

export async function getCriticalAlerts(wazuhGroup?: string) {
  return getAlerts(wazuhGroup, 50, 12);
}

// ── Security events (same as alerts, with more fields) ────────
export async function getSecurityEvents(wazuhGroup?: string, limit = 50) {
  return getAlerts(wazuhGroup, limit, 0);
}

// ── MITRE techniques from alerts ──────────────────────────────
export async function getMitreStats(wazuhGroup?: string) {
  const { items } = await getAlerts(wazuhGroup, 500, 0);
  const map: Record<string, { id: string; name: string; count: number; maxLevel: number }> = {};
  for (const a of items) {
    const mitre = a.rule?.mitre;
    if (!mitre?.id?.length) continue;
    for (let i = 0; i < mitre.id.length; i++) {
      const tid = mitre.id[i];
      const tname = mitre.technique?.[i] ?? tid;
      if (!map[tid]) map[tid] = { id: tid, name: tname, count: 0, maxLevel: 0 };
      map[tid].count++;
      map[tid].maxLevel = Math.max(map[tid].maxLevel, a.rule?.level ?? 0);
    }
  }
  return Object.values(map).sort((a, b) => b.count - a.count).slice(0, 30);
}

// ── FIM (File Integrity Monitoring) ──────────────────────────
export async function getFIMEvents(wazuhGroup?: string, limit = 50) {
  let agentIds: string[] = [];
  if (wazuhGroup) {
    agentIds = await getGroupAgentIds(wazuhGroup);
    if (agentIds.length === 0) return [];
  } else {
    const { items } = await getAgents(undefined, 20);
    agentIds = items.slice(0, 20).map((a: any) => a.id);
  }

  const results: any[] = [];
  for (const id of agentIds.slice(0, 5)) {
    try {
      const r = await wazuh<any>(`/syscheck/${id}?limit=${limit}&sort=-date`);
      const events = (r.data?.affected_items ?? []).map((e: any) => ({ ...e, agent_id: id }));
      results.push(...events);
    } catch { /* agent may not have FIM */ }
  }
  return results.slice(0, limit);
}

// ── SCA (Security Configuration Assessment) ──────────────────
export async function getSCAResults(wazuhGroup?: string) {
  let agentIds: string[] = [];
  if (wazuhGroup) {
    agentIds = await getGroupAgentIds(wazuhGroup);
  } else {
    const { items } = await getAgents(undefined, 10);
    agentIds = items.slice(0, 10).map((a: any) => a.id);
  }

  const results: any[] = [];
  for (const id of agentIds.slice(0, 10)) {
    try {
      const r = await wazuh<any>(`/sca/${id}`);
      const policies = (r.data?.affected_items ?? []).map((p: any) => ({ ...p, agent_id: id }));
      results.push(...policies);
    } catch {}
  }
  return results;
}

// ── Vulnerability ─────────────────────────────────────────────
export async function getVulnerabilityStats(wazuhGroup?: string) {
  let agentIds: string[] = [];
  if (wazuhGroup) {
    agentIds = await getGroupAgentIds(wazuhGroup);
  } else {
    const { items } = await getAgents(undefined, 20);
    agentIds = items.filter((a: any) => a.status === 'active').slice(0, 20).map((a: any) => a.id);
  }

  const summary = { critical: 0, high: 0, medium: 0, low: 0, total: 0 };
  const perAgent: { agent_id: string; name: string; count: number }[] = [];

  for (const id of agentIds.slice(0, 10)) {
    try {
      const r = await wazuh<any>(`/vulnerability/${id}/summary/severity`);
      const data = r.data?.affected_items?.[0] ?? {};
      const agentTotal = (data.Critical ?? 0) + (data.High ?? 0) + (data.Medium ?? 0) + (data.Low ?? 0);
      summary.critical += data.Critical ?? 0;
      summary.high     += data.High ?? 0;
      summary.medium   += data.Medium ?? 0;
      summary.low      += data.Low ?? 0;
      summary.total    += agentTotal;

      const ag = agentIds && await getAgentName(id);
      if (agentTotal > 0) perAgent.push({ agent_id: id, name: ag ?? id, count: agentTotal });
    } catch {}
  }

  return { summary, perAgent: perAgent.sort((a, b) => b.count - a.count).slice(0, 10) };
}

async function getAgentName(agentId: string): Promise<string> {
  try {
    const r = await wazuh<any>(`/agents?agents_list=${agentId}`);
    return r.data?.affected_items?.[0]?.name ?? agentId;
  } catch {
    return agentId;
  }
}

// ── Compliance (rules tagged with frameworks) ─────────────────
export async function getComplianceStats(wazuhGroup?: string) {
  const { items } = await getAlerts(wazuhGroup, 500, 0);

  const frameworks: Record<string, { name: string; count: number }> = {
    pci_dss: { name: 'PCI-DSS', count: 0 },
    hipaa:   { name: 'HIPAA',   count: 0 },
    gdpr:    { name: 'GDPR',    count: 0 },
    nist_800_53: { name: 'NIST 800-53', count: 0 },
    tsc:     { name: 'TSC',     count: 0 },
  };

  for (const alert of items) {
    const groups: string[] = alert.rule?.groups ?? [];
    for (const fw of Object.keys(frameworks)) {
      if (groups.some((g: string) => g.toLowerCase().includes(fw))) {
        frameworks[fw].count++;
      }
    }
  }

  return Object.entries(frameworks)
    .map(([id, d]) => ({ id, ...d }))
    .filter(f => f.count > 0);
}

// ── Groups (for tenant sync) ──────────────────────────────────
export async function getGroups() {
  const r = await wazuh<any>('/groups?limit=100');
  return r.data?.affected_items ?? [];
}

// ── Create group (for tenant onboarding) ─────────────────────
export async function createGroup(groupName: string) {
  return wazuh<any>('/groups', { method: 'POST', body: { group_id: groupName } });
}

// ── Create Wazuh user ─────────────────────────────────────────
export async function createWazuhUser(username: string, password: string) {
  return wazuh<any>('/security/users', { method: 'POST', body: { username, password, allow_run_as: false } });
}

// ── Get security roles ────────────────────────────────────────
export async function getSecurityRoles() {
  const r = await wazuh<any>('/security/roles?limit=100');
  return r.data?.affected_items ?? [];
}

// ── Assign role to user ───────────────────────────────────────
export async function assignRoleToUser(userId: number, roleId: number) {
  return wazuh<any>(`/security/users/${userId}/roles?role_ids=${roleId}`, { method: 'POST' });
}

// ── Stats for dashboard aggregation ──────────────────────────
export async function getDashboardData(wazuhGroup?: string) {
  const [agentSummary, critAlerts, allAlerts] = await Promise.allSettled([
    getAgentSummary(wazuhGroup),
    getCriticalAlerts(wazuhGroup),
    getAlerts(wazuhGroup, 20, 0),
  ]);

  return {
    agents:       agentSummary.status === 'fulfilled' ? agentSummary.value : null,
    critAlerts:   critAlerts.status === 'fulfilled' ? critAlerts.value : { items: [], total: 0 },
    recentAlerts: allAlerts.status === 'fulfilled' ? allAlerts.value.items : [],
  };
}
