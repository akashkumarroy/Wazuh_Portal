# Prime SOC Portal v3
## Prime Infoserv MSSP — Unified Security Operations Portal

---

## Quick Deploy (Docker Compose)

### 1. Copy & configure environment
```bash
cp .env.example .env
nano .env
```

**Minimum required changes:**
```
JWT_SECRET=<generate: echo $(openssl rand -hex 32)$(openssl rand -hex 32)>
POSTGRES_PASSWORD=<strong password>
```

All other values are pre-filled from the tested configuration.

### 2. Build and start
```bash
docker compose up -d --build
```

### 3. Access
```
http://<server-ip>:8181
```

Login with any Wazuh Indexer user (e.g., `admin`, `Ploutos`, `Vedika`, etc.)

---

## Architecture

```
Browser → Nginx (:8181) → Next.js Portal (:3000)
                                  ↓
          ┌───────────────────────┼───────────────────────┐
          │                       │                       │
   Wazuh Indexer          OpenCTI + MISP            IRIS + Shuffle
  (74.225.232.83)        (10.0.7.93 via WG)        (10.0.7.93 via WG)
```

### WireGuard tunnels
Internal tools (OpenCTI, MISP, IRIS) are accessed via WireGuard tunnels already set up on the server. The portal connects to them using the private IPs in `.env`.

---

## Authentication Flow

1. User enters username + password
2. Portal calls `POST https://74.225.232.83:8888/_plugins/_security/api/account` with those credentials
3. If `200` → valid, check `backend_roles`
   - Non-empty `backend_roles` → **admin** role (sees all tenants)
   - Empty `backend_roles` → **client** role (sees only their tenant group via DLS)
4. Portal issues JWT session cookie (8 hours)
5. All data queries use admin credentials + DLS filter based on user's group

**No separate user database needed.** All authentication is delegated to Wazuh Indexer.

---

## Tenant Isolation

- Client tenant = username (e.g., user `Ploutos` → group `Ploutos`)
- All Wazuh alerts tagged with `agent.labels.group`
- Admin queries: no DLS filter → all data
- Client queries: `{"match": {"agent.labels.group": "<username>"}}`

**New tenant onboarding:**
1. Create Wazuh Indexer user with tenant name as username
2. Assign the tenant role with DLS filter in OpenSearch Security
3. Portal auto-detects the new tenant — no code changes needed

---

## Page Reference

| URL | Description |
|-----|-------------|
| `/` | Login page |
| `/dashboard` | Main SOC overview — alerts, MITRE, geo, agent health |
| `/siem` | SIEM: Events, FIM, SCA, Vuln, Compliance, MITRE, Hunting, Malware |
| `/threat-intel` | Threat Intel: OpenCTI + MISP live feed, IOCs, threat actors |
| `/soar` | SOAR: Shuffle workflows + IRIS DFIR section |
| `/assets` | Agent inventory with full details |
| `/reports` | CSV/JSON export of alerts, agents, CTI |
| `/settings` | Portal config info |
| `/admin/tenants` | Admin: all tenants with real-time alert counts |
| `/admin/tenant/:group` | Admin: per-tenant full dashboard |
| `/admin/users` | Admin: Wazuh Indexer users list |

---

## Environment Variables

| Variable | Description |
|----------|-------------|
| `JWT_SECRET` | Session signing key (64+ chars) |
| `WAZUH_INDEXER_URL` | OpenSearch endpoint |
| `WAZUH_INDEXER_USER` | Admin username |
| `WAZUH_INDEXER_PASS` | Admin password |
| `OPENCTI_URL` | OpenCTI API URL |
| `OPENCTI_API_KEY` | OpenCTI API key |
| `MISP_URL` | MISP base URL |
| `MISP_API_KEY` | MISP auth key |
| `IRIS_URL` | IRIS case management URL |
| `IRIS_API_KEY` | IRIS bearer token |
| `SHUFFLE_URL` | Shuffle SOAR URL |
| `SHUFFLE_API_KEY` | Shuffle API key |
| `DATABASE_URL` | PostgreSQL connection string |

**To update any connection:** change `.env` → `docker compose restart portal`

---

## Updating

```bash
# Pull latest code
git pull

# Rebuild portal only (no data loss)
docker compose up -d --build portal

# Full restart
docker compose down && docker compose up -d --build
```

---

## Troubleshooting

**Portal not loading:**
```bash
docker compose logs portal --tail=50
```

**Wazuh connection errors:**
```bash
# Test from Docker host
curl -sk -u "admin:password" https://74.225.232.83:8888/_cluster/health
```

**Internal tools (IRIS/MISP/OpenCTI) unreachable:**
```bash
# Verify WireGuard is up
wg show
# Test from portal container
docker compose exec portal wget -qO- http://10.0.7.93:8080/graphql
```

---

*Prime Infoserv MSSP · Our Expertise, Your Shield*
