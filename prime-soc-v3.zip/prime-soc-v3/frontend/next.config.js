/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',
  experimental: { serverComponentsExternalPackages: ['pg'] },
  // Accept self-signed TLS (Wazuh Indexer / IRIS use self-signed certs)
  env: { NODE_TLS_REJECT_UNAUTHORIZED: '0' },
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'X-Frame-Options',        value: 'DENY' },
          { key: 'X-Content-Type-Options',  value: 'nosniff' },
          { key: 'Referrer-Policy',         value: 'strict-origin-when-cross-origin' },
        ],
      },
    ];
  },
};

process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

module.exports = nextConfig;
