'use client';
import { useState, useEffect } from 'react';

interface Alert { id:string; timestamp:string; agent:any; rule:any; data?:any; full_log?:string; GeoLocation?:any; manager?:any; severity:string; location?:string; }

interface Props { alertId: string | null; onClose: () => void; }

const SEV_COLOR: Record<string,string> = { CRITICAL:'#ef4444', HIGH:'#f59e0b', MEDIUM:'#eab308', LOW:'#3b82f6', INFO:'#64748b' };

export default function AlertDetailPanel({ alertId, onClose }: Props) {
  const [alert, setAlert] = useState<Alert | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!alertId) { setAlert(null); return; }
    setLoading(true);
    fetch(`/api/wazuh/alert/${encodeURIComponent(alertId)}`)
      .then(r => r.json()).then(d => setAlert(d.alert)).catch(() => setAlert(null))
      .finally(() => setLoading(false));
  }, [alertId]);

  if (!alertId) return null;

  const sev = alert?.severity ?? 'INFO';
  const sevColor = SEV_COLOR[sev] ?? '#64748b';

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 z-[190]" style={{ background:'rgba(0,0,0,0.5)' }} onClick={onClose} />

      {/* Panel */}
      <div className="alert-detail-panel">
        {/* Header */}
        <div className="sticky top-0 px-5 py-4 border-b flex items-center justify-between"
          style={{ borderColor:'var(--border)', background:'var(--bg-secondary)', zIndex:1 }}>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className={`badge badge-${sev.toLowerCase()}`}>{sev}</span>
              <span className="mono text-dim" style={{ fontSize:10 }}>Level {alert?.rule?.level ?? '—'}</span>
            </div>
            <p className="font-semibold text-white" style={{ fontSize:14, maxWidth:360 }}>
              {loading ? 'Loading…' : alert?.rule?.description ?? 'Alert Detail'}
            </p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-white/5 text-dim hover:text-white transition-colors">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/>
            </svg>
          </button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-6 h-6 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : alert ? (
          <div className="p-5 space-y-4">
            {/* Timestamp */}
            <div className="card p-3 flex items-center gap-3">
              <svg className="w-4 h-4 text-dim shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
              </svg>
              <span className="mono text-secondary" style={{ fontSize:12 }}>
                {alert.timestamp ? new Date(alert.timestamp).toLocaleString() : '—'}
              </span>
            </div>

            {/* Agent Info */}
            <Section title="Agent" icon="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2">
              <Row label="Name"   value={alert.agent?.name ?? '—'} />
              <Row label="ID"     value={alert.agent?.id ?? '—'} />
              <Row label="IP"     value={alert.agent?.ip ?? '—'} />
              <Row label="Group"  value={alert.agent?.labels?.group ?? '—'} accent />
              <Row label="Manager" value={alert.manager?.name ?? '—'} />
            </Section>

            {/* Rule Info */}
            <Section title="Rule" icon="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z">
              <Row label="ID"          value={alert.rule?.id ?? '—'} />
              <Row label="Description" value={alert.rule?.description ?? '—'} />
              <Row label="Level"       value={String(alert.rule?.level ?? '—')} accent />
              <Row label="Groups"      value={(alert.rule?.groups ?? []).join(', ') || '—'} />
            </Section>

            {/* MITRE ATT&CK */}
            {alert.rule?.mitre?.id?.length > 0 && (
              <Section title="MITRE ATT&CK" icon="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2z">
                <div className="flex flex-wrap gap-1.5">
                  {(alert.rule.mitre.id ?? []).map((id: string, i: number) => (
                    <div key={i} className="px-2 py-1 rounded" style={{ background:'rgba(0,216,232,0.1)', border:'1px solid rgba(0,216,232,0.2)' }}>
                      <p className="mono font-bold" style={{ fontSize:11, color:'var(--cyan)' }}>{id}</p>
                      <p className="mono text-dim" style={{ fontSize:9 }}>{alert.rule.mitre.technique?.[i] ?? ''}</p>
                    </div>
                  ))}
                </div>
                {alert.rule?.mitre?.tactic?.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {alert.rule.mitre.tactic.map((t: string, i: number) => (
                      <span key={i} className="badge badge-info" style={{ fontSize:8 }}>{t}</span>
                    ))}
                  </div>
                )}
              </Section>
            )}

            {/* Compliance */}
            {(alert.rule?.pci_dss || alert.rule?.gdpr || alert.rule?.hipaa || alert.rule?.nist_800_53 || alert.rule?.tsc) && (
              <Section title="Compliance Mapping" icon="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2">
                {alert.rule?.pci_dss?.length > 0 && <Row label="PCI-DSS" value={alert.rule.pci_dss.join(', ')} />}
                {alert.rule?.gdpr?.length > 0 && <Row label="GDPR" value={alert.rule.gdpr.join(', ')} />}
                {alert.rule?.hipaa?.length > 0 && <Row label="HIPAA" value={alert.rule.hipaa.join(', ')} />}
                {alert.rule?.nist_800_53?.length > 0 && <Row label="NIST 800-53" value={alert.rule.nist_800_53.join(', ')} />}
                {alert.rule?.tsc?.length > 0 && <Row label="TSC" value={alert.rule.tsc.join(', ')} />}
              </Section>
            )}

            {/* GeoLocation */}
            {alert.GeoLocation && (
              <Section title="Geolocation" icon="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945">
                <Row label="Country" value={alert.GeoLocation.country_name ?? '—'} accent />
                <Row label="City"    value={alert.GeoLocation.city_name ?? '—'} />
                <Row label="Region"  value={alert.GeoLocation.region_name ?? '—'} />
                <Row label="Coords"  value={`${alert.GeoLocation.location?.lat ?? '—'}, ${alert.GeoLocation.location?.lon ?? '—'}`} />
              </Section>
            )}

            {/* Data fields */}
            {alert.data && Object.keys(alert.data).length > 0 && (
              <Section title="Event Data" icon="M4 6h16M4 10h16M4 14h16M4 18h16">
                {Object.entries(alert.data).slice(0,10).map(([k,v]) => (
                  <Row key={k} label={k} value={typeof v === 'object' ? JSON.stringify(v) : String(v ?? '—')} />
                ))}
              </Section>
            )}

            {/* Full log */}
            {alert.full_log && (
              <div>
                <p className="label-caps text-dim mb-2" style={{ fontSize:8 }}>Full Log</p>
                <div className="card p-3 mono overflow-x-auto" style={{ background:'rgba(0,0,0,0.3)', fontSize:10, color:'var(--text-secondary)', whiteSpace:'pre-wrap', wordBreak:'break-all' }}>
                  {alert.full_log}
                </div>
              </div>
            )}

            {/* Location */}
            {alert.location && (
              <div>
                <p className="label-caps text-dim mb-1" style={{ fontSize:8 }}>Log Location</p>
                <p className="mono text-secondary" style={{ fontSize:11 }}>{alert.location}</p>
              </div>
            )}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20">
            <p className="mono text-dim" style={{ fontSize:12 }}>Alert not found</p>
          </div>
        )}
      </div>
    </>
  );
}

function Section({ title, icon, children }: { title:string; icon:string; children:React.ReactNode }) {
  return (
    <div>
      <div className="flex items-center gap-2 mb-2">
        <svg className="w-3.5 h-3.5 text-dim" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={icon}/>
        </svg>
        <p className="label-caps text-dim" style={{ fontSize:8 }}>{title}</p>
      </div>
      <div className="card p-3 space-y-2">{children}</div>
    </div>
  );
}

function Row({ label, value, accent=false }: { label:string; value:string; accent?:boolean }) {
  return (
    <div className="flex justify-between gap-2 items-start">
      <span className="mono text-dim shrink-0" style={{ fontSize:10, minWidth:80 }}>{label}</span>
      <span className="mono text-right" style={{ fontSize:11, color: accent ? 'var(--cyan)' : 'var(--text-secondary)', wordBreak:'break-all' }}>{value}</span>
    </div>
  );
}
