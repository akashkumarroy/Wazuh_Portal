'use client';
import { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';

interface User { username:string; role:string; is_admin:boolean; group:string|null; }

export default function TopBar({ user, className='' }: { user:User; className?:string }) {
  const router = useRouter();
  const [profileOpen, setProfileOpen] = useState(false);
  const [time, setTime] = useState('');
  const pRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const t = () => setTime(new Date().toLocaleTimeString('en-GB',{hour12:false})+' UTC');
    t(); const id = setInterval(t,1000); return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const h = (e:MouseEvent) => { if (pRef.current&&!pRef.current.contains(e.target as Node)) setProfileOpen(false); };
    document.addEventListener('mousedown',h); return ()=>document.removeEventListener('mousedown',h);
  }, []);

  const logout = async () => { await fetch('/api/auth/logout',{method:'POST'}); router.push('/'); router.refresh(); };
  const initials = user.username.slice(0,2).toUpperCase();

  return (
    <header className={`${className} flex items-center justify-between px-4`}
      style={{ background:'rgba(8,12,20,0.98)', borderBottom:'1px solid var(--border)', backdropFilter:'blur(12px)', zIndex:100 }}>

      {/* Brand */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          {/* Mini shield */}
          <svg viewBox="0 0 100 120" style={{ width:22, height:26 }}>
            <path d="M50 5 L95 25 L95 65 C95 90 75 108 50 115 C25 108 5 90 5 65 L5 25 Z" fill="rgba(26,79,163,0.2)" stroke="#1a4fa3" strokeWidth="5"/>
            <path d="M30 50 L50 80 L70 50" fill="none" stroke="#00d8e8" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <div>
            <span className="font-black text-white" style={{ fontSize:14, letterSpacing:'-0.01em' }}>
              <span style={{ color:'#3b82f6' }}>Prime</span> SOC
            </span>
          </div>
        </div>
        <div className="h-4 w-px" style={{ background:'var(--border)' }} />
        <span className="mono text-dim" style={{ fontSize:9 }}>PRIME INFOSERV MSSP</span>
      </div>

      {/* Search */}
      <div className="flex-1 max-w-xs mx-6">
        <div className="relative">
          <svg className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-dim" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
          </svg>
          <input className="field py-1.5 pl-8 text-xs" placeholder="Search alerts, agents, rules…" style={{ fontSize:11 }}/>
        </div>
      </div>

      {/* Right actions */}
      <div className="flex items-center gap-2">
        <span className="mono text-dim" style={{ fontSize:10 }}>{time}</span>
        <div className="h-4 w-px mx-1" style={{ background:'var(--border)' }} />

        {/* Role badge */}
        <span className={`badge ${user.is_admin ? 'badge-active' : 'badge-info'}`} style={{ fontSize:8 }}>
          {user.is_admin ? '⬡ ADMIN' : '◈ ' + (user.group ?? 'CLIENT')}
        </span>

        {/* Profile */}
        <div ref={pRef} className="relative">
          <button onClick={()=>setProfileOpen(!profileOpen)}
            className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-white/5 transition-colors">
            <div className="w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs"
              style={{ background: user.is_admin ? 'rgba(26,79,163,0.3)' : 'rgba(124,58,237,0.25)', color: user.is_admin ? '#60a5fa' : '#a78bfa', fontSize:9 }}>
              {initials}
            </div>
            <span className="text-secondary" style={{ fontSize:12 }}>{user.username}</span>
            <svg className="w-3 h-3 text-dim" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7"/>
            </svg>
          </button>

          {profileOpen && (
            <div className="absolute right-0 top-9 w-48 rounded-xl z-50 overflow-hidden animate-up"
              style={{ background:'var(--bg-secondary)', border:'1px solid var(--border)', boxShadow:'0 20px 60px rgba(0,0,0,.7)' }}>
              <div className="px-3 py-2.5 border-b" style={{ borderColor:'var(--border)' }}>
                <p className="font-semibold text-white" style={{ fontSize:12 }}>{user.username}</p>
                <p className="mono text-dim" style={{ fontSize:9 }}>{user.is_admin?'SUPER ADMIN':user.group??'CLIENT'}</p>
              </div>
              <div className="p-1">
                {user.is_admin && (
                  <>
                    <button onClick={()=>{setProfileOpen(false);router.push('/admin/tenants');}}
                      className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg hover:bg-white/5 transition-colors text-left">
                      <svg className="w-3.5 h-3.5 text-dim" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5"/></svg>
                      <span className="text-secondary" style={{ fontSize:12 }}>Tenants</span>
                    </button>
                    <button onClick={()=>{setProfileOpen(false);router.push('/admin/users');}}
                      className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg hover:bg-white/5 transition-colors text-left">
                      <svg className="w-3.5 h-3.5 text-dim" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
                      <span className="text-secondary" style={{ fontSize:12 }}>Users</span>
                    </button>
                    <div className="border-t my-1" style={{ borderColor:'var(--border)' }} />
                  </>
                )}
                <button onClick={()=>{setProfileOpen(false);router.push('/settings');}}
                  className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg hover:bg-white/5 transition-colors text-left">
                  <svg className="w-3.5 h-3.5 text-dim" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/></svg>
                  <span className="text-secondary" style={{ fontSize:12 }}>Settings</span>
                </button>
                <div className="border-t my-1" style={{ borderColor:'var(--border)' }} />
                <button onClick={logout}
                  className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg hover:bg-red-500/10 transition-colors text-left">
                  <svg className="w-3.5 h-3.5 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
                  <span className="text-red-400" style={{ fontSize:12 }}>Logout</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
