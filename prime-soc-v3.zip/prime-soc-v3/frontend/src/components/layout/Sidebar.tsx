'use client';
import { usePathname, useRouter } from 'next/navigation';

interface User { username:string; role:string; is_admin:boolean; group:string|null; }

const NAV = [
  { label:'Dashboard',     href:'/dashboard',     icon:'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
  { label:'SIEM',          href:'/siem',          icon:'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z' },
  { label:'Threat Intel',  href:'/threat-intel',  icon:'M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064' },
  { label:'SOAR',          href:'/soar',          icon:'M13 10V3L4 14h7v7l9-11h-7z' },
  { label:'Assets',        href:'/assets',        icon:'M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01' },
  { label:'Reports',       href:'/reports',       icon:'M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
];

const ADMIN_NAV = [
  { label:'Tenants', href:'/admin/tenants', icon:'M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5' },
  { label:'Users',   href:'/admin/users',   icon:'M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z' },
];

export default function Sidebar({ user, className='' }: { user:User; className?:string }) {
  const pathname = usePathname();
  const router   = useRouter();

  const isActive = (href: string) =>
    pathname === href || (href !== '/dashboard' && pathname.startsWith(href));

  return (
    <aside className={`${className} flex flex-col`}
      style={{ background:'rgba(8,12,20,0.95)', borderRight:'1px solid var(--border)' }}>

      {/* User badge */}
      <div className="px-3 py-3 border-b" style={{ borderColor:'var(--border)' }}>
        <div className="flex items-center gap-2.5 px-1.5 py-1.5 rounded-lg"
          style={{ background: 'rgba(255,255,255,0.03)' }}>
          <div className="w-7 h-7 rounded-lg flex items-center justify-center font-bold shrink-0"
            style={{ fontSize:9, background: user.is_admin?'rgba(26,79,163,0.25)':'rgba(124,58,237,0.2)', color: user.is_admin?'#60a5fa':'#a78bfa' }}>
            {user.username.slice(0,2).toUpperCase()}
          </div>
          <div className="min-w-0">
            <p className="font-semibold text-white truncate" style={{ fontSize:11 }}>{user.username}</p>
            <p className="mono text-dim truncate" style={{ fontSize:8 }}>
              {user.is_admin ? '◈ ADMIN' : user.group ?? 'CLIENT'}
            </p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-2 overflow-y-auto space-y-0.5">
        {NAV.map(item => {
          const active = isActive(item.href);
          return (
            <button key={item.href} onClick={()=>router.push(item.href)}
              className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg transition-all text-left"
              style={{
                background:  active ? 'rgba(0,216,232,0.08)' : 'transparent',
                borderLeft:  active ? '2px solid var(--cyan)' : '2px solid transparent',
              }}>
              <svg className="w-4 h-4 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={active?2:1.5}
                style={{ color: active ? 'var(--cyan)' : 'var(--text-dim)' }}>
                <path strokeLinecap="round" strokeLinejoin="round" d={item.icon}/>
              </svg>
              <span style={{ fontSize:12, fontWeight: active?600:400, color: active?'white':'var(--text-secondary)' }}>
                {item.label}
              </span>
            </button>
          );
        })}

        {user.is_admin && (
          <>
            <div className="pt-3 pb-1 px-3">
              <p className="label-caps text-dim" style={{ fontSize:8 }}>Administration</p>
            </div>
            {ADMIN_NAV.map(item => {
              const active = pathname.startsWith(item.href);
              return (
                <button key={item.href} onClick={()=>router.push(item.href)}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg transition-all text-left"
                  style={{
                    background:  active ? 'rgba(124,58,237,0.1)' : 'transparent',
                    borderLeft:  active ? '2px solid var(--purple)' : '2px solid transparent',
                  }}>
                  <svg className="w-4 h-4 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}
                    style={{ color: active ? '#a78bfa' : 'var(--text-dim)' }}>
                    <path strokeLinecap="round" strokeLinejoin="round" d={item.icon}/>
                  </svg>
                  <span style={{ fontSize:12, color: active?'white':'var(--text-secondary)' }}>{item.label}</span>
                </button>
              );
            })}
          </>
        )}
      </nav>

      {/* Status */}
      <div className="p-3 border-t" style={{ borderColor:'var(--border)' }}>
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 dot-live" />
            <span className="mono text-dim" style={{ fontSize:8 }}>SOC ACTIVE</span>
          </div>
          <span className="mono text-dim" style={{ fontSize:8 }}>LIVE</span>
        </div>
      </div>
    </aside>
  );
}
