'use client';
import { useEffect, useState } from 'react';
export default function FooterBar({ className='' }: { className?:string }) {
  const [t, setT] = useState('');
  useEffect(() => {
    const tick = () => setT(new Date().toUTCString());
    tick(); const id = setInterval(tick, 1000); return () => clearInterval(id);
  }, []);
  return (
    <footer className={`${className} flex items-center justify-between px-4`}
      style={{ background:'rgba(8,12,20,0.98)', borderTop:'1px solid var(--border)', backdropFilter:'blur(8px)', zIndex:10 }}>
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-green-400 dot-live" />
          <span className="mono text-green-400" style={{ fontSize:9 }}>SYSTEM NOMINAL</span>
        </div>
        <span className="mono text-dim" style={{ fontSize:9 }}>Wazuh Indexer · OpenCTI · MISP · Shuffle · IRIS</span>
      </div>
      <div className="flex items-center gap-4">
        <span className="mono text-dim" style={{ fontSize:9 }}>Prime Infoserv MSSP © 2026</span>
        <span className="mono text-dim" style={{ fontSize:9 }}>{t}</span>
      </div>
    </footer>
  );
}
