import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Prime SOC — Prime Infoserv | Advanced Cyber Defense',
  description: 'Unified MSSP Security Operations Portal — Our Expertise, Your Shield',
  icons: { icon: '/favicon.ico' },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
