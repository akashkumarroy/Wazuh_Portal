export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { authenticateViaIndexer, createToken, COOKIE_NAME, COOKIE_OPTIONS } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const { username, password } = await request.json();
    if (!username || !password)
      return NextResponse.json({ error: 'Username and password required' }, { status: 400 });

    const auth = await authenticateViaIndexer(username.trim().toLowerCase(), password);
    if (!auth.valid)
      return NextResponse.json({ error: 'Invalid credentials. Check your Wazuh username and password.' }, { status: 401 });

    const role = auth.is_admin ? 'admin' : 'client';

    const token = await createToken({
      sub:      username.trim().toLowerCase(),
      role,
      group:    auth.group ?? undefined,
      is_admin: auth.is_admin,
    });

    const res = NextResponse.json({
      ok: true,
      user: { username: username.trim().toLowerCase(), role, is_admin: auth.is_admin, group: auth.group },
    });

    res.cookies.set(COOKIE_NAME, token, COOKIE_OPTIONS);
    return res;
  } catch (err) {
    console.error('[AUTH LOGIN]', err);
    return NextResponse.json({ error: 'Authentication service unavailable' }, { status: 503 });
  }
}
