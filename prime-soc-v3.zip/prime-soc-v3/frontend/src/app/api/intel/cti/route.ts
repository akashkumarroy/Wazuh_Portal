export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getCTIThreatActors, getCTIIndicators, getCTIStats, getCTIReports } from '@/lib/intel';
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  const p = token ? await verifyToken(token) : null;
  if (!p) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const type = searchParams.get('type') ?? 'stats';
  try {
    if (type==='actors') return NextResponse.json({ actors: await getCTIThreatActors(20) });
    if (type==='indicators') return NextResponse.json({ indicators: await getCTIIndicators(50) });
    if (type==='reports') return NextResponse.json({ reports: await getCTIReports(15) });
    const [stats, actors, indicators] = await Promise.allSettled([getCTIStats(), getCTIThreatActors(10), getCTIIndicators(20)]);
    return NextResponse.json({
      stats: stats.status==='fulfilled'?stats.value:null,
      actors: actors.status==='fulfilled'?actors.value:[],
      indicators: indicators.status==='fulfilled'?indicators.value:[],
    });
  } catch (err) { return NextResponse.json({ error: String(err) }, { status: 502 }); }
}
