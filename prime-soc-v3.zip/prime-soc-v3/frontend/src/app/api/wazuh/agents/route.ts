export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getAgents } from '@/lib/wazuh';
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  const p = token ? await verifyToken(token) : null;
  if (!p) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const group = p.is_admin ? null : p.group;
  try {
    const { agents, total } = await getAgents(group, 2000);
    return NextResponse.json({ agents, total });
  } catch (err) { return NextResponse.json({ error: String(err) }, { status: 502 }); }
}
