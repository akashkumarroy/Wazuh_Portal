export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getComplianceSummary, getComplianceAlerts } from '@/lib/wazuh';
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  const p = token ? await verifyToken(token) : null;
  if (!p) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const framework = searchParams.get('framework') as any;
  const group = p.is_admin ? null : p.group;
  try {
    if (framework) {
      const alerts = await getComplianceAlerts(framework, group, 200);
      return NextResponse.json({ alerts });
    }
    return NextResponse.json(await getComplianceSummary(group));
  } catch (err) { return NextResponse.json({ error: String(err) }, { status: 502 }); }
}
