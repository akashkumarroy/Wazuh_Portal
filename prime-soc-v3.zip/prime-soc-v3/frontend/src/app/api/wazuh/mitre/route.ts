export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getMitreSummary } from '@/lib/wazuh';
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  const p = token ? await verifyToken(token) : null;
  if (!p) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const group = p.is_admin ? null : p.group;
  try { return NextResponse.json(await getMitreSummary(group)); }
  catch (err) { return NextResponse.json({ error: String(err) }, { status: 502 }); }
}
