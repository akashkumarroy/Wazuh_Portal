export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getAlertById } from '@/lib/wazuh';
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  const p = token ? await verifyToken(token) : null;
  if (!p) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const alert = await getAlertById(params.id);
    if (!alert) return NextResponse.json({ error: 'Not found' }, { status: 404 });
    return NextResponse.json({ alert });
  } catch (err) { return NextResponse.json({ error: String(err) }, { status: 502 }); }
}
