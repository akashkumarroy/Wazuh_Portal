export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getStatistics, getDashboardStats, getGeoData } from '@/lib/wazuh';
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  const p = token ? await verifyToken(token) : null;
  if (!p) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const group = p.is_admin ? null : p.group;
  try {
    const [stats, perf, geo] = await Promise.allSettled([getDashboardStats(group), getStatistics(), getGeoData(group)]);
    return NextResponse.json({
      stats: stats.status==='fulfilled'?stats.value:null,
      perf:  perf.status==='fulfilled'?perf.value:[],
      geo:   geo.status==='fulfilled'?geo.value:null,
    });
  } catch (err) { return NextResponse.json({ error: String(err) }, { status: 502 }); }
}
