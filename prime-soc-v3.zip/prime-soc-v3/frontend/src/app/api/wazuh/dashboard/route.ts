export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getDashboardStats, getAgentStatusSummary, getStatistics, getGeoData } from '@/lib/wazuh';

export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  const p = token ? await verifyToken(token) : null;
  if (!p) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const group = p.is_admin ? null : p.group;

  try {
    const [stats, agentData, statsData, geoData] = await Promise.allSettled([
      getDashboardStats(group),
      getAgentStatusSummary(group),
      getStatistics(),
      getGeoData(group),
    ]);

    return NextResponse.json({
      stats:   stats.status   === 'fulfilled' ? stats.value   : null,
      agents:  agentData.status === 'fulfilled' ? agentData.value : null,
      perf:    statsData.status === 'fulfilled' ? statsData.value : [],
      geo:     geoData.status   === 'fulfilled' ? geoData.value   : null,
      group,
      is_admin: p.is_admin,
    });
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 502 });
  }
}
