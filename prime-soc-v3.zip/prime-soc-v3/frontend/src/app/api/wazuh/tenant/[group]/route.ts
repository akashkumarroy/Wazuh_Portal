export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getTenantOverview, getAlerts, getAgents } from '@/lib/wazuh';
export async function GET(req: NextRequest, { params }: { params: { group: string } }) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  const p = token ? await verifyToken(token) : null;
  if (!p || !p.is_admin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  try {
    const [overview, recentAlerts, agentList] = await Promise.allSettled([
      getTenantOverview(params.group),
      getAlerts(params.group, 50),
      getAgents(params.group, 500),
    ]);
    return NextResponse.json({
      group: params.group,
      overview: overview.status==='fulfilled'?overview.value:null,
      recent_alerts: recentAlerts.status==='fulfilled'?recentAlerts.value:[],
      agents: agentList.status==='fulfilled'?agentList.value:{ agents:[], total:0 },
    });
  } catch (err) { return NextResponse.json({ error: String(err) }, { status: 502 }); }
}
