export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getAllTenantsSummary, getIndexerUsers, getIndexerRoles } from '@/lib/wazuh';
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  const p = token ? await verifyToken(token) : null;
  if (!p || !p.is_admin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  try {
    const [summary, users, roles] = await Promise.allSettled([
      getAllTenantsSummary(), getIndexerUsers(), getIndexerRoles(),
    ]);
    return NextResponse.json({
      tenants: summary.status==='fulfilled'?summary.value:[],
      users:   users.status==='fulfilled'?users.value:[],
      roles:   roles.status==='fulfilled'?roles.value:[],
    });
  } catch (err) { return NextResponse.json({ error: String(err) }, { status: 502 }); }
}
