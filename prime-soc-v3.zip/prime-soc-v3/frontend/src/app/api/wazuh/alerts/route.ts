export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getAlerts } from '@/lib/wazuh';
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  const p = token ? await verifyToken(token) : null;
  if (!p) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const size = parseInt(searchParams.get('size') ?? '100');
  const from = parseInt(searchParams.get('from') ?? '0');
  const group = p.is_admin ? null : p.group;
  try {
    const alerts = await getAlerts(group, size, from);
    return NextResponse.json({ alerts, total: alerts.length });
  } catch (err) { return NextResponse.json({ error: String(err) }, { status: 502 }); }
}
