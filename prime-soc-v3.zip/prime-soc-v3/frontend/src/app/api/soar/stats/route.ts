export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getShuffleStats, getShuffleWorkflows } from '@/lib/soar';
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  const p = token ? await verifyToken(token) : null;
  if (!p) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { searchParams } = new URL(req.url);
  if (searchParams.get('workflows') === 'true') {
    try { return NextResponse.json({ workflows: await getShuffleWorkflows() }); }
    catch (err) { return NextResponse.json({ workflows: [], error: String(err) }); }
  }
  try { return NextResponse.json(await getShuffleStats()); }
  catch (err) { return NextResponse.json({ total:0, active:0, success:0, failed:0, last_run:null, error: String(err) }); }
}
