export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getIRISStats, getIRISCases, getIRISAlerts, getIRISDashboard } from '@/lib/soar';
export async function GET(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  const p = token ? await verifyToken(token) : null;
  if (!p) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const type = searchParams.get('type') ?? 'stats';
  try {
    if (type==='cases') return NextResponse.json({ cases: await getIRISCases() });
    if (type==='alerts') return NextResponse.json({ alerts: await getIRISAlerts() });
    if (type==='dashboard') return NextResponse.json(await getIRISDashboard());
    const [stats, cases] = await Promise.allSettled([getIRISStats(), getIRISCases()]);
    return NextResponse.json({
      stats: stats.status==='fulfilled'?stats.value:null,
      cases: cases.status==='fulfilled'?(cases.value as any[]).slice(0,10):[],
    });
  } catch (err) { return NextResponse.json({ error: String(err) }, { status: 502 }); }
}
