'use client';
import { useState, useEffect, useCallback } from 'react';

export default function AdminUsersPage() {
  const [data, setData]     = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const fetch_ = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch('/api/wazuh/tenants').then(r=>r.json());
      setData(r);
    } finally { setLoading(false); }
  }, []);

  useEffect(()=>{ fetch_(); },[fetch_]);

  const users = (data?.users ?? []).filter((u:any) =>
    !search || u.username.toLowerCase().includes(search.toLowerCase())
  );

  const admins  = users.filter((u:any)=>u.backend_roles?.some((r:string)=>r&&r!==''));
  const clients = users.filter((u:any)=>!u.backend_roles?.some((r:string)=>r&&r!==''));

  return (
    <div className="flex flex-col h-full">
      <div className="px-5 pt-4 pb-4 shrink-0 border-b" style={{borderColor:'var(--border)'}}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <span className="badge badge-warning mb-2" style={{fontSize:8}}>ADMIN VIEW</span>
            <h1 className="font-black text-white" style={{fontSize:20,letterSpacing:'-0.02em'}}>User Management</h1>
            <p className="mono text-secondary mt-0.5" style={{fontSize:11}}>Wazuh Indexer users · Synced from OpenSearch Security</p>
          </div>
          <button onClick={fetch_} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-secondary hover:text-white transition-colors"
            style={{border:'1px solid var(--border)', fontSize:11}}>
            <svg className={`w-3.5 h-3.5 ${loading?'animate-spin':''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
            Sync
          </button>
        </div>
        <div className="grid grid-cols-3 gap-3 mb-4">
          {[
            {l:'Total Users',    v:users.length,   c:'var(--cyan)'},
            {l:'Admins',         v:admins.length,  c:'#a78bfa'},
            {l:'Client Users',   v:clients.length, c:'var(--green)'},
          ].map(s=>(
            <div key={s.l} className="card px-4 py-2.5">
              <p className="label-caps text-dim" style={{fontSize:8}}>{s.l}</p>
              <p className="stat-value mt-0.5" style={{fontSize:20,color:s.c}}>{loading?'…':s.v}</p>
            </div>
          ))}
        </div>
        <input value={search} onChange={e=>setSearch(e.target.value)} className="field py-1.5"
          style={{fontSize:11,width:240}} placeholder="Search users…"/>
      </div>

      <div className="flex-1 overflow-auto p-5">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin"/>
          </div>
        ) : (
          <div className="card" style={{overflow:'auto'}}>
            <table className="data-table">
              <thead><tr><th>Username</th><th>Type</th><th>Backend Roles</th><th>Roles</th></tr></thead>
              <tbody>
                {users.map((u:any,i:number)=>{
                  const isAdmin = u.backend_roles?.some((r:string)=>r&&r!=='');
                  return (
                    <tr key={i}>
                      <td>
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-lg flex items-center justify-center font-bold"
                            style={{fontSize:9, background:isAdmin?'rgba(124,58,237,0.2)':'rgba(16,185,129,0.1)', color:isAdmin?'#a78bfa':'var(--green)'}}>
                            {u.username[0]?.toUpperCase()}
                          </div>
                          <span className="font-semibold text-white" style={{fontSize:12}}>{u.username}</span>
                        </div>
                      </td>
                      <td>
                        <span className={`badge ${isAdmin?'badge-warning':'badge-active'}`} style={{fontSize:8}}>
                          {isAdmin?'ADMIN':'CLIENT'}
                        </span>
                      </td>
                      <td className="mono text-dim" style={{fontSize:10}}>{(u.backend_roles??[]).filter((r:string)=>r).join(', ')||'—'}</td>
                      <td className="mono text-dim" style={{fontSize:10}}>{(u.roles??[]).slice(0,4).join(', ')||'—'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {users.length===0&&<div className="py-12 text-center"><p className="mono text-dim" style={{fontSize:11}}>No users found</p></div>}
          </div>
        )}
        <div className="mt-4 card p-4">
          <p className="label-caps text-secondary mb-2" style={{fontSize:9}}>Managing Users</p>
          <p className="mono text-secondary" style={{fontSize:10,lineHeight:1.6}}>
            Users are managed in Wazuh's OpenSearch Security. To add a new tenant, create a user with the tenant name and assign the appropriate role with DLS filter. The portal will automatically detect the new tenant.
          </p>
        </div>
      </div>
    </div>
  );
}
