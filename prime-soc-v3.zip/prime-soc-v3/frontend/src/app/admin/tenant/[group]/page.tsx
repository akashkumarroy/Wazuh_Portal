'use client';
import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer,
} from 'recharts';
import AlertDetailPanel from '@/components/widgets/AlertDetailPanel';

const fmt = (n:number) => n>=1_000_000?`${(n/1_000_000).toFixed(1)}M`:n>=1_000?`${(n/1_000).toFixed(1)}K`:String(n);

export default function TenantDetailPage({ params }: { params: { group: string } }) {
  const router = useRouter();
  const group  = decodeURIComponent(params.group);
  const [data, setData]             = useState<any>(null);
  const [loading, setLoading]       = useState(true);
  const [selectedAlert, setSelectedAlert] = useState<string|null>(null);

  const fetch_ = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch(`/api/wazuh/tenant/${encodeURIComponent(group)}`).then(r=>r.json());
      setData(r);
    } finally { setLoading(false); }
  }, [group]);

  useEffect(()=>{ fetch_(); },[fetch_]);
  useEffect(()=>{ const id=setInterval(fetch_, 60_000); return ()=>clearInterval(id); },[fetch_]);

  const alertAggs  = data?.overview?.alerts?.aggregations;
  const agentAggs  = data?.overview?.agents?.aggregations;
  const total      = data?.overview?.alerts?.hits?.total?.value ?? 0;
  const critical   = alertAggs?.critical?.doc_count ?? 0;
  const high       = alertAggs?.high?.doc_count ?? 0;
  const medium     = alertAggs?.medium?.doc_count ?? 0;

  const agentByStatus = (agentAggs?.by_status?.buckets ?? []) as {key:string;doc_count:number}[];
  const active  = agentByStatus.find(b=>b.key==='active')?.doc_count ?? 0;
  const disconn = agentByStatus.find(b=>b.key==='disconnected')?.doc_count ?? 0;
  const agentCount = agentAggs?.agent_count?.value ?? (active+disconn);

  const alertsOT = (alertAggs?.alerts_over_time?.buckets ?? []).slice(-30).map((b:any)=>({
    t: new Date(b.key_as_string).toLocaleDateString('en-GB',{day:'numeric',month:'short'}),
    v: b.doc_count,
  }));

  const topAgents = (alertAggs?.top_agents?.buckets ?? []).slice(0,8).map((b:any)=>({name:b.key,count:b.doc_count}));
  const topRules  = (alertAggs?.top_rules?.buckets  ?? []).slice(0,6).map((b:any)=>({name:b.key,count:b.doc_count}));
  const byOS      = (agentAggs?.by_os?.buckets ?? []).map((b:any)=>({name:b.key,count:b.doc_count,color:b.key==='linux'?'var(--cyan)':b.key==='windows'?'#3b82f6':'#a78bfa'}));

  const recentAlerts = data?.recent_alerts ?? [];
  const agentList    = data?.agents?.agents ?? [];

  const sevData = [
    {name:'Critical',value:critical,color:'#ef4444'},
    {name:'High',    value:high,    color:'#f59e0b'},
    {name:'Medium',  value:medium,  color:'#eab308'},
  ].filter(d=>d.value>0);

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 pt-4 pb-4 shrink-0 border-b" style={{borderColor:'var(--border)'}}>
        <div className="flex items-center gap-3 mb-1">
          <button onClick={()=>router.push('/admin/tenants')} className="text-dim hover:text-white transition-colors p-1 -ml-1">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7"/></svg>
          </button>
          <span className="label-caps text-dim" style={{fontSize:8}}>TENANTS /</span>
          <span className="badge badge-active" style={{fontSize:8}}>ADMIN VIEW</span>
        </div>
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center font-black"
            style={{background:'rgba(0,216,232,0.12)',color:'var(--cyan)',fontSize:20}}>
            {group[0].toUpperCase()}
          </div>
          <div>
            <h1 className="font-black text-white" style={{fontSize:24,letterSpacing:'-0.02em'}}>{group}</h1>
            <p className="mono text-secondary" style={{fontSize:11}}>Tenant dashboard · Real-time · Last 30 days</p>
          </div>
          <button onClick={fetch_} className="ml-auto flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-secondary hover:text-white transition-colors"
            style={{border:'1px solid var(--border)', fontSize:11}}>
            <svg className={`w-3.5 h-3.5 ${loading?'animate-spin':''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
            Refresh
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-5 space-y-4">
        {loading && !data ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin"/>
          </div>
        ) : (
          <>
            {/* KPIs */}
            <div className="grid grid-cols-6 gap-3">
              {[
                {l:'Total Alerts',   v:fmt(total),      c:'var(--cyan)'},
                {l:'Critical',       v:fmt(critical),   c:'#ef4444'},
                {l:'High',           v:fmt(high),       c:'#f59e0b'},
                {l:'Medium',         v:fmt(medium),     c:'#eab308'},
                {l:'Total Agents',   v:String(agentCount), c:'var(--cyan)'},
                {l:'Active / Disc',  v:`${active} / ${disconn}`, c: active>0?'var(--green)':'#ef4444'},
              ].map(s=>(
                <div key={s.l} className="card p-3 text-center">
                  <p className="label-caps text-dim" style={{fontSize:7}}>{s.l}</p>
                  <p className="stat-value mt-0.5" style={{fontSize:18,color:s.c}}>{s.v}</p>
                </div>
              ))}
            </div>

            {/* Alert trend + Severity donut */}
            <div className="grid grid-cols-3 gap-4">
              <div className="col-span-2 card p-4">
                <p className="label-caps text-secondary mb-3" style={{fontSize:9}}>Alert Volume — Last 30 Days</p>
                <div style={{height:140}}>
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={alertsOT} margin={{top:0,right:0,bottom:0,left:0}}>
                      <defs>
                        <linearGradient id="tGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={critical>0?'#ef4444':'var(--cyan)'} stopOpacity={0.3}/>
                          <stop offset="95%" stopColor={critical>0?'#ef4444':'var(--cyan)'} stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <XAxis dataKey="t" tick={{fontSize:8,fill:'var(--text-dim)'}} tickLine={false} axisLine={false}/>
                      <YAxis hide/>
                      <Tooltip/>
                      <Area type="monotone" dataKey="v" name="Alerts" stroke={critical>0?'#ef4444':'var(--cyan)'} strokeWidth={1.5} fill="url(#tGrad)"/>
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
              <div className="card p-4">
                <p className="label-caps text-secondary mb-3" style={{fontSize:9}}>Severity Distribution</p>
                {sevData.length>0?(
                  <>
                    <div style={{height:100}}>
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie data={sevData} cx="50%" cy="50%" innerRadius={28} outerRadius={44} dataKey="value" stroke="none">
                            {sevData.map((d,i)=><Cell key={i} fill={d.color}/>)}
                          </Pie>
                          <Tooltip/>
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="space-y-1 mt-2">
                      {sevData.map(d=>(
                        <div key={d.name} className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <div className="w-1.5 h-1.5 rounded-sm" style={{background:d.color}}/>
                            <span className="mono text-secondary" style={{fontSize:9}}>{d.name}</span>
                          </div>
                          <span className="mono font-bold" style={{fontSize:10,color:d.color}}>{fmt(d.value)}</span>
                        </div>
                      ))}
                    </div>
                  </>
                ):<p className="mono text-dim text-center py-6" style={{fontSize:10}}>No data</p>}
              </div>
            </div>

            {/* Top agents + OS + Top rules */}
            <div className="grid grid-cols-3 gap-4">
              <div className="card p-4">
                <p className="label-caps text-secondary mb-3" style={{fontSize:9}}>Top Alert Sources</p>
                {topAgents.length>0?(
                  <div style={{height:160}}>
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={topAgents} layout="vertical" margin={{top:0,right:8,bottom:0,left:0}}>
                        <XAxis type="number" hide/>
                        <YAxis type="category" dataKey="name" tick={{fontSize:9,fill:'var(--text-secondary)'}} width={110} tickLine={false} axisLine={false}/>
                        <Tooltip/>
                        <Bar dataKey="count" name="Alerts" fill="var(--cyan)" radius={[0,3,3,0]} barSize={7} opacity={0.8}/>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                ):<p className="mono text-dim text-center py-8" style={{fontSize:10}}>No agent data</p>}
              </div>

              <div className="card p-4">
                <p className="label-caps text-secondary mb-3" style={{fontSize:9}}>OS Distribution</p>
                {byOS.length>0?(
                  <div className="space-y-2">
                    {byOS.map((o:any)=>{
                      const mx=byOS[0].count;
                      return (
                        <div key={o.name}>
                          <div className="flex justify-between mb-0.5">
                            <span className="text-secondary capitalize" style={{fontSize:10}}>{o.name}</span>
                            <span className="mono font-bold" style={{fontSize:10,color:o.color}}>{o.count}</span>
                          </div>
                          <div className="rounded-full overflow-hidden" style={{height:3,background:'rgba(255,255,255,0.05)'}}>
                            <div style={{width:`${(o.count/mx)*100}%`,height:'100%',background:o.color,borderRadius:3}}/>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ):<p className="mono text-dim text-center py-8" style={{fontSize:10}}>No OS data</p>}
              </div>

              <div className="card p-4">
                <p className="label-caps text-secondary mb-3" style={{fontSize:9}}>Top Alert Rules</p>
                {topRules.length>0?(
                  <div className="space-y-2">
                    {topRules.map((r:any,i:number)=>{
                      const mx=topRules[0].count;
                      return (
                        <div key={i}>
                          <div className="flex justify-between mb-0.5">
                            <span className="text-secondary truncate" style={{fontSize:9,maxWidth:140}} title={r.name}>{r.name}</span>
                            <span className="mono font-bold text-white" style={{fontSize:10}}>{fmt(r.count)}</span>
                          </div>
                          <div className="rounded-full overflow-hidden" style={{height:3,background:'rgba(255,255,255,0.05)'}}>
                            <div style={{width:`${(r.count/mx)*100}%`,height:'100%',background:'var(--amber)',borderRadius:3}}/>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ):<p className="mono text-dim text-center py-8" style={{fontSize:10}}>No rule data</p>}
              </div>
            </div>

            {/* Recent Alerts + Agent List */}
            <div className="grid grid-cols-2 gap-4">
              <div className="card flex flex-col" style={{maxHeight:300}}>
                <div className="px-4 py-3 border-b shrink-0 flex items-center justify-between" style={{borderColor:'var(--border)'}}>
                  <p className="label-caps text-secondary" style={{fontSize:9}}>Recent Alerts</p>
                  <span className="badge badge-info">{recentAlerts.length}</span>
                </div>
                <div className="overflow-auto flex-1">
                  <table className="data-table">
                    <thead><tr><th>Time</th><th>Severity</th><th>Agent</th><th>Rule</th></tr></thead>
                    <tbody>
                      {recentAlerts.slice(0,20).map((a:any,i:number)=>(
                        <tr key={i} onClick={()=>a.id&&setSelectedAlert(a.id)}>
                          <td className="mono text-dim" style={{fontSize:9}}>{a.timestamp?new Date(a.timestamp).toLocaleTimeString():''}</td>
                          <td><span className={`badge badge-${(a.severity??'info').toLowerCase()}`} style={{fontSize:7}}>{a.severity}</span></td>
                          <td className="text-white" style={{fontSize:10}}>{a.agent?.name??'—'}</td>
                          <td className="text-secondary truncate" style={{fontSize:10,maxWidth:150}}>{a.rule?.description??'—'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {recentAlerts.length===0&&<div className="py-8 text-center"><p className="mono text-dim" style={{fontSize:11}}>No recent alerts</p></div>}
                </div>
              </div>

              <div className="card flex flex-col" style={{maxHeight:300}}>
                <div className="px-4 py-3 border-b shrink-0 flex items-center justify-between" style={{borderColor:'var(--border)'}}>
                  <p className="label-caps text-secondary" style={{fontSize:9}}>Agents</p>
                  <span className="badge badge-info">{agentList.length}</span>
                </div>
                <div className="overflow-auto flex-1">
                  <table className="data-table">
                    <thead><tr><th>Name</th><th>IP</th><th>Status</th><th>OS</th><th>Last Seen</th></tr></thead>
                    <tbody>
                      {agentList.slice(0,20).map((a:any,i:number)=>(
                        <tr key={i}>
                          <td className="text-white font-medium" style={{fontSize:10}}>{a.name??'—'}</td>
                          <td className="mono text-dim" style={{fontSize:9}}>{a.ip??'—'}</td>
                          <td><span className={`badge ${a.status==='active'?'badge-active':a.status==='disconnected'?'badge-critical':'badge-warning'}`} style={{fontSize:7}}>{a.status}</span></td>
                          <td className="mono text-dim" style={{fontSize:9}}>{a.os?.platform??'—'}</td>
                          <td className="mono text-dim" style={{fontSize:9}}>{a.lastKeepAlive?new Date(a.lastKeepAlive).toLocaleDateString():''}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {agentList.length===0&&<div className="py-8 text-center"><p className="mono text-dim" style={{fontSize:11}}>No agents found for this tenant</p></div>}
                </div>
              </div>
            </div>
          </>
        )}
      </div>

      <AlertDetailPanel alertId={selectedAlert} onClose={()=>setSelectedAlert(null)}/>
    </div>
  );
}
