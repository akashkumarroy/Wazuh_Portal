'use client';
import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { AreaChart, Area, ResponsiveContainer } from 'recharts';

const formatNum = (n: number) => n >= 1_000_000 ? `${(n/1_000_000).toFixed(1)}M` : n >= 1_000 ? `${(n/1_000).toFixed(1)}K` : String(n);

export default function AdminTenantsPage() {
  const router = useRouter();
  const [data, setData]       = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch]   = useState('');

  const fetch_ = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch('/api/wazuh/tenants').then(r=>r.json());
      setData(r);
    } finally { setLoading(false); }
  }, []);

  useEffect(()=>{ fetch_(); },[fetch_]);
  useEffect(()=>{ const id=setInterval(fetch_, 60_000); return ()=>clearInterval(id); },[fetch_]);

  const tenants = (data?.tenants ?? []).filter((t:any) =>
    !search || t.key.toLowerCase().includes(search.toLowerCase())
  );

  const totalAlerts  = tenants.reduce((s:number,t:any)=>s+t.doc_count,0);
  const totalTenants = tenants.length;
  const criticalTenants = tenants.filter((t:any)=>t.critical?.doc_count>0).length;

  return (
    <div className="flex flex-col h-full">
      <div className="px-5 pt-4 pb-4 shrink-0 border-b" style={{borderColor:'var(--border)'}}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="badge badge-warning" style={{fontSize:8}}>ADMIN VIEW</span>
            </div>
            <h1 className="font-black text-white" style={{fontSize:20,letterSpacing:'-0.02em'}}>Tenant Management</h1>
            <p className="mono text-secondary mt-0.5" style={{fontSize:11}}>
              Auto-synced from Wazuh Indexer · {totalTenants} tenants · Click any tenant for full dashboard
            </p>
          </div>
          <button onClick={fetch_} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-secondary hover:text-white transition-colors"
            style={{border:'1px solid var(--border)', fontSize:11}}>
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
            Sync
          </button>
        </div>

        {/* Summary */}
        <div className="grid grid-cols-3 gap-3 mb-4">
          {[
            { l:'Active Tenants',    v:totalTenants,    c:'var(--cyan)' },
            { l:'Total Alerts',      v:formatNum(totalAlerts), c:'var(--amber)' },
            { l:'Tenants w/ Critical', v:criticalTenants, c:'#ef4444' },
          ].map(s=>(
            <div key={s.l} className="card px-4 py-2.5">
              <p className="label-caps text-dim" style={{fontSize:8}}>{s.l}</p>
              <p className="stat-value mt-0.5" style={{fontSize:20,color:s.c}}>{loading?'…':s.v}</p>
            </div>
          ))}
        </div>

        <div className="relative">
          <svg className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-dim" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
          <input value={search} onChange={e=>setSearch(e.target.value)} className="field pl-8 py-1.5"
            style={{fontSize:11,width:240}} placeholder="Search tenants…"/>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-5">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin"/>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-4">
            {tenants.map((t:any) => {
              const critical = t.critical?.doc_count ?? 0;
              const high     = t.high?.doc_count ?? 0;
              const medium   = t.medium?.doc_count ?? 0;
              const total    = t.doc_count ?? 0;
              const lastAlert = t.last_alert?.value_as_string ?? null;
              const sparkData = (t.alerts_over_time?.buckets ?? []).slice(-14).map((b:any)=>({v:b.doc_count}));

              return (
                <div key={t.key} className="card-hover p-5 rounded-2xl cursor-pointer"
                  onClick={()=>router.push(`/admin/tenant/${encodeURIComponent(t.key)}`)}>
                  {/* Tenant header */}
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <div className="w-8 h-8 rounded-xl flex items-center justify-center font-black"
                          style={{background:'rgba(0,216,232,0.1)',color:'var(--cyan)',fontSize:13}}>
                          {t.key[0].toUpperCase()}
                        </div>
                        <div>
                          <p className="font-bold text-white" style={{fontSize:14}}>{t.key}</p>
                          {lastAlert && <p className="mono text-dim" style={{fontSize:9}}>Last: {new Date(lastAlert).toLocaleDateString()}</p>}
                        </div>
                      </div>
                    </div>
                    <svg className="w-4 h-4 text-dim" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7"/></svg>
                  </div>

                  {/* Total alerts */}
                  <p className="stat-value text-white mb-2" style={{fontSize:22}}>{formatNum(total)}</p>
                  <p className="mono text-dim mb-3" style={{fontSize:9}}>Total Alerts</p>

                  {/* Severity breakdown */}
                  <div className="grid grid-cols-3 gap-2 mb-3">
                    {[
                      {l:'Critical',v:critical,c:'#ef4444'},
                      {l:'High',    v:high,    c:'#f59e0b'},
                      {l:'Medium',  v:medium,  c:'#eab308'},
                    ].map(s=>(
                      <div key={s.l} className="text-center rounded-lg py-1.5"
                        style={{background:`${s.c}10`,border:`1px solid ${s.c}20`}}>
                        <p className="mono font-bold" style={{fontSize:13,color:s.c}}>{formatNum(s.v)}</p>
                        <p className="label-caps text-dim" style={{fontSize:7}}>{s.l}</p>
                      </div>
                    ))}
                  </div>

                  {/* Mini sparkline */}
                  {sparkData.length > 2 && (
                    <div style={{height:36}}>
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={sparkData} margin={{top:0,right:0,bottom:0,left:0}}>
                          <defs>
                            <linearGradient id={`sg-${t.key}`} x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor={critical>0?'#ef4444':'var(--cyan)'} stopOpacity={0.3}/>
                              <stop offset="95%" stopColor={critical>0?'#ef4444':'var(--cyan)'} stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <Area type="monotone" dataKey="v" stroke={critical>0?'#ef4444':'var(--cyan)'} strokeWidth={1.5} fill={`url(#sg-${t.key})`}/>
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  )}

                  <div className="flex items-center justify-end mt-2">
                    <span className="mono text-dim" style={{fontSize:9}}>Click for full dashboard →</span>
                  </div>
                </div>
              );
            })}

            {tenants.length === 0 && (
              <div className="col-span-3 py-20 text-center">
                <p className="mono text-secondary" style={{fontSize:13}}>
                  {search ? 'No tenants match search' : 'No tenant data. Alerts with agent.labels.group will appear here automatically.'}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
