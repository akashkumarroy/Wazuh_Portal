import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import TopBar from '@/components/layout/TopBar';
import Sidebar from '@/components/layout/Sidebar';
import FooterBar from '@/components/layout/FooterBar';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const store = cookies();
  const token = store.get(COOKIE_NAME)?.value;
  if (!token) redirect('/');
  const payload = await verifyToken(token);
  if (!payload || !payload.is_admin) redirect('/dashboard');

  const user = { username: payload.sub, role: payload.role, is_admin: payload.is_admin, group: payload.group ?? null };

  return (
    <div className="portal-grid">
      <TopBar user={user} className="area-top" />
      <Sidebar user={user} className="area-side" />
      <main className="area-main">{children}</main>
      <FooterBar className="area-foot" />
    </div>
  );
}
