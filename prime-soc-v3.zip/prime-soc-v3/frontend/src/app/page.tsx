'use client';
import { Suspense, useState, useEffect, useRef } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState('');
  const [time, setTime]         = useState('');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const t = () => setTime(new Date().toUTCString());
    t(); const id = setInterval(t, 1000); return () => clearInterval(id);
  }, []);

  // Particle canvas
  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    let raf: number;
    const particles: {x:number;y:number;vx:number;vy:number;life:number;color:string}[] = [];
    let mouse = { x: canvas.width/2, y: canvas.height/2 };
    const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
    resize(); window.addEventListener('resize', resize);
    window.addEventListener('mousemove', e => { mouse.x = e.clientX; mouse.y = e.clientY; });
    const colors = ['rgba(0,216,232,', 'rgba(124,58,237,', 'rgba(16,185,129,'];
    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      // Glow at mouse
      const g = ctx.createRadialGradient(mouse.x, mouse.y, 0, mouse.x, mouse.y, 300);
      g.addColorStop(0, 'rgba(0,216,232,0.04)'); g.addColorStop(1, 'transparent');
      ctx.fillStyle = g; ctx.fillRect(0, 0, canvas.width, canvas.height);
      if (Math.random() < 0.15) {
        const c = colors[Math.floor(Math.random()*colors.length)];
        particles.push({ x: mouse.x+(Math.random()-.5)*150, y: mouse.y+(Math.random()-.5)*150, vx: (Math.random()-.5)*.5, vy: -Math.random()*.7-.1, life: 1, color: c });
      }
      for (let i = particles.length-1; i >= 0; i--) {
        const p = particles[i]; p.x+=p.vx; p.y+=p.vy; p.life-=.016;
        if (p.life<=0) { particles.splice(i,1); continue; }
        ctx.beginPath(); ctx.arc(p.x, p.y, 1.5, 0, Math.PI*2);
        ctx.fillStyle = `${p.color}${p.life*.4})`; ctx.fill();
      }
      raf = requestAnimationFrame(draw);
    };
    draw();
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', resize); };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setLoading(true); setError('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username.trim().toLowerCase(), password }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error ?? 'Authentication failed'); return; }
      router.push(searchParams.get('redirect') ?? '/dashboard');
      router.refresh();
    } catch { setError('Connection error. Wazuh Indexer may be unreachable.'); }
    finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen relative overflow-hidden flex flex-col items-center justify-center p-6 bg-grid"
      style={{ background: 'var(--bg-primary)' }}>
      <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-0" />
      {/* Ambient orbs */}
      <div className="fixed pointer-events-none" style={{ top:'-20%', left:'-15%', width:'60%', height:'60%', borderRadius:'50%', background:'radial-gradient(circle, rgba(0,216,232,0.05) 0%, transparent 70%)', filter:'blur(60px)' }} />
      <div className="fixed pointer-events-none" style={{ bottom:'-20%', right:'-15%', width:'60%', height:'60%', borderRadius:'50%', background:'radial-gradient(circle, rgba(124,58,237,0.05) 0%, transparent 70%)', filter:'blur(60px)' }} />

      <main className="relative z-10 w-full max-w-[420px] animate-up">
        {/* Prime Infoserv Branding */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-4 mb-3">
            {/* Shield logo */}
            <div className="relative" style={{ width: 48, height: 56 }}>
              <svg viewBox="0 0 100 120" className="w-full h-full">
                {/* Shield outline */}
                <path d="M50 5 L95 25 L95 65 C95 90 75 108 50 115 C25 108 5 90 5 65 L5 25 Z"
                  fill="none" stroke="#1a4fa3" strokeWidth="4"/>
                {/* Shield fill */}
                <path d="M50 5 L95 25 L95 65 C95 90 75 108 50 115 C25 108 5 90 5 65 L5 25 Z"
                  fill="rgba(26,79,163,0.15)"/>
                {/* Red accent */}
                <path d="M50 5 L95 25 L95 45 L5 45 L5 25 Z" fill="rgba(220,38,38,0.3)"/>
                {/* V mark */}
                <path d="M30 50 L50 80 L70 50" fill="none" stroke="#00d8e8" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M35 50 L50 70 L65 50" fill="none" stroke="rgba(0,216,232,0.4)" strokeWidth="2"/>
              </svg>
            </div>
            <div className="text-left">
              <div className="font-black text-white" style={{ fontSize: 24, letterSpacing: '-0.02em', lineHeight: 1.1 }}>
                <span style={{ color: '#1a4fa3' }}>Prime</span>
              </div>
              <div className="font-black" style={{ fontSize: 24, letterSpacing: '-0.02em', lineHeight: 1.1, color: '#dc2626' }}>
                Infoserv
              </div>
            </div>
          </div>
          <div className="label-caps text-dim" style={{ letterSpacing: '.15em' }}>Our Expertise, Your Shield</div>
          <div className="mono mt-2" style={{ color: 'var(--cyan)', fontSize: 11 }}>
            ◈ PRIME SOC — Unified Security Operations Portal
          </div>
        </div>

        {/* Login card */}
        <div className="card scan-line" style={{ padding: '28px 32px' }}>
          <div className="flex justify-between items-center mb-5">
            <div>
              <p className="font-semibold text-white" style={{ fontSize: 15 }}>Secure Login</p>
              <p className="mono text-dim mt-0.5" style={{ fontSize: 10 }}>Authentication via Wazuh Indexer IAM</p>
            </div>
            <div className="flex items-center gap-1.5 px-2 py-1 rounded" style={{ background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.2)' }}>
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 dot-live" />
              <span className="mono text-green-400" style={{ fontSize: 9 }}>SECURE</span>
            </div>
          </div>

          {error && (
            <div className="mb-4 px-3 py-2.5 rounded-lg flex items-start gap-2 animate-fade"
              style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)' }}>
              <svg className="w-3.5 h-3.5 text-red-400 shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
              </svg>
              <p className="mono text-red-300" style={{ fontSize: 11 }}>{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3.5">
            <div>
              <label className="label-caps text-dim block mb-1.5" style={{ fontSize: 8 }}>Wazuh Username</label>
              <input className="field" type="text" placeholder="Enter your Wazuh username"
                value={username} onChange={e => setUsername(e.target.value)} autoComplete="username" required />
            </div>
            <div>
              <label className="label-caps text-dim block mb-1.5" style={{ fontSize: 8 }}>Password</label>
              <input className="field" type="password" placeholder="••••••••••••"
                value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" required />
            </div>

            <button type="submit" disabled={loading || !username || !password}
              className="w-full py-3 rounded-xl font-bold tracking-wide flex items-center justify-center gap-2 transition-all disabled:opacity-40 mt-1"
              style={{ background: 'linear-gradient(135deg, var(--brand-blue), #2563eb)', color: '#fff', fontSize: 13 }}>
              {loading ? (
                <><svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg>Authenticating…</>
              ) : (
                <><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>ACCESS PORTAL</>
              )}
            </button>
          </form>

          <div className="flex justify-between items-center mt-4 pt-3 border-t" style={{ borderColor: 'var(--border)' }}>
            <p className="mono text-dim" style={{ fontSize: 9 }}>Restricted system · All access logged</p>
            <p className="mono text-dim" style={{ fontSize: 9 }}>v3.0</p>
          </div>
        </div>

        <p className="text-center mono text-dim mt-4" style={{ fontSize: 9 }}>{time}</p>
      </main>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center" style={{ background: 'var(--bg-primary)' }}>
        <div className="w-6 h-6 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
      </div>
    }>
      <LoginForm />
    </Suspense>
  );
}
