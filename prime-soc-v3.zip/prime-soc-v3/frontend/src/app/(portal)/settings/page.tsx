'use client';
import { useState, useEffect } from 'react';

export default function SettingsPage() {
  const [health, setHealth] = useState<any>(null);

  useEffect(()=>{
    fetch('/api/health').then(r=>r.json()).then(setHealth).catch(()=>{});
  },[]);

  const TOOLS = [
    { name:'Wazuh Indexer',  key:'WAZUH_INDEXER_URL',  icon:'M5 12h14', color:'var(--cyan)', url:process.env.NEXT_PUBLIC_PORTAL_NAME },
    { name:'OpenCTI',        key:'OPENCTI_URL',         icon:'M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2', color:'var(--amber)' },
    { name:'MISP',           key:'MISP_URL',            icon:'M9 12l2 2 4-4m5.618-4.016A11.955', color:'#ef4444' },
    { name:'IRIS',           key:'IRIS_URL',            icon:'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z', color:'var(--purple)' },
    { name:'Shuffle',        key:'SHUFFLE_URL',         icon:'M13 10V3L4 14h7v7l9-11h-7z', color:'var(--green)' },
  ];

  return (
    <div className="p-5 space-y-6">
      <div>
        <h1 className="font-black text-white" style={{fontSize:20,letterSpacing:'-0.02em'}}>Settings</h1>
        <p className="mono text-secondary mt-1" style={{fontSize:11}}>Portal configuration · All sensitive values are in .env file only</p>
      </div>

      {/* System health */}
      <div className="card p-4">
        <p className="label-caps text-secondary mb-3" style={{fontSize:9}}>System Status</p>
        <div className="flex items-center gap-3">
          <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg ${health?'':'animate-pulse'}`}
            style={{background:'rgba(16,185,129,0.1)',border:'1px solid rgba(16,185,129,0.2)'}}>
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 dot-live"/>
            <span className="mono text-green-400" style={{fontSize:10}}>Portal API: {health?'ONLINE':'Checking…'}</span>
          </div>
          {health && <span className="mono text-dim" style={{fontSize:9}}>Last checked: {health.ts}</span>}
        </div>
      </div>

      {/* Tool connections */}
      <div className="card p-4">
        <p className="label-caps text-secondary mb-3" style={{fontSize:9}}>Connected Tools</p>
        <p className="mono text-dim mb-3" style={{fontSize:10}}>
          All tool URLs and API keys are configured in the <span className="mono text-cyan-400">.env</span> file.
          To update a connection, change the corresponding variable and restart the portal.
        </p>
        <div className="grid grid-cols-2 gap-3">
          {TOOLS.map(t=>(
            <div key={t.name} className="card p-3 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{background:`${t.color}18`}}>
                <svg className="w-4 h-4" style={{color:t.color}} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d={t.icon}/>
                </svg>
              </div>
              <div>
                <p className="font-semibold text-white" style={{fontSize:12}}>{t.name}</p>
                <p className="mono text-dim" style={{fontSize:9}}>{t.key}</p>
              </div>
              <span className="ml-auto badge badge-active" style={{fontSize:7}}>CONFIGURED</span>
            </div>
          ))}
        </div>
      </div>

      {/* How to update */}
      <div className="card p-4">
        <p className="label-caps text-secondary mb-3" style={{fontSize:9}}>Updating Configuration</p>
        <div className="space-y-3 mono text-secondary" style={{fontSize:11,lineHeight:1.7}}>
          <p>1. Edit the <span className="text-cyan-400">.env</span> file at the root of the project</p>
          <p>2. Change the relevant variable (URL, API key, etc.)</p>
          <p>3. Restart the portal: <span className="text-cyan-400 px-2 py-0.5 rounded" style={{background:'rgba(0,216,232,0.1)'}}>docker compose restart portal</span></p>
          <p>4. No code changes required — all configuration is externalized</p>
        </div>
      </div>

      <div className="card p-4">
        <p className="label-caps text-secondary mb-2" style={{fontSize:9}}>Portal Information</p>
        <div className="grid grid-cols-3 gap-3">
          {[
            {l:'Version',   v:'3.0.0'},
            {l:'Stack',     v:'Next.js 14 + TypeScript'},
            {l:'Auth',      v:'Wazuh Indexer IAM (pass-through)'},
            {l:'Data',      v:'Wazuh Indexer (OpenSearch)'},
            {l:'Intel',     v:'OpenCTI + MISP'},
            {l:'SOAR/DFIR', v:'Shuffle + IRIS'},
          ].map(r=>(
            <div key={r.l}>
              <p className="mono text-dim" style={{fontSize:9}}>{r.l}</p>
              <p className="mono text-secondary font-medium" style={{fontSize:11}}>{r.v}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
