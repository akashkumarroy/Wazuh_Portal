'use client';
import { useState, useEffect, useCallback } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import AlertDetailPanel from '@/components/widgets/AlertDetailPanel';

type Tab = 'events'|'fim'|'sca'|'vulnerability'|'compliance'|'mitre'|'threat-hunting'|'malware';

const COMPLIANCE_TABS = [
  { id:'pci_dss', label:'PCI-DSS', color:'#3b82f6' },
  { id:'gdpr', label:'GDPR', color:'#a78bfa' },
  { id:'hipaa', label:'HIPAA', color:'#10b981' },
  { id:'nist_800_53', label:'NIST 800-53', color:'#f59e0b' },
  { id:'tsc', label:'TSC', color:'#ec4899' },
  { id:'gpg13', label:'GPG13', color:'#6366f1' },
];

const SEV_COLOR: Record<string,string> = { CRITICAL:'#ef4444', HIGH:'#f59e0b', MEDIUM:'#eab308', LOW:'#3b82f6', INFO:'#475569' };

function SevBadge({ s }: { s:string }) {
  return <span className={`badge badge-${s.toLowerCase()}`}>{s}</span>;
}

export default function SIEMPage() {
  const [tab, setTab] = useState<Tab>('events');
  const [complianceTab, setComplianceTab] = useState('pci_dss');
  const [alerts, setAlerts]       = useState<any[]>([]);
  const [fim, setFim]             = useState<any[]>([]);
  const [sca, setSca]             = useState<any>(null);
  const [compliance, setCompliance] = useState<any>(null);
  const [compAlerts, setCompAlerts] = useState<any[]>([]);
  const [mitre, setMitre]         = useState<any>(null);
  const [vuln, setVuln]           = useState<any>(null);
  const [sankeyData, setSankeyData] = useState<any>(null);
  const [loading, setLoading]     = useState<Record<string,boolean>>({});
  const [selectedAlert, setSelectedAlert] = useState<string|null>(null);
  const [alertFilter, setAlertFilter] = useState('');
  const [levelFilter, setLevelFilter] = useState('all');

  const load = useCallback(async (which: string) => {
    setLoading(p=>({...p,[which]:true}));
    try {
      switch(which) {
        case 'events': {
          const r = await fetch('/api/wazuh/alerts?size=200').then(r=>r.json());
          setAlerts(r.alerts??[]); break;
        }
        case 'fim': {
          const r = await fetch('/api/wazuh/fim').then(r=>r.json());
          setFim(r.events??[]); break;
        }
        case 'sca': {
          const r = await fetch('/api/wazuh/sca').then(r=>r.json());
          setSca(r); break;
        }
        case 'compliance': {
          const r = await fetch('/api/wazuh/compliance').then(r=>r.json());
          setCompliance(r); break;
        }
        case 'mitre': {
          const r = await fetch('/api/wazuh/mitre').then(r=>r.json());
          setMitre(r); break;
        }
        case 'vulnerability': {
          const r = await fetch('/api/wazuh/vulnerability').then(r=>r.json());
          setVuln(r); break;
        }
        case 'sankey': {
          const r = await fetch('/api/wazuh/sankey').then(r=>r.json());
          setSankeyData(r); break;
        }
      }
    } finally { setLoading(p=>({...p,[which]:false})); }
  }, []);

  useEffect(()=>{ load('events'); },[load]);
  useEffect(()=>{ if(tab!=='events') load(tab); },[tab,load]);

  const loadComplianceAlerts = useCallback(async (fw: string) => {
    setLoading(p=>({...p,compAlerts:true}));
    try {
      const r = await fetch(`/api/wazuh/compliance?framework=${fw}`).then(r=>r.json());
      setCompAlerts(r.alerts??[]);
    } finally { setLoading(p=>({...p,compAlerts:false})); }
  }, []);

  useEffect(()=>{ if(tab==='compliance'){ load('compliance'); loadComplianceAlerts(complianceTab); } },[tab,complianceTab,load,loadComplianceAlerts]);

  const isLoading = (t:string) => !!loading[t];

  const filteredAlerts = alerts.filter(a => {
    const text = !alertFilter || JSON.stringify(a).toLowerCase().includes(alertFilter.toLowerCase());
    const lvl  = levelFilter==='all' || a.severity===levelFilter;
    return text && lvl;
  });

  const MAIN_TABS: {id:Tab;label:string}[] = [
    {id:'events',label:'Security Events'},
    {id:'fim',label:'File Integrity'},
    {id:'sca',label:'CIS/SCA'},
    {id:'vulnerability',label:'Vulnerabilities'},
    {id:'compliance',label:'Compliance'},
    {id:'mitre',label:'MITRE ATT&CK'},
    {id:'threat-hunting',label:'Threat Hunting'},
    {id:'malware',label:'Malware Detection'},
  ];

  // SCA policy stats
  const scaPolicies = (sca?.aggregations?.by_agent?.buckets??[]).map((b:any)=>({
    agent: b.key,
    score: Math.round(b.latest_score?.value??0),
  })).slice(0,8);

  const scaResults = sca?.aggregations?.by_result?.buckets??[];
  const passed = scaResults.find((b:any)=>b.key==='passed')?.doc_count??0;
  const failed = scaResults.find((b:any)=>b.key==='failed')?.doc_count??0;
  const totalSCA = passed+failed;

  return (
    <div className="flex flex-col h-full">
      {/* ── Header ── */}
      <div className="px-5 pt-4 pb-0 shrink-0">
        <div className="flex items-center gap-3 mb-4">
          <h1 className="font-black text-white" style={{fontSize:20,letterSpacing:'-0.02em'}}>SIEM — Security Information & Event Management</h1>
          <span className="badge badge-active">LIVE</span>
        </div>
        {/* Tab bar */}
        <div className="flex gap-0 border-b overflow-x-auto" style={{borderColor:'var(--border)'}}>
          {MAIN_TABS.map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)}
              className="px-4 py-2 label-caps whitespace-nowrap transition-colors border-b-2 -mb-px shrink-0"
              style={{fontSize:8, borderColor:tab===t.id?'var(--cyan)':'transparent', color:tab===t.id?'var(--cyan)':'var(--text-dim)'}}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── Content ── */}
      <div className="flex-1 overflow-auto p-5">

        {/* EVENTS */}
        {tab==='events' && (
          <div className="space-y-3">
            {/* Filters */}
            <div className="flex items-center gap-3 flex-wrap">
              <div className="relative">
                <svg className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-dim" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                <input value={alertFilter} onChange={e=>setAlertFilter(e.target.value)} className="field pl-8 py-1.5" style={{fontSize:11,width:220}} placeholder="Filter events…"/>
              </div>
              <div className="flex gap-1.5">
                {['all','CRITICAL','HIGH','MEDIUM','LOW'].map(l=>(
                  <button key={l} onClick={()=>setLevelFilter(l)}
                    className="label-caps px-2.5 py-1.5 rounded-lg transition-colors"
                    style={{fontSize:8, background:levelFilter===l?`${SEV_COLOR[l]??'var(--cyan)'}18`:'transparent', border:`1px solid ${levelFilter===l?SEV_COLOR[l]??'var(--cyan)':'var(--border)'}`, color:levelFilter===l?SEV_COLOR[l]??'var(--cyan)':'var(--text-dim)'}}>
                    {l}
                  </button>
                ))}
              </div>
              <span className="mono text-dim ml-auto" style={{fontSize:10}}>{filteredAlerts.length} events</span>
            </div>
            <div className="card" style={{overflow:'auto',maxHeight:'calc(100vh - 280px)'}}>
              <table className="data-table">
                <thead><tr><th>Timestamp</th><th>Severity</th><th>Agent</th><th>Group</th><th>Rule</th><th>Level</th><th>MITRE</th></tr></thead>
                <tbody>
                  {filteredAlerts.map(a=>(
                    <tr key={a.id} onClick={()=>setSelectedAlert(a.id)}>
                      <td className="mono text-dim" style={{fontSize:10}}>{a.timestamp?new Date(a.timestamp).toLocaleString():''}</td>
                      <td><SevBadge s={a.severity??'INFO'}/></td>
                      <td className="text-white font-medium" style={{fontSize:11}}>{a.agent?.name??'—'}</td>
                      <td className="mono text-dim" style={{fontSize:10}}>{a.agent?.labels?.group??'—'}</td>
                      <td className="text-secondary" style={{fontSize:11,maxWidth:200}}><span className="truncate block" title={a.rule?.description}>{a.rule?.description??'—'}</span></td>
                      <td className="mono font-bold" style={{fontSize:11,color:(a.rule?.level??0)>=13?'#ef4444':(a.rule?.level??0)>=10?'#f59e0b':'var(--text-secondary)'}}>{a.rule?.level??'—'}</td>
                      <td>{a.rule?.mitre?.id?.[0]?<span className="badge badge-info" style={{fontSize:8}}>{a.rule.mitre.id[0]}</span>:'—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {filteredAlerts.length===0&&<div className="py-10 text-center"><p className="mono text-dim" style={{fontSize:11}}>{isLoading('events')?'Loading events…':'No events match filters'}</p></div>}
            </div>
          </div>
        )}

        {/* FIM */}
        {tab==='fim' && (
          <div className="card" style={{overflow:'auto',maxHeight:'calc(100vh - 220px)'}}>
            <div className="px-4 py-3 border-b flex items-center justify-between" style={{borderColor:'var(--border)'}}>
              <p className="label-caps text-secondary" style={{fontSize:9}}>File Integrity Monitoring — Registry & File Changes</p>
              {isLoading('fim')&&<div className="w-4 h-4 border border-cyan-400 border-t-transparent rounded-full animate-spin"/>}
            </div>
            <table className="data-table">
              <thead><tr><th>Timestamp</th><th>Agent</th><th>File/Registry Path</th><th>Event Type</th><th>MD5</th></tr></thead>
              <tbody>
                {fim.map((f:any,i:number)=>(
                  <tr key={i} onClick={()=>f.id&&setSelectedAlert(f.id)}>
                    <td className="mono text-dim" style={{fontSize:10}}>{f.timestamp?new Date(f.timestamp).toLocaleString():''}</td>
                    <td className="text-white" style={{fontSize:11}}>{f.agent?.name??'—'}</td>
                    <td className="mono text-secondary" style={{fontSize:10,maxWidth:280}}><span className="truncate block" title={f.syscheck?.path}>{f.syscheck?.path??'—'}</span></td>
                    <td><span className={`badge ${f.syscheck?.event==='modified'?'badge-warning':f.syscheck?.event==='deleted'?'badge-critical':'badge-info'}`}>{f.syscheck?.event??'changed'}</span></td>
                    <td className="mono text-dim" style={{fontSize:9}}>{f.syscheck?.md5_after?.slice(0,16)+'…'??'—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {fim.length===0&&<div className="py-12 text-center"><p className="mono text-dim" style={{fontSize:11}}>{isLoading('fim')?'Loading…':'No FIM events found'}</p></div>}
          </div>
        )}

        {/* SCA */}
        {tab==='sca' && (
          <div className="space-y-4">
            {/* Summary */}
            <div className="grid grid-cols-3 gap-4">
              <div className="card p-4 text-center">
                <p className="label-caps text-dim mb-2" style={{fontSize:8}}>Passed Checks</p>
                <p className="stat-value text-green-400" style={{fontSize:28}}>{passed.toLocaleString()}</p>
              </div>
              <div className="card p-4 text-center">
                <p className="label-caps text-dim mb-2" style={{fontSize:8}}>Failed Checks</p>
                <p className="stat-value text-red-400" style={{fontSize:28}}>{failed.toLocaleString()}</p>
              </div>
              <div className="card p-4 text-center">
                <p className="label-caps text-dim mb-2" style={{fontSize:8}}>Pass Rate</p>
                <p className="stat-value" style={{fontSize:28,color:totalSCA>0&&passed/totalSCA>=0.8?'var(--green)':totalSCA>0&&passed/totalSCA>=0.6?'var(--amber)':'var(--red)'}}>
                  {totalSCA>0?Math.round((passed/totalSCA)*100):0}%
                </p>
              </div>
            </div>
            {/* Per-agent scores */}
            <div className="card p-4">
              <p className="label-caps text-secondary mb-3" style={{fontSize:9}}>SCA Score by Agent (Latest)</p>
              {scaPolicies.length>0?(
                <div style={{height:200}}>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={scaPolicies} layout="vertical" margin={{top:0,right:20,bottom:0,left:0}}>
                      <XAxis type="number" domain={[0,100]} tick={{fontSize:9,fill:'var(--text-dim)'}}/>
                      <YAxis type="category" dataKey="agent" tick={{fontSize:9,fill:'var(--text-secondary)'}} width={140} tickLine={false} axisLine={false}/>
                      <Tooltip/>
                      <Bar dataKey="score" name="Score" radius={[0,3,3,0]} barSize={10}
                        fill="var(--cyan)"/>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ):<p className="mono text-dim text-center py-8" style={{fontSize:11}}>{isLoading('sca')?'Loading SCA data…':'No SCA data. Enable SCA module in agents.'}</p>}
            </div>
          </div>
        )}

        {/* VULNERABILITY */}
        {tab==='vulnerability' && (
          <div className="space-y-4">
            {vuln ? (
              <div className="card p-4">
                <p className="label-caps text-secondary mb-4" style={{fontSize:9}}>Vulnerability Detection</p>
                <div className="grid grid-cols-4 gap-3 mb-4">
                  {['Critical','High','Medium','Low'].map(s=>(
                    <div key={s} className="card p-3 text-center">
                      <p className="label-caps text-dim mb-1" style={{fontSize:8}}>{s}</p>
                      <p className="stat-value" style={{fontSize:24,color:s==='Critical'?'var(--red)':s==='High'?'var(--amber)':s==='Medium'?'#eab308':'var(--blue)'}}>
                        {vuln?.aggregations?.[s.toLowerCase()]?.doc_count??0}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="card py-16 text-center">
                <p className="mono text-secondary" style={{fontSize:13}}>No Vulnerability Data</p>
                <p className="mono text-dim mt-2" style={{fontSize:11}}>Enable Vulnerability Detection module in Wazuh agents.</p>
              </div>
            )}
          </div>
        )}

        {/* COMPLIANCE */}
        {tab==='compliance' && (
          <div className="space-y-4">
            {/* Framework tabs */}
            <div className="flex gap-2 flex-wrap">
              {COMPLIANCE_TABS.map(ct=>(
                <button key={ct.id} onClick={()=>{setComplianceTab(ct.id);loadComplianceAlerts(ct.id);}}
                  className="px-4 py-2 rounded-lg label-caps transition-all"
                  style={{fontSize:9, background:complianceTab===ct.id?`${ct.color}20`:'transparent', border:`1px solid ${complianceTab===ct.id?ct.color:'var(--border)'}`, color:complianceTab===ct.id?ct.color:'var(--text-dim)'}}>
                  {ct.label}
                </button>
              ))}
            </div>
            {/* Stats */}
            {compliance && (
              <div className="card p-4">
                <div className="flex items-center justify-between mb-3">
                  <p className="label-caps text-secondary" style={{fontSize:9}}>
                    {COMPLIANCE_TABS.find(c=>c.id===complianceTab)?.label} — Top Requirements
                  </p>
                  <span className="badge badge-active">{compliance?.aggregations?.[complianceTab]?.doc_count?.toLocaleString()??0} events</span>
                </div>
                <div style={{height:200}}>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={(compliance?.aggregations?.[complianceTab]?.requirements?.buckets??[]).slice(0,15).map((b:any)=>({key:b.key,count:b.doc_count}))}
                      margin={{top:0,right:0,bottom:40,left:0}}>
                      <XAxis dataKey="key" tick={{fontSize:8,fill:'var(--text-dim)'}} angle={-45} textAnchor="end"/>
                      <YAxis tick={{fontSize:9,fill:'var(--text-dim)'}}/>
                      <Tooltip/>
                      <Bar dataKey="count" name="Alerts" fill={COMPLIANCE_TABS.find(c=>c.id===complianceTab)?.color??'var(--cyan)'} radius={[3,3,0,0]}/>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}
            {/* Recent compliance alerts */}
            <div className="card" style={{maxHeight:300,overflow:'auto'}}>
              <div className="px-4 py-3 border-b" style={{borderColor:'var(--border)'}}>
                <p className="label-caps text-secondary" style={{fontSize:9}}>Recent {COMPLIANCE_TABS.find(c=>c.id===complianceTab)?.label} Alerts</p>
              </div>
              <table className="data-table">
                <thead><tr><th>Timestamp</th><th>Agent</th><th>Rule</th><th>Requirements</th></tr></thead>
                <tbody>
                  {compAlerts.slice(0,50).map((a:any,i:number)=>(
                    <tr key={i} onClick={()=>a.id&&setSelectedAlert(a.id)}>
                      <td className="mono text-dim" style={{fontSize:10}}>{a.timestamp?new Date(a.timestamp).toLocaleString():''}</td>
                      <td className="text-white" style={{fontSize:11}}>{a.agent?.name??'—'}</td>
                      <td className="text-secondary" style={{fontSize:11}}>{a.rule?.description??'—'}</td>
                      <td className="mono text-dim" style={{fontSize:9}}>{(a.rule?.[complianceTab]??[]).slice(0,3).join(', ')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {compAlerts.length===0&&<div className="py-8 text-center"><p className="mono text-dim" style={{fontSize:11}}>{isLoading('compAlerts')?'Loading…':'No compliance alerts found'}</p></div>}
            </div>
          </div>
        )}

        {/* MITRE */}
        {tab==='mitre' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="card p-4">
                <p className="label-caps text-secondary mb-3" style={{fontSize:9}}>Top Techniques</p>
                {(mitre?.aggregations?.techniques?.buckets??[]).length>0?(
                  <div style={{height:280}}>
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={(mitre.aggregations.techniques.buckets).slice(0,15).map((b:any)=>({name:b.key,count:b.doc_count}))} layout="vertical" margin={{top:0,right:8,bottom:0,left:0}}>
                        <XAxis type="number" tick={{fontSize:9,fill:'var(--text-dim)'}}/>
                        <YAxis type="category" dataKey="name" tick={{fontSize:10,fill:'var(--text-secondary)'}} width={80} tickLine={false} axisLine={false}/>
                        <Tooltip/>
                        <Bar dataKey="count" name="Events" fill="var(--purple)" radius={[0,3,3,0]} barSize={10}/>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                ):<p className="mono text-dim text-center py-8" style={{fontSize:11}}>{isLoading('mitre')?'Loading…':'No MITRE data'}</p>}
              </div>
              <div className="card p-4">
                <p className="label-caps text-secondary mb-3" style={{fontSize:9}}>Tactics Coverage</p>
                {(mitre?.aggregations?.tactics?.buckets??[]).length>0?(
                  <div className="space-y-2">
                    {(mitre.aggregations.tactics.buckets).map((b:any)=>{
                      const max=(mitre.aggregations.tactics.buckets[0]?.doc_count??1);
                      return (
                        <div key={b.key}>
                          <div className="flex justify-between mb-0.5">
                            <span className="text-secondary" style={{fontSize:10}}>{b.key}</span>
                            <span className="mono font-bold text-white" style={{fontSize:10}}>{b.doc_count.toLocaleString()}</span>
                          </div>
                          <div className="rounded-full overflow-hidden" style={{height:4,background:'rgba(255,255,255,0.05)'}}>
                            <div style={{width:`${(b.doc_count/max)*100}%`,height:'100%',background:'var(--amber)',borderRadius:4}}/>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ):<p className="mono text-dim text-center py-8" style={{fontSize:11}}>No tactic data</p>}
              </div>
            </div>
          </div>
        )}

        {/* THREAT HUNTING */}
        {tab==='threat-hunting' && (
          <div className="space-y-3">
            <div className="px-3 py-2.5 rounded-xl flex items-center gap-2" style={{background:'rgba(0,216,232,0.06)',border:'1px solid rgba(0,216,232,0.15)'}}>
              <svg className="w-4 h-4 text-cyan-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
              <p className="mono text-secondary" style={{fontSize:11}}>Showing high-severity (≥10) alerts with MITRE ATT&CK mapping for active threat hunting.</p>
            </div>
            <div className="card" style={{overflow:'auto',maxHeight:'calc(100vh - 280px)'}}>
              <table className="data-table">
                <thead><tr><th>Timestamp</th><th>Severity</th><th>Agent</th><th>Rule</th><th>Technique</th><th>Tactic</th><th>Src IP</th></tr></thead>
                <tbody>
                  {alerts.filter(a=>(a.rule?.level??0)>=10&&a.rule?.mitre?.id?.length>0).slice(0,100).map(a=>(
                    <tr key={a.id} onClick={()=>setSelectedAlert(a.id)}>
                      <td className="mono text-dim" style={{fontSize:10}}>{a.timestamp?new Date(a.timestamp).toLocaleString():''}</td>
                      <td><SevBadge s={a.severity??'INFO'}/></td>
                      <td className="text-white" style={{fontSize:11}}>{a.agent?.name??'—'}</td>
                      <td className="text-secondary" style={{fontSize:11,maxWidth:180}}><span className="truncate block">{a.rule?.description??'—'}</span></td>
                      <td className="mono" style={{fontSize:10,color:'var(--cyan)'}}>{a.rule?.mitre?.id?.[0]??'—'}</td>
                      <td className="mono text-dim" style={{fontSize:10}}>{a.rule?.mitre?.tactic?.[0]??'—'}</td>
                      <td className="mono text-dim" style={{fontSize:10}}>{a.data?.srcip??'—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {alerts.filter(a=>(a.rule?.level??0)>=10&&a.rule?.mitre?.id?.length>0).length===0&&(
                <div className="py-10 text-center"><p className="mono text-dim" style={{fontSize:11}}>No high-severity MITRE-tagged alerts found</p></div>
              )}
            </div>
          </div>
        )}

        {/* MALWARE */}
        {tab==='malware' && (
          <div className="card" style={{overflow:'auto',maxHeight:'calc(100vh - 220px)'}}>
            <div className="px-4 py-3 border-b" style={{borderColor:'var(--border)'}}>
              <p className="label-caps text-secondary" style={{fontSize:9}}>Malware Detection — virus, rootcheck, trojan alerts</p>
            </div>
            <table className="data-table">
              <thead><tr><th>Timestamp</th><th>Agent</th><th>Rule Groups</th><th>Description</th><th>Level</th></tr></thead>
              <tbody>
                {alerts.filter(a=>{
                  const grps = a.rule?.groups??[];
                  return grps.some((g:string)=>['virus','malware','rootcheck','trojan'].includes(g));
                }).map(a=>(
                  <tr key={a.id} onClick={()=>setSelectedAlert(a.id)}>
                    <td className="mono text-dim" style={{fontSize:10}}>{a.timestamp?new Date(a.timestamp).toLocaleString():''}</td>
                    <td className="text-white" style={{fontSize:11}}>{a.agent?.name??'—'}</td>
                    <td>{(a.rule?.groups??[]).map((g:string)=><span key={g} className="badge badge-critical mr-1" style={{fontSize:8}}>{g}</span>)}</td>
                    <td className="text-secondary" style={{fontSize:11}}>{a.rule?.description??'—'}</td>
                    <td className="mono font-bold text-red-400" style={{fontSize:11}}>{a.rule?.level??'—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {alerts.filter(a=>(a.rule?.groups??[]).some((g:string)=>['virus','malware','rootcheck','trojan'].includes(g))).length===0&&(
              <div className="py-10 text-center"><p className="mono text-dim" style={{fontSize:11}}>No malware detections in current alert set</p></div>
            )}
          </div>
        )}
      </div>

      <AlertDetailPanel alertId={selectedAlert} onClose={()=>setSelectedAlert(null)}/>
    </div>
  );
}
