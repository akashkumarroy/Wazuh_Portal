'use client';
import { useState, useEffect, useCallback } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

type Tab = 'overview' | 'workflows' | 'dfir' | 'cases';

export default function SOARPage() {
  const [tab, setTab]             = useState<Tab>('overview');
  const [soarStats, setSoarStats] = useState<any>(null);
  const [workflows, setWorkflows] = useState<any[]>([]);
  const [irisStats, setIrisStats] = useState<any>(null);
  const [irisCases, setIrisCases] = useState<any[]>([]);
  const [irisAlerts, setIrisAlerts] = useState<any[]>([]);
  const [loading, setLoading]     = useState(true);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    try {
      const [soar, wf, iris, cases, alerts] = await Promise.allSettled([
        fetch('/api/soar/stats').then(r=>r.json()),
        fetch('/api/soar/stats?workflows=true').then(r=>r.json()),
        fetch('/api/soar/iris').then(r=>r.json()),
        fetch('/api/soar/iris?type=cases').then(r=>r.json()),
        fetch('/api/soar/iris?type=alerts').then(r=>r.json()),
      ]);
      if (soar.status==='fulfilled') setSoarStats(soar.value);
      if (wf.status==='fulfilled') setWorkflows(wf.value.workflows??[]);
      if (iris.status==='fulfilled') { setIrisStats(iris.value.stats); setIrisCases(iris.value.cases??[]); }
      if (cases.status==='fulfilled') setIrisCases(cases.value.cases??[]);
      if (alerts.status==='fulfilled') setIrisAlerts(alerts.value.alerts??[]);
    } finally { setLoading(false); }
  }, []);

  useEffect(()=>{ fetchAll(); },[fetchAll]);
  useEffect(()=>{ const id=setInterval(fetchAll, 60_000); return ()=>clearInterval(id); },[fetchAll]);

  const TABS: {id:Tab;label:string}[] = [
    {id:'overview',  label:'Overview'},
    {id:'workflows', label:'Shuffle Workflows'},
    {id:'dfir',      label:'DFIR (IRIS)'},
    {id:'cases',     label:'Active Cases'},
  ];

  // Case state breakdown for pie
  const caseStates: Record<string,number> = {};
  irisCases.forEach((c:any) => { const s=c.state_name??'Unknown'; caseStates[s]=(caseStates[s]??0)+1; });
  const caseStateData = Object.entries(caseStates).map(([name,value])=>({
    name, value,
    color: name==='Closed'?'#10b981':name==='In Progress'?'#f59e0b':name==='Open'?'#ef4444':'#64748b',
  }));

  const getSeverityColor = (id: number) => {
    if (id===1) return '#ef4444';
    if (id===2) return '#f59e0b';
    if (id===3) return '#eab308';
    return '#3b82f6';
  };
  const getSeverityLabel = (id: number) => ['','Critical','High','Medium','Low','Informational'][id]??'Unknown';

  if (loading && !soarStats) return (
    <div className="flex items-center justify-center h-full gap-3">
      <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin"/>
      <p className="mono text-secondary" style={{fontSize:12}}>Loading SOAR & DFIR data…</p>
    </div>
  );

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 pt-4 pb-0 shrink-0">
        <div className="flex items-center gap-3 mb-4">
          <h1 className="font-black text-white" style={{fontSize:20,letterSpacing:'-0.02em'}}>SOAR & DFIR</h1>
          <span className="badge badge-active">LIVE</span>
        </div>
        <div className="flex gap-0 border-b" style={{borderColor:'var(--border)'}}>
          {TABS.map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)}
              className="px-5 py-2 label-caps whitespace-nowrap transition-colors border-b-2 -mb-px"
              style={{fontSize:8, borderColor:tab===t.id?'var(--cyan)':'transparent', color:tab===t.id?'var(--cyan)':'var(--text-dim)'}}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-auto p-5 space-y-4">

        {/* OVERVIEW */}
        {tab==='overview' && (
          <>
            {/* KPIs */}
            <div className="grid grid-cols-4 gap-4">
              {[
                { label:'Total Workflows',    value:String(soarStats?.total??0),      color:'var(--cyan)',   icon:'M13 10V3L4 14h7v7l9-11h-7z' },
                { label:'Active Workflows',   value:String(soarStats?.active??0),     color:'var(--green)',  icon:'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z' },
                { label:'Open Cases (IRIS)',  value:String(irisStats?.open??0),       color:'#ef4444',      icon:'M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z' },
                { label:'Total Cases (IRIS)', value:String(irisStats?.total??0),      color:'var(--amber)',  icon:'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2' },
              ].map(s=>(
                <div key={s.label} className="card p-4">
                  <div className="flex items-start justify-between mb-2">
                    <p className="label-caps text-dim" style={{fontSize:8}}>{s.label}</p>
                    <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{background:`${s.color}18`}}>
                      <svg className="w-3.5 h-3.5" style={{color:s.color}} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d={s.icon}/>
                      </svg>
                    </div>
                  </div>
                  <p className="stat-value" style={{fontSize:28,color:s.color}}>{s.value}</p>
                </div>
              ))}
            </div>

            {/* Workflow list + Case state */}
            <div className="grid grid-cols-3 gap-4">
              <div className="col-span-2 card flex flex-col" style={{maxHeight:320}}>
                <div className="px-4 py-3 border-b shrink-0 flex items-center justify-between" style={{borderColor:'var(--border)'}}>
                  <p className="label-caps text-secondary" style={{fontSize:9}}>Shuffle Workflows</p>
                  <a href="https://shuffler.io" target="_blank" rel="noopener noreferrer"
                    className="mono text-dim hover:text-cyan-400 transition-colors" style={{fontSize:9}}>
                    Open Shuffle ↗
                  </a>
                </div>
                <div className="overflow-auto flex-1">
                  {workflows.length>0 ? (
                    <table className="data-table">
                      <thead><tr><th>Workflow</th><th>Status</th><th>Triggers</th><th>Actions</th></tr></thead>
                      <tbody>
                        {workflows.slice(0,15).map((w:any,i:number)=>(
                          <tr key={w.id??i}>
                            <td className="text-white font-medium" style={{fontSize:11}}>{w.name??'Unnamed'}</td>
                            <td>
                              <span className={`badge ${w.status==='running'||w.is_running?'badge-active':w.status==='failed'?'badge-critical':'badge-info'}`}>
                                {w.status==='running'||w.is_running?'RUNNING':w.status??'IDLE'}
                              </span>
                            </td>
                            <td className="mono text-dim" style={{fontSize:10}}>{(w.triggers??[]).length}</td>
                            <td className="mono text-dim" style={{fontSize:10}}>{(w.actions??[]).length}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full gap-2">
                      <svg className="w-8 h-8 text-dim" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                      <p className="mono text-dim" style={{fontSize:11}}>No workflows found in Shuffle</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="card p-4">
                <p className="label-caps text-secondary mb-3" style={{fontSize:9}}>Case Status Distribution</p>
                {caseStateData.length>0?(
                  <>
                    <div style={{height:130}}>
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie data={caseStateData} cx="50%" cy="50%" innerRadius={35} outerRadius={55} dataKey="value" stroke="none">
                            {caseStateData.map((d,i)=><Cell key={i} fill={d.color}/>)}
                          </Pie>
                          <Tooltip/>
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="space-y-1.5 mt-2">
                      {caseStateData.map(d=>(
                        <div key={d.name} className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <div className="w-2 h-2 rounded-sm" style={{background:d.color}}/>
                            <span className="mono text-secondary" style={{fontSize:10}}>{d.name}</span>
                          </div>
                          <span className="mono font-bold" style={{fontSize:11,color:d.color}}>{d.value}</span>
                        </div>
                      ))}
                    </div>
                  </>
                ):<p className="mono text-dim text-center py-8" style={{fontSize:11}}>No case data</p>}
              </div>
            </div>

            {/* Recent IRIS Alerts */}
            {irisAlerts.length > 0 && (
              <div className="card">
                <div className="px-4 py-3 border-b flex items-center justify-between" style={{borderColor:'var(--border)'}}>
                  <p className="label-caps text-secondary" style={{fontSize:9}}>Recent IRIS Alerts</p>
                  <span className="badge badge-info">{irisAlerts.length} alerts</span>
                </div>
                <div style={{overflow:'auto',maxHeight:200}}>
                  <table className="data-table">
                    <thead><tr><th>Alert Title</th><th>Source</th><th>Status</th><th>Date</th></tr></thead>
                    <tbody>
                      {irisAlerts.slice(0,15).map((a:any,i:number)=>(
                        <tr key={i}>
                          <td className="text-white font-medium" style={{fontSize:11}}>{a.alert_title??a.alert_name??'Untitled'}</td>
                          <td className="mono text-dim" style={{fontSize:10}}>{a.alert_source??'—'}</td>
                          <td><span className="badge badge-info" style={{fontSize:8}}>{a.alert_status_id??'—'}</span></td>
                          <td className="mono text-dim" style={{fontSize:10}}>{a.alert_source_event_time??a.alert_creation_time??'—'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </>
        )}

        {/* WORKFLOWS */}
        {tab==='workflows' && (
          <div className="space-y-3">
            <div className="grid grid-cols-4 gap-3">
              {[
                {label:'Total',  v:soarStats?.total??0, c:'var(--cyan)'},
                {label:'Active', v:soarStats?.active??0, c:'var(--green)'},
                {label:'Success',v:soarStats?.success??0, c:'var(--green)'},
                {label:'Failed', v:soarStats?.failed??0, c:'var(--red)'},
              ].map(s=>(
                <div key={s.label} className="card p-3 text-center">
                  <p className="label-caps text-dim" style={{fontSize:8}}>{s.label}</p>
                  <p className="stat-value mt-1" style={{fontSize:22,color:s.c}}>{s.v}</p>
                </div>
              ))}
            </div>
            <div className="card" style={{overflow:'auto',maxHeight:'calc(100vh - 320px)'}}>
              <div className="px-4 py-3 border-b flex items-center justify-between" style={{borderColor:'var(--border)'}}>
                <p className="label-caps text-secondary" style={{fontSize:9}}>All Shuffle Workflows</p>
                <a href="https://shuffler.io" target="_blank" rel="noopener noreferrer"
                  className="label-caps text-cyan-400 hover:text-cyan-300 transition-colors" style={{fontSize:8}}>
                  Manage in Shuffle ↗
                </a>
              </div>
              {workflows.length>0?(
                <div className="p-4 grid grid-cols-2 gap-3">
                  {workflows.map((w:any,i:number)=>(
                    <div key={w.id??i} className="card-hover p-4 rounded-xl">
                      <div className="flex items-start justify-between mb-2">
                        <p className="font-semibold text-white" style={{fontSize:13}}>{w.name??'Unnamed Workflow'}</p>
                        <span className={`badge ${w.status==='running'||w.is_running?'badge-active':w.status==='failed'?'badge-critical':'badge-info'}`}>
                          {w.status==='running'||w.is_running?'RUNNING':w.status??'IDLE'}
                        </span>
                      </div>
                      {w.description&&<p className="mono text-secondary" style={{fontSize:10,lineHeight:1.4}}>{w.description.slice(0,80)}</p>}
                      <div className="flex gap-3 mt-2 pt-2 border-t" style={{borderColor:'var(--border)'}}>
                        <span className="mono text-dim" style={{fontSize:9}}>⚡ {(w.triggers??[]).length} triggers</span>
                        <span className="mono text-dim" style={{fontSize:9}}>🔧 {(w.actions??[]).length} actions</span>
                      </div>
                    </div>
                  ))}
                </div>
              ):(
                <div className="py-16 text-center">
                  <p className="mono text-secondary" style={{fontSize:13}}>No workflows found</p>
                  <p className="mono text-dim mt-2" style={{fontSize:11}}>Create workflows in Shuffle to automate SOC responses.</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* DFIR */}
        {tab==='dfir' && (
          <div className="space-y-4">
            <div className="px-4 py-3 rounded-xl flex items-center gap-3"
              style={{background:'rgba(124,58,237,0.08)',border:'1px solid rgba(124,58,237,0.2)'}}>
              <svg className="w-5 h-5 text-purple-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
              <div>
                <p className="font-semibold text-white" style={{fontSize:13}}>Digital Forensics & Incident Response — Powered by IRIS</p>
                <p className="mono text-dim" style={{fontSize:10}}>Real-time case management · Evidence tracking · Timeline analysis</p>
              </div>
              <a href={process.env.NEXT_PUBLIC_IRIS_URL??'https://10.0.7.93:4433'} target="_blank" rel="noopener noreferrer"
                className="ml-auto label-caps text-purple-400 hover:text-purple-300 shrink-0" style={{fontSize:8}}>
                Open IRIS ↗
              </a>
            </div>

            {/* DFIR Stats */}
            <div className="grid grid-cols-3 gap-4">
              <div className="card p-4 text-center">
                <p className="label-caps text-dim mb-2" style={{fontSize:8}}>Total Cases</p>
                <p className="stat-value text-white" style={{fontSize:32}}>{irisStats?.total??0}</p>
              </div>
              <div className="card p-4 text-center">
                <p className="label-caps text-dim mb-2" style={{fontSize:8}}>Open / In Progress</p>
                <p className="stat-value text-red-400" style={{fontSize:32}}>{(irisStats?.open??0)+(irisStats?.in_progress??0)}</p>
              </div>
              <div className="card p-4 text-center">
                <p className="label-caps text-dim mb-2" style={{fontSize:8}}>Closed</p>
                <p className="stat-value text-green-400" style={{fontSize:32}}>{irisStats?.closed??0}</p>
              </div>
            </div>

            {/* Case severity breakdown */}
            <div className="grid grid-cols-2 gap-4">
              <div className="card p-4">
                <p className="label-caps text-secondary mb-3" style={{fontSize:9}}>Cases by Severity</p>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    {label:'Critical', v:irisStats?.critical??0, c:'#ef4444'},
                    {label:'High',     v:irisStats?.high??0,     c:'#f59e0b'},
                  ].map(s=>(
                    <div key={s.label} className="card p-3 text-center">
                      <p className="label-caps text-dim" style={{fontSize:8}}>{s.label}</p>
                      <p className="stat-value" style={{fontSize:24,color:s.c}}>{s.v}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="card p-4">
                <p className="label-caps text-secondary mb-3" style={{fontSize:9}}>Case State Distribution</p>
                {caseStateData.length>0?(
                  <div style={{height:130}}>
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie data={caseStateData} cx="50%" cy="50%" innerRadius={35} outerRadius={55} dataKey="value" stroke="none">
                          {caseStateData.map((d,i)=><Cell key={i} fill={d.color}/>)}
                        </Pie>
                        <Tooltip/>
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                ):<p className="mono text-dim text-center py-4" style={{fontSize:10}}>No data</p>}
              </div>
            </div>

            {/* Recent cases */}
            <div className="card" style={{overflow:'auto',maxHeight:280}}>
              <div className="px-4 py-3 border-b" style={{borderColor:'var(--border)'}}>
                <p className="label-caps text-secondary" style={{fontSize:9}}>Recent Cases</p>
              </div>
              {irisCases.length>0?(
                <table className="data-table">
                  <thead><tr><th>#</th><th>Case Name</th><th>Severity</th><th>State</th><th>Customer</th><th>Open Date</th></tr></thead>
                  <tbody>
                    {irisCases.slice(0,20).map((c:any,i:number)=>(
                      <tr key={i}>
                        <td className="mono text-dim" style={{fontSize:10}}>#{c.case_id}</td>
                        <td className="text-white font-medium" style={{fontSize:11}}>{c.case_name}</td>
                        <td>
                          <span className="mono font-bold" style={{fontSize:11,color:getSeverityColor(c.severity_id)}}>
                            {getSeverityLabel(c.severity_id)}
                          </span>
                        </td>
                        <td>
                          <span className={`badge ${c.state_name==='Closed'?'badge-active':c.state_name==='In Progress'?'badge-warning':'badge-critical'}`} style={{fontSize:8}}>
                            {c.state_name??'Open'}
                          </span>
                        </td>
                        <td className="mono text-dim" style={{fontSize:10}}>{c.case_customer??'—'}</td>
                        <td className="mono text-dim" style={{fontSize:10}}>{c.open_date??'—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ):(
                <div className="py-12 text-center">
                  <p className="mono text-dim" style={{fontSize:11}}>No cases found in IRIS</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* CASES */}
        {tab==='cases' && (
          <div className="card" style={{overflow:'auto',maxHeight:'calc(100vh - 220px)'}}>
            <div className="px-4 py-3 border-b flex items-center justify-between" style={{borderColor:'var(--border)'}}>
              <p className="label-caps text-secondary" style={{fontSize:9}}>All Active Cases — IRIS</p>
              <span className="badge badge-warning">{irisCases.filter((c:any)=>c.state_name!=='Closed').length} ACTIVE</span>
            </div>
            {irisCases.length>0?(
              <table className="data-table">
                <thead><tr><th>#</th><th>Case Name</th><th>Severity</th><th>State</th><th>Owner</th><th>Customer</th><th>Opened</th></tr></thead>
                <tbody>
                  {irisCases.map((c:any,i:number)=>(
                    <tr key={i}>
                      <td className="mono text-dim" style={{fontSize:10}}>#{c.case_id}</td>
                      <td className="text-white font-medium" style={{fontSize:11}}>{c.case_name}</td>
                      <td>
                        <span className="mono font-bold" style={{fontSize:11,color:getSeverityColor(c.severity_id)}}>
                          {getSeverityLabel(c.severity_id)}
                        </span>
                      </td>
                      <td>
                        <span className={`badge ${c.state_name==='Closed'?'badge-active':c.state_name==='In Progress'?'badge-warning':'badge-critical'}`} style={{fontSize:8}}>
                          {c.state_name??'Open'}
                        </span>
                      </td>
                      <td className="mono text-dim" style={{fontSize:10}}>{c.owner_id??'—'}</td>
                      <td className="mono text-dim" style={{fontSize:10}}>{c.case_customer??'—'}</td>
                      <td className="mono text-dim" style={{fontSize:10}}>{c.open_date??'—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ):(
              <div className="py-16 text-center">
                <p className="mono text-secondary" style={{fontSize:13}}>No cases found in IRIS</p>
                <p className="mono text-dim mt-2" style={{fontSize:11}}>Create your first case in IRIS to start tracking incidents.</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
