'use client';
import { useState, useEffect, useCallback, useRef } from 'react';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from 'recharts';
import AlertDetailPanel from '@/components/widgets/AlertDetailPanel';

const SEV_COLOR: Record<string,string> = { CRITICAL:'#ef4444', HIGH:'#f59e0b', MEDIUM:'#eab308', LOW:'#3b82f6', INFO:'#475569' };
const formatNum = (n: number) => n >= 1_000_000 ? `${(n/1_000_000).toFixed(1)}M` : n >= 1_000 ? `${(n/1_000).toFixed(1)}K` : String(n);

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="card px-3 py-2 rounded-lg" style={{ fontSize:11, minWidth:100 }}>
      {label && <p className="mono text-dim mb-1" style={{ fontSize:9 }}>{label}</p>}
      {payload.map((p: any, i: number) => (
        <p key={i} className="mono font-bold" style={{ color:p.color||p.fill||'var(--cyan)' }}>{p.name}: {typeof p.value==='number'?p.value.toLocaleString():p.value}</p>
      ))}
    </div>
  );
}

export default function DashboardPage() {
  const [data, setData]               = useState<any>(null);
  const [alerts, setAlerts]           = useState<any[]>([]);
  const [loading, setLoading]         = useState(true);
  const [selectedAlert, setSelectedAlert] = useState<string|null>(null);
  const [autoRefresh, setAutoRefresh] = useState(true);

  const fetchData = useCallback(async () => {
    try {
      const [dash, alertsRes] = await Promise.allSettled([
        fetch('/api/wazuh/dashboard').then(r=>r.json()),
        fetch('/api/wazuh/alerts?size=50').then(r=>r.json()),
      ]);
      if (dash.status==='fulfilled') setData(dash.value);
      if (alertsRes.status==='fulfilled') setAlerts(alertsRes.value.alerts ?? []);
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);
  useEffect(() => {
    if (!autoRefresh) return;
    const id = setInterval(fetchData, 30_000);
    return () => clearInterval(id);
  }, [fetchData, autoRefresh]);

  // ── Derived metrics ──────────────────────────────────────────
  const stats     = data?.stats;
  const aggs      = stats?.aggregations;
  const totalAlerts = stats?.hits?.total?.value ?? 0;
  const critical  = aggs?.critical?.doc_count ?? 0;
  const high      = aggs?.high?.doc_count ?? 0;
  const medium    = aggs?.medium?.doc_count ?? 0;

  const agentAggs  = data?.agents?.aggregations;
  const agentBySt  = (agentAggs?.by_status?.buckets ?? []) as {key:string;doc_count:number}[];
  const activeA    = agentBySt.find(b=>b.key==='active')?.doc_count ?? 0;
  const disconnA   = agentBySt.find(b=>b.key==='disconnected')?.doc_count ?? 0;
  const totalAgts  = agentAggs?.unique_agents?.value ?? (activeA + disconnA);
  const healthPct  = totalAgts > 0 ? Math.round((activeA/totalAgts)*100) : 0;

  // Alert volume over time (last 24 buckets)
  const alertsOT = (aggs?.alerts_over_time?.buckets ?? []).slice(-24).map((b:any) => ({
    t: new Date(b.key_as_string).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',hour12:false}),
    v: b.doc_count,
  }));

  // Severity donut
  const sevData = [
    { name:'CRITICAL', value:critical, color:'#ef4444' },
    { name:'HIGH',     value:high,     color:'#f59e0b' },
    { name:'MEDIUM',   value:medium,   color:'#eab308' },
  ].filter(d=>d.value>0);

  // Top agents
  const topAgents = (aggs?.top_agents?.buckets ?? []).slice(0,8).map((b:any) => ({ name:b.key, count:b.doc_count }));

  // Top rules
  const topRules = (aggs?.top_rules?.buckets ?? []).slice(0,6).map((b:any) => ({ name:b.key, count:b.doc_count }));

  // MITRE tactics
  const mitreT = (aggs?.mitre_tactics?.buckets ?? []).slice(0,8).map((b:any) => ({ name:b.key, count:b.doc_count }));

  // Geo countries
  const geoCountries = (data?.geo?.aggregations?.top_countries?.buckets ?? []).slice(0,8);

  // EPS from statistics
  const perfData = (data?.perf ?? []).slice(0,20).reverse().map((p:any,i:number) => ({
    t: String(i),
    events: p.analysisd?.events_received ?? 0,
    alerts: p.analysisd?.alerts_written ?? 0,
  }));

  if (loading) return (
    <div className="flex flex-col items-center justify-center h-full gap-3">
      <div className="w-10 h-10 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
      <p className="mono text-secondary" style={{ fontSize:12 }}>Loading live data from Wazuh Indexer…</p>
    </div>
  );

  return (
    <div className="p-4 space-y-4 animate-fade">
      {/* ── Header ─────────────────────────────────────────────── */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-black text-white" style={{ fontSize:20, letterSpacing:'-0.02em' }}>
            Security Operations Center
          </h1>
          <p className="mono text-secondary mt-0.5" style={{ fontSize:11 }}>
            {data?.is_admin ? 'All tenants — Admin view' : `Tenant: ${data?.group ?? '—'}`}
            {' · '}Live data · Auto-refresh every 30s
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={fetchData} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-secondary hover:text-white transition-colors"
            style={{ border:'1px solid var(--border)', fontSize:11 }}>
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
            </svg>
            Refresh
          </button>
          <button onClick={()=>setAutoRefresh(!autoRefresh)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors"
            style={{ border:`1px solid ${autoRefresh?'rgba(0,216,232,0.3)':'var(--border)'}`, color:autoRefresh?'var(--cyan)':'var(--text-secondary)', background:autoRefresh?'rgba(0,216,232,0.06)':'transparent', fontSize:11 }}>
            <span className={`w-1.5 h-1.5 rounded-full ${autoRefresh?'bg-cyan-400 dot-live':'bg-gray-600'}`}/>
            Live
          </button>
        </div>
      </div>

      {/* ── Row 1: KPI Cards ────────────────────────────────────── */}
      <div className="grid grid-cols-5 gap-3">
        {[
          { label:'Total Alerts', value:formatNum(totalAlerts), sub:'All-time indexed', color:'var(--cyan)', icon:'M13 10V3L4 14h7v7l9-11h-7z' },
          { label:'Critical',     value:formatNum(critical),    sub:'Level 13–15',      color:'#ef4444',       icon:'M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z' },
          { label:'High',         value:formatNum(high),        sub:'Level 10–12',      color:'#f59e0b',       icon:'M12 9v2m0 4h.01' },
          { label:'Active Agents',value:formatNum(activeA),     sub:`of ${formatNum(totalAgts)} total`, color:'var(--green)', icon:'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z' },
          { label:'Health',       value:`${healthPct}%`,        sub:`${formatNum(disconnA)} disconnected`, color:healthPct>=80?'var(--green)':healthPct>=60?'var(--amber)':'var(--red)', icon:'M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z' },
        ].map(s => (
          <div key={s.label} className="card p-4">
            <div className="flex items-start justify-between mb-2">
              <p className="label-caps text-dim" style={{ fontSize:8 }}>{s.label}</p>
              <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background:`${s.color}18` }}>
                <svg className="w-3.5 h-3.5" style={{ color:s.color }} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d={s.icon}/>
                </svg>
              </div>
            </div>
            <p className="stat-value" style={{ fontSize:24, color:s.color }}>{s.value}</p>
            <p className="mono text-dim mt-1" style={{ fontSize:9 }}>{s.sub}</p>
          </div>
        ))}
      </div>

      {/* ── Row 2: Alert volume + Severity donut ────────────────── */}
      <div className="grid grid-cols-3 gap-4">
        <div className="col-span-2 card p-4">
          <div className="flex items-center justify-between mb-3">
            <p className="label-caps text-secondary" style={{ fontSize:9 }}>Alert Volume Timeline</p>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 dot-live"/>
              <span className="mono text-dim" style={{ fontSize:9 }}>Real-time · 24 data points</span>
            </div>
          </div>
          <div style={{ height:150 }}>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={alertsOT} margin={{ top:0, right:0, bottom:0, left:0 }}>
                <defs>
                  <linearGradient id="cyanGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="var(--cyan)" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="var(--cyan)" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false}/>
                <XAxis dataKey="t" tick={{ fontSize:9, fill:'var(--text-dim)' }} tickLine={false} axisLine={false}/>
                <YAxis hide />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="v" name="Alerts" stroke="var(--cyan)" strokeWidth={1.5} fill="url(#cyanGrad)"/>
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card p-4">
          <p className="label-caps text-secondary mb-3" style={{ fontSize:9 }}>Severity Distribution</p>
          {sevData.length > 0 ? (
            <>
              <div style={{ height:120 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={sevData} cx="50%" cy="50%" innerRadius={38} outerRadius={55} dataKey="value" stroke="none">
                      {sevData.map((d,i)=><Cell key={i} fill={d.color}/>)}
                    </Pie>
                    <Tooltip content={<CustomTooltip />}/>
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-1.5 mt-2">
                {sevData.map(d => (
                  <div key={d.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <div className="w-2 h-2 rounded-sm" style={{ background:d.color }}/>
                      <span className="mono text-secondary" style={{ fontSize:10 }}>{d.name}</span>
                    </div>
                    <span className="mono font-bold" style={{ fontSize:11, color:d.color }}>{formatNum(d.value)}</span>
                  </div>
                ))}
              </div>
            </>
          ) : <p className="mono text-dim text-center py-8" style={{ fontSize:11 }}>No alert data</p>}
        </div>
      </div>

      {/* ── Row 3: MITRE + Top Agents + Geo ─────────────────────── */}
      <div className="grid grid-cols-3 gap-4">
        {/* MITRE ATT&CK Tactics */}
        <div className="card p-4">
          <p className="label-caps text-secondary mb-3" style={{ fontSize:9 }}>MITRE ATT&CK Tactics</p>
          {mitreT.length > 0 ? (
            <div className="space-y-2">
              {mitreT.map(m => {
                const max = mitreT[0].count;
                return (
                  <div key={m.name}>
                    <div className="flex justify-between mb-0.5">
                      <span className="text-secondary truncate" style={{ fontSize:10, maxWidth:140 }} title={m.name}>{m.name}</span>
                      <span className="mono font-bold text-white" style={{ fontSize:10 }}>{formatNum(m.count)}</span>
                    </div>
                    <div className="rounded-full overflow-hidden" style={{ height:3, background:'rgba(255,255,255,0.05)' }}>
                      <div style={{ width:`${(m.count/max)*100}%`, height:'100%', background:'var(--purple)', borderRadius:3 }}/>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : <p className="mono text-dim text-center py-6" style={{ fontSize:10 }}>No MITRE data</p>}
        </div>

        {/* Top Agents */}
        <div className="card p-4">
          <p className="label-caps text-secondary mb-3" style={{ fontSize:9 }}>Top Alert Sources</p>
          {topAgents.length > 0 ? (
            <div style={{ height:180 }}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={topAgents} layout="vertical" margin={{top:0,right:8,bottom:0,left:0}}>
                  <XAxis type="number" hide />
                  <YAxis type="category" dataKey="name" tick={{ fontSize:10, fill:'var(--text-secondary)' }} width={110} tickLine={false} axisLine={false}/>
                  <Tooltip content={<CustomTooltip />} cursor={{ fill:'rgba(255,255,255,0.03)' }}/>
                  <Bar dataKey="count" name="Alerts" fill="var(--cyan)" radius={[0,3,3,0]} barSize={8} opacity={0.8}/>
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : <p className="mono text-dim text-center py-8" style={{ fontSize:10 }}>No agent data</p>}
        </div>

        {/* Top Countries */}
        <div className="card p-4">
          <p className="label-caps text-secondary mb-3" style={{ fontSize:9 }}>Attack Origins</p>
          {geoCountries.length > 0 ? (
            <div className="space-y-2">
              {geoCountries.slice(0,8).map((c:any,i:number) => {
                const max = geoCountries[0].doc_count;
                const threatLevel = c.doc_count/max;
                const color = threatLevel>0.7?'#ef4444':threatLevel>0.4?'#f59e0b':'var(--cyan)';
                return (
                  <div key={c.key}>
                    <div className="flex justify-between mb-0.5">
                      <span className="text-secondary" style={{ fontSize:10 }}>{c.key}</span>
                      <span className="mono font-bold" style={{ fontSize:10, color }}>{formatNum(c.doc_count)}</span>
                    </div>
                    <div className="rounded-full overflow-hidden" style={{ height:3, background:'rgba(255,255,255,0.05)' }}>
                      <div style={{ width:`${(c.doc_count/max)*100}%`, height:'100%', background:color, borderRadius:3 }}/>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : <p className="mono text-dim text-center py-6" style={{ fontSize:10 }}>No geo data</p>}
        </div>
      </div>

      {/* ── Row 4: Top Rules + Real-time Alert Feed ──────────────── */}
      <div className="grid grid-cols-3 gap-4">
        {/* EPS Performance */}
        <div className="card p-4">
          <p className="label-caps text-secondary mb-3" style={{ fontSize:9 }}>Events Per Second (EPS)</p>
          {perfData.length > 0 ? (
            <div style={{ height:120 }}>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={perfData} margin={{top:0,right:0,bottom:0,left:0}}>
                  <defs>
                    <linearGradient id="evGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%"  stopColor="var(--green)" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="var(--green)" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="alGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%"  stopColor="var(--amber)" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="var(--amber)" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="t" hide />
                  <YAxis hide />
                  <Tooltip content={<CustomTooltip />}/>
                  <Area type="monotone" dataKey="events" name="Events" stroke="var(--green)" strokeWidth={1.5} fill="url(#evGrad)"/>
                  <Area type="monotone" dataKey="alerts" name="Alerts Written" stroke="var(--amber)" strokeWidth={1.5} fill="url(#alGrad)"/>
                </AreaChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center" style={{ height:120 }}>
              <p className="mono text-dim" style={{ fontSize:10 }}>Statistics loading…</p>
            </div>
          )}
          {perfData.length > 0 && (
            <div className="grid grid-cols-2 gap-2 mt-2">
              <div className="px-2 py-1 rounded" style={{ background:'rgba(16,185,129,0.1)' }}>
                <p className="mono text-dim" style={{ fontSize:8 }}>Events/min</p>
                <p className="mono font-bold text-green-400" style={{ fontSize:13 }}>
                  {formatNum(perfData[perfData.length-1]?.events ?? 0)}
                </p>
              </div>
              <div className="px-2 py-1 rounded" style={{ background:'rgba(245,158,11,0.1)' }}>
                <p className="mono text-dim" style={{ fontSize:8 }}>Alerts/min</p>
                <p className="mono font-bold text-amber-400" style={{ fontSize:13 }}>
                  {formatNum(perfData[perfData.length-1]?.alerts ?? 0)}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Live Alert Feed */}
        <div className="col-span-2 card flex flex-col" style={{ maxHeight:280 }}>
          <div className="px-4 py-3 border-b flex items-center justify-between shrink-0" style={{ borderColor:'var(--border)' }}>
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-red-400 dot-live"/>
              <p className="label-caps text-secondary" style={{ fontSize:9 }}>Live Alert Feed</p>
            </div>
            <span className="badge badge-info">{alerts.length} loaded</span>
          </div>
          <div className="overflow-auto flex-1">
            {alerts.length > 0 ? (
              <table className="data-table">
                <thead><tr><th>Time</th><th>Severity</th><th>Agent</th><th>Rule</th><th>Level</th></tr></thead>
                <tbody>
                  {alerts.slice(0,20).map(a => (
                    <tr key={a.id} onClick={()=>setSelectedAlert(a.id)}>
                      <td className="mono text-dim" style={{ fontSize:10 }}>
                        {a.timestamp?new Date(a.timestamp).toLocaleTimeString('en-GB',{hour12:false}):'—'}
                      </td>
                      <td><span className={`badge badge-${(a.severity??'info').toLowerCase()}`}>{a.severity}</span></td>
                      <td className="text-white font-medium" style={{ fontSize:11 }}>{a.agent?.name??'—'}</td>
                      <td className="text-secondary" style={{ fontSize:11, maxWidth:200 }}>
                        <span className="truncate block" title={a.rule?.description}>{a.rule?.description??'—'}</span>
                      </td>
                      <td className="mono font-bold" style={{ fontSize:11, color: (a.rule?.level??0)>=13?'#ef4444':(a.rule?.level??0)>=10?'#f59e0b':'var(--text-secondary)' }}>
                        {a.rule?.level??'—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="flex items-center justify-center h-full">
                <p className="mono text-dim" style={{ fontSize:11 }}>No alerts loaded</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Alert detail panel */}
      <AlertDetailPanel alertId={selectedAlert} onClose={()=>setSelectedAlert(null)}/>
    </div>
  );
}
