'use client';
import { useState } from 'react';

type Format = 'json' | 'csv';

export default function ReportsPage() {
  const [loading, setLoading] = useState<Record<string,boolean>>({});
  const [dateFrom, setDateFrom] = useState(() => { const d=new Date(); d.setDate(d.getDate()-7); return d.toISOString().split('T')[0]; });
  const [dateTo, setDateTo]   = useState(() => new Date().toISOString().split('T')[0]);
  const [format, setFormat]   = useState<Format>('csv');

  const download = async (type: string, label: string) => {
    setLoading(p=>({...p,[type]:true}));
    try {
      let url = '';
      let data: any[] = [];
      if (type==='alerts') {
        const r = await fetch('/api/wazuh/alerts?size=5000').then(r=>r.json());
        data = r.alerts ?? [];
      } else if (type==='agents') {
        const r = await fetch('/api/wazuh/agents').then(r=>r.json());
        data = r.agents ?? [];
      } else if (type==='misp') {
        const r = await fetch('/api/intel/misp?limit=1000').then(r=>r.json());
        data = r.events ?? [];
      }

      let content = '';
      let mime = '';
      const filename = `prime-soc-${type}-${new Date().toISOString().split('T')[0]}`;

      if (format==='json') {
        content = JSON.stringify(data, null, 2);
        mime = 'application/json';
        url = `data:${mime};charset=utf-8,` + encodeURIComponent(content);
        const a = document.createElement('a'); a.href=url; a.download=`${filename}.json`; a.click();
      } else {
        // CSV
        if (data.length > 0) {
          const flatten = (obj:any, prefix='') => Object.entries(obj).reduce((acc:any, [k,v])=>{
            const key = prefix?`${prefix}.${k}`:k;
            if (v && typeof v==='object' && !Array.isArray(v)) Object.assign(acc, flatten(v, key));
            else acc[key] = Array.isArray(v)?v.join('|'):String(v??'');
            return acc;
          }, {});
          const rows = data.map(d=>flatten(d));
          const headers = [...new Set(rows.flatMap(r=>Object.keys(r)))].slice(0,30);
          const csv = [
            headers.join(','),
            ...rows.map(r=>headers.map(h=>`"${(r[h]??'').replace(/"/g,'""')}"`).join(',')),
          ].join('\n');
          url = `data:text/csv;charset=utf-8,` + encodeURIComponent(csv);
          const a = document.createElement('a'); a.href=url; a.download=`${filename}.csv`; a.click();
        }
      }
    } finally { setLoading(p=>({...p,[type]:false})); }
  };

  const REPORTS = [
    { id:'alerts', label:'Security Alerts',  desc:'All alerts with severity, rule, agent, MITRE mapping', icon:'M13 10V3L4 14h7v7l9-11h-7z', color:'#ef4444' },
    { id:'agents', label:'Asset Inventory',  desc:'All agents with status, OS, group, last seen',         icon:'M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2', color:'var(--cyan)' },
    { id:'misp',   label:'CTI / MISP Events','desc':'Threat intel events from MISP with IOC details',     icon:'M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945', color:'var(--amber)' },
  ];

  return (
    <div className="p-5 space-y-6">
      <div>
        <h1 className="font-black text-white" style={{fontSize:20,letterSpacing:'-0.02em'}}>Reports & Export</h1>
        <p className="mono text-secondary mt-1" style={{fontSize:11}}>Export real-time data in CSV or JSON format</p>
      </div>

      {/* Config */}
      <div className="card p-4 flex items-center gap-6">
        <div className="flex items-center gap-2">
          <label className="label-caps text-dim" style={{fontSize:8}}>Format</label>
          <div className="flex gap-2">
            {(['csv','json'] as Format[]).map(f=>(
              <button key={f} onClick={()=>setFormat(f)}
                className="label-caps px-3 py-1.5 rounded-lg transition-colors uppercase"
                style={{fontSize:9, background:format===f?'rgba(0,216,232,0.12)':'transparent', border:`1px solid ${format===f?'var(--cyan)':'var(--border)'}`, color:format===f?'var(--cyan)':'var(--text-dim)'}}>
                {f}
              </button>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <label className="label-caps text-dim" style={{fontSize:8}}>Note</label>
          <p className="mono text-secondary" style={{fontSize:10}}>Date filters apply to UI display only. Export pulls latest 5000 records.</p>
        </div>
      </div>

      {/* Report cards */}
      <div className="grid grid-cols-3 gap-4">
        {REPORTS.map(r=>(
          <div key={r.id} className="card p-5 flex flex-col gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{background:`${r.color}18`}}>
                <svg className="w-5 h-5" style={{color:r.color}} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d={r.icon}/>
                </svg>
              </div>
              <div>
                <p className="font-bold text-white" style={{fontSize:14}}>{r.label}</p>
                <p className="mono text-secondary" style={{fontSize:10}}>{r.desc}</p>
              </div>
            </div>
            <button onClick={()=>download(r.id, r.label)} disabled={loading[r.id]}
              className="w-full py-2.5 rounded-xl font-bold label-caps flex items-center justify-center gap-2 transition-all disabled:opacity-50"
              style={{background:`${r.color}18`, border:`1px solid ${r.color}30`, color:r.color, fontSize:9}}>
              {loading[r.id]?(
                <><div className="w-3.5 h-3.5 border border-current border-t-transparent rounded-full animate-spin"/>Preparing…</>
              ):(
                <><svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>Export {format.toUpperCase()}</>
              )}
            </button>
          </div>
        ))}
      </div>

      <div className="card p-4">
        <p className="label-caps text-secondary mb-2" style={{fontSize:9}}>About Reports</p>
        <p className="mono text-dim" style={{fontSize:10,lineHeight:1.6}}>
          All exported data is sourced directly from Wazuh Indexer, OpenCTI, and MISP in real time.
          Alert exports include severity, MITRE ATT&CK mapping, compliance frameworks, agent details, and geolocation.
          Asset exports include current agent status, OS information, group membership, and connectivity history.
          For scheduled automated reports, configure Shuffle workflows to generate and deliver reports via email or ticketing system.
        </p>
      </div>
    </div>
  );
}
