'use client';
import { useState, useEffect, useCallback } from 'react';

export default function AssetsPage() {
  const [agents, setAgents]     = useState<any[]>([]);
  const [loading, setLoading]   = useState(true);
  const [search, setSearch]     = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [osFilter, setOsFilter] = useState('all');
  const [selected, setSelected] = useState<any>(null);

  const fetch_ = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch('/api/wazuh/agents').then(r=>r.json());
      setAgents(r.agents??[]);
    } finally { setLoading(false); }
  }, []);

  useEffect(()=>{ fetch_(); },[fetch_]);
  useEffect(()=>{ const id=setInterval(fetch_, 60_000); return ()=>clearInterval(id); },[fetch_]);

  const filtered = agents.filter(a=>{
    const s = !search || JSON.stringify(a).toLowerCase().includes(search.toLowerCase());
    const st = statusFilter==='all' || a.status===statusFilter;
    const os = osFilter==='all' || a.os?.platform===osFilter;
    return s && st && os;
  });

  const active = agents.filter(a=>a.status==='active').length;
  const disconnected = agents.filter(a=>a.status==='disconnected').length;
  const pending = agents.filter(a=>a.status==='pending').length;

  const osPlatforms = [...new Set(agents.map(a=>a.os?.platform).filter(Boolean))];

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 pt-4 pb-4 shrink-0">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="font-black text-white" style={{fontSize:20,letterSpacing:'-0.02em'}}>Asset Inventory</h1>
            <p className="mono text-secondary mt-0.5" style={{fontSize:11}}>All monitored endpoints — Wazuh agents · Live status</p>
          </div>
          <button onClick={fetch_} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-secondary hover:text-white transition-colors"
            style={{border:'1px solid var(--border)', fontSize:11}}>
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
            Refresh
          </button>
        </div>

        {/* Summary cards */}
        <div className="grid grid-cols-4 gap-3 mb-4">
          {[
            { label:'Total Agents',    v:agents.length,  c:'var(--cyan)' },
            { label:'Active',          v:active,          c:'var(--green)' },
            { label:'Disconnected',    v:disconnected,    c:'#ef4444' },
            { label:'Pending',         v:pending,         c:'var(--amber)' },
          ].map(s=>(
            <div key={s.label} className="card px-4 py-3">
              <p className="label-caps text-dim" style={{fontSize:8}}>{s.label}</p>
              <p className="stat-value mt-1" style={{fontSize:24,color:s.c}}>{loading?'…':s.v}</p>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative">
            <svg className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-dim" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            <input value={search} onChange={e=>setSearch(e.target.value)} className="field pl-8 py-1.5"
              style={{fontSize:11,width:220}} placeholder="Search agents, IPs, OS…"/>
          </div>
          <div className="flex gap-1.5">
            {['all','active','disconnected','pending'].map(s=>(
              <button key={s} onClick={()=>setStatusFilter(s)}
                className="label-caps px-2.5 py-1.5 rounded-lg capitalize transition-colors"
                style={{fontSize:8, background:statusFilter===s?'rgba(0,216,232,0.1)':'transparent', border:`1px solid ${statusFilter===s?'var(--cyan)':'var(--border)'}`, color:statusFilter===s?'var(--cyan)':'var(--text-dim)'}}>
                {s}
              </button>
            ))}
          </div>
          {osPlatforms.length > 0 && (
            <select value={osFilter} onChange={e=>setOsFilter(e.target.value)} className="field py-1.5" style={{fontSize:11,width:140}}>
              <option value="all">All OS</option>
              {osPlatforms.map(p=><option key={p} value={p}>{p}</option>)}
            </select>
          )}
          <span className="mono text-dim ml-auto" style={{fontSize:10}}>{filtered.length} agents</span>
        </div>
      </div>

      {/* Table + Detail */}
      <div className="flex flex-1 overflow-hidden">
        <div className="flex-1 overflow-auto px-5 pb-5">
          {loading ? (
            <div className="flex items-center justify-center py-20">
              <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin"/>
            </div>
          ) : (
            <div className="card" style={{overflow:'visible'}}>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Agent Name</th><th>ID</th><th>IP</th><th>Status</th>
                    <th>OS</th><th>Platform</th><th>Group</th><th>Last Seen</th><th>Added</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((a:any,i:number)=>(
                    <tr key={i} onClick={()=>setSelected(a===selected?null:a)}
                      style={{background:selected===a?'rgba(0,216,232,0.06)':''}}>
                      <td className="font-semibold text-white" style={{fontSize:11}}>{a.name??'—'}</td>
                      <td className="mono text-dim" style={{fontSize:10}}>{a.id??'—'}</td>
                      <td className="mono text-secondary" style={{fontSize:10}}>{a.ip??'—'}</td>
                      <td>
                        <span className={`badge ${a.status==='active'?'badge-active':a.status==='disconnected'?'badge-critical':'badge-warning'}`} style={{fontSize:8}}>
                          {a.status??'unknown'}
                        </span>
                      </td>
                      <td className="text-secondary" style={{fontSize:11}}>{a.os?.name??'—'}</td>
                      <td className="mono text-dim" style={{fontSize:10}}>{a.os?.platform??'—'}</td>
                      <td className="mono text-dim" style={{fontSize:10}}>{Array.isArray(a.group)?a.group.join(', '):a.group??'—'}</td>
                      <td className="mono text-dim" style={{fontSize:10}}>
                        {a.lastKeepAlive?new Date(a.lastKeepAlive).toLocaleString():a.status==='disconnected'?'Offline':'—'}
                      </td>
                      <td className="mono text-dim" style={{fontSize:10}}>
                        {a.dateAdd?new Date(a.dateAdd).toLocaleDateString():'—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {filtered.length===0&&(
                <div className="py-12 text-center">
                  <p className="mono text-dim" style={{fontSize:11}}>No agents match current filters</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Agent detail panel */}
        {selected && (
          <div className="w-72 border-l overflow-y-auto shrink-0 p-4 space-y-3 animate-up"
            style={{borderColor:'var(--border)',background:'var(--bg-secondary)'}}>
            <div className="flex items-center justify-between">
              <p className="font-bold text-white" style={{fontSize:14}}>{selected.name}</p>
              <button onClick={()=>setSelected(null)} className="text-dim hover:text-white p-1">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/></svg>
              </button>
            </div>
            <span className={`badge ${selected.status==='active'?'badge-active':selected.status==='disconnected'?'badge-critical':'badge-warning'}`}>
              {selected.status}
            </span>
            {[
              {l:'Agent ID',    v:selected.id},
              {l:'IP Address',  v:selected.ip},
              {l:'Manager',     v:selected.manager},
              {l:'Node',        v:selected.node_name},
              {l:'OS',          v:selected.os?.name},
              {l:'Version',     v:selected.os?.version},
              {l:'Platform',    v:selected.os?.platform},
              {l:'Agent Ver',   v:selected.version},
              {l:'Group',       v:Array.isArray(selected.group)?selected.group.join(', '):selected.group},
              {l:'Last Seen',   v:selected.lastKeepAlive?new Date(selected.lastKeepAlive).toLocaleString():null},
              {l:'Enrolled',    v:selected.dateAdd?new Date(selected.dateAdd).toLocaleString():null},
            ].map(row=>(row.v?(
              <div key={row.l} className="flex justify-between gap-2">
                <span className="mono text-dim" style={{fontSize:9,minWidth:70}}>{row.l}</span>
                <span className="mono text-secondary text-right" style={{fontSize:10,wordBreak:'break-all'}}>{row.v}</span>
              </div>
            ):null))}
          </div>
        )}
      </div>
    </div>
  );
}
