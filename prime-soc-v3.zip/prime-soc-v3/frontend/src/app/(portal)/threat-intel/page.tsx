'use client';
import { useState, useEffect, useCallback } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis, PieChart, Pie, Cell } from 'recharts';

const THREAT_LEVEL: Record<number,{label:string;color:string;bg:string}> = {
  1: { label:'HIGH',     color:'#ef4444', bg:'rgba(239,68,68,0.15)' },
  2: { label:'MEDIUM',   color:'#f59e0b', bg:'rgba(245,158,11,0.15)' },
  3: { label:'LOW',      color:'#3b82f6', bg:'rgba(59,130,246,0.15)' },
  4: { label:'UNKNOWN',  color:'#64748b', bg:'rgba(100,116,139,0.1)' },
};

export default function ThreatIntelPage() {
  const [tab, setTab] = useState<'overview'|'actors'|'indicators'|'reports'>('overview');
  const [cti, setCTI]         = useState<any>(null);
  const [actors, setActors]   = useState<any[]>([]);
  const [indicators, setInd]  = useState<any[]>([]);
  const [mispFeed, setMISP]   = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [tickerIdx, setTickerIdx] = useState(0);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    try {
      const [ctiRes, mispRes] = await Promise.allSettled([
        fetch('/api/intel/cti').then(r=>r.json()),
        fetch('/api/intel/misp?limit=20').then(r=>r.json()),
      ]);
      if (ctiRes.status==='fulfilled') {
        setCTI(ctiRes.value);
        setActors(ctiRes.value.actors??[]);
        setInd(ctiRes.value.indicators??[]);
      }
      if (mispRes.status==='fulfilled') setMISP(mispRes.value.events??[]);
    } finally { setLoading(false); }
  }, []);

  useEffect(()=>{ fetchAll(); },[fetchAll]);
  useEffect(()=>{ const id=setInterval(fetchAll, 60_000); return ()=>clearInterval(id); },[fetchAll]);

  // Ticker animation for live CTI feed
  useEffect(()=>{
    if (mispFeed.length===0) return;
    const id = setInterval(()=>setTickerIdx(i=>(i+1)%mispFeed.length), 5000);
    return ()=>clearInterval(id);
  },[mispFeed]);

  const stats = cti?.stats;

  // Radar data for threat distribution
  const radarData = [
    { subject:'Malware',    A: stats?.malwares??0, fullMark:200 },
    { subject:'Threat Actors', A: stats?.threat_actors??0, fullMark:200 },
    { subject:'Indicators', A: Math.min(stats?.indicators??0,200), fullMark:200 },
    { subject:'Reports',    A: stats?.reports??0, fullMark:200 },
    { subject:'TTPs',       A: stats?.attack_patterns??0, fullMark:200 },
    { subject:'Objects',    A: Math.min((stats?.total_objects??0)/100,200), fullMark:200 },
  ];

  // IOC type breakdown from MISP
  const iocTypes: Record<string,number> = {};
  mispFeed.forEach(e=>{ const t=e.threat_level; iocTypes[t]=((iocTypes[t]??0)+1); });
  const iocData = Object.entries(iocTypes).map(([k,v])=>({
    name: THREAT_LEVEL[parseInt(k)]?.label ?? 'UNKNOWN',
    value:v,
    color: THREAT_LEVEL[parseInt(k)]?.color ?? '#64748b',
  }));

  const formatNum = (n: number) => n >= 1_000 ? `${(n/1_000).toFixed(1)}K` : String(n);

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 pt-4 pb-4 shrink-0 border-b" style={{borderColor:'var(--border)'}}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="font-black text-white" style={{fontSize:20,letterSpacing:'-0.02em'}}>Threat Intelligence</h1>
            <p className="mono text-secondary mt-0.5" style={{fontSize:11}}>OpenCTI + MISP · Live threat feed · Real-time IOC tracking</p>
          </div>
          <div className="flex gap-2">
            {(['overview','actors','indicators','reports'] as const).map(t=>(
              <button key={t} onClick={()=>setTab(t)}
                className="label-caps px-3 py-1.5 rounded-lg capitalize transition-colors"
                style={{fontSize:9, background:tab===t?'rgba(0,216,232,0.12)':'transparent', border:`1px solid ${tab===t?'rgba(0,216,232,0.4)':'var(--border)'}`, color:tab===t?'var(--cyan)':'var(--text-dim)'}}>
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* KPI cards */}
        <div className="grid grid-cols-6 gap-3">
          {[
            { label:'Total Objects',   value:formatNum(stats?.total_objects??0),  color:'var(--cyan)' },
            { label:'Indicators/IOCs', value:formatNum(stats?.indicators??0),     color:'#ef4444' },
            { label:'Threat Actors',   value:formatNum(stats?.threat_actors??0),  color:'#f59e0b' },
            { label:'Malware',         value:formatNum(stats?.malwares??0),       color:'#a78bfa' },
            { label:'Reports',         value:formatNum(stats?.reports??0),        color:'var(--green)' },
            { label:'MISP Events',     value:String(mispFeed.length),            color:'var(--cyan)' },
          ].map(s=>(
            <div key={s.label} className="card px-3 py-2 text-center">
              <p className="label-caps text-dim" style={{fontSize:8}}>{s.label}</p>
              <p className="stat-value mt-1" style={{fontSize:18,color:s.color}}>{loading?'…':s.value}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-auto p-5 space-y-4">

        {/* OVERVIEW */}
        {tab==='overview' && (
          <>
            {/* Live CTI Ticker */}
            {mispFeed.length > 0 && (
              <div className="rounded-xl px-4 py-3 flex items-center gap-3"
                style={{background:'rgba(239,68,68,0.06)',border:'1px solid rgba(239,68,68,0.2)'}}>
                <span className="label-caps shrink-0" style={{fontSize:8,color:'#ef4444',background:'rgba(239,68,68,0.2)',padding:'2px 6px',borderRadius:4}}>LIVE THREAT</span>
                <div className="flex-1 overflow-hidden">
                  <p className="text-white truncate" style={{fontSize:12}}>
                    {mispFeed[tickerIdx%mispFeed.length]?.info ?? 'Loading threat feed…'}
                  </p>
                  <p className="mono text-dim" style={{fontSize:9}}>
                    {mispFeed[tickerIdx%mispFeed.length]?.org ?? '—'} · {mispFeed[tickerIdx%mispFeed.length]?.date ?? ''}
                  </p>
                </div>
                <span className="mono shrink-0" style={{fontSize:9,color:'#ef4444'}}>⬤ {mispFeed.length} events</span>
              </div>
            )}

            <div className="grid grid-cols-3 gap-4">
              {/* Threat Radar */}
              <div className="card p-4">
                <p className="label-caps text-secondary mb-3" style={{fontSize:9}}>Threat Intelligence Radar</p>
                <div style={{height:200}}>
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart data={radarData}>
                      <PolarGrid stroke="rgba(255,255,255,0.08)"/>
                      <PolarAngleAxis dataKey="subject" tick={{fontSize:9,fill:'var(--text-secondary)'}}/>
                      <Radar name="Coverage" dataKey="A" stroke="var(--cyan)" fill="var(--cyan)" fillOpacity={0.2} strokeWidth={1.5}/>
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* MISP Event Severity */}
              <div className="card p-4">
                <p className="label-caps text-secondary mb-3" style={{fontSize:9}}>MISP Event Threat Level</p>
                {iocData.length>0?(
                  <>
                    <div style={{height:130}}>
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie data={iocData} cx="50%" cy="50%" innerRadius={35} outerRadius={55} dataKey="value" stroke="none">
                            {iocData.map((d,i)=><Cell key={i} fill={d.color}/>)}
                          </Pie>
                          <Tooltip/>
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="space-y-1 mt-2">
                      {iocData.map(d=>(
                        <div key={d.name} className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <div className="w-2 h-2 rounded-sm" style={{background:d.color}}/>
                            <span className="mono text-secondary" style={{fontSize:10}}>{d.name}</span>
                          </div>
                          <span className="mono font-bold" style={{fontSize:10,color:d.color}}>{d.value}</span>
                        </div>
                      ))}
                    </div>
                  </>
                ):<p className="mono text-dim text-center py-8" style={{fontSize:11}}>Loading MISP data…</p>}
              </div>

              {/* Top Threat Actors */}
              <div className="card p-4">
                <p className="label-caps text-secondary mb-3" style={{fontSize:9}}>Active Threat Actors</p>
                {actors.slice(0,6).length>0?(
                  <div className="space-y-2">
                    {actors.slice(0,6).map((a:any)=>(
                      <div key={a.id} className="card-hover p-2.5 rounded-lg">
                        <p className="font-semibold text-white" style={{fontSize:12}}>{a.name}</p>
                        {a.threat_actor_types?.length>0&&(
                          <div className="flex gap-1 flex-wrap mt-1">
                            {a.threat_actor_types.slice(0,2).map((t:string,i:number)=>(
                              <span key={i} className="badge badge-warning" style={{fontSize:7}}>{t}</span>
                            ))}
                          </div>
                        )}
                        {a.description&&<p className="mono text-secondary mt-1" style={{fontSize:9,lineHeight:1.4,display:'-webkit-box',WebkitLineClamp:2,WebkitBoxOrient:'vertical',overflow:'hidden'}}>{a.description}</p>}
                      </div>
                    ))}
                  </div>
                ):<p className="mono text-dim text-center py-8" style={{fontSize:11}}>No threat actors in OpenCTI</p>}
              </div>
            </div>

            {/* CYREBRO-style CTI News Feed */}
            <div className="grid grid-cols-3 gap-4">
              <div className="col-span-2 card flex flex-col" style={{maxHeight:320}}>
                <div className="px-4 py-3 border-b shrink-0 flex items-center justify-between" style={{borderColor:'var(--border)'}}>
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-400 dot-live"/>
                    <p className="label-caps text-secondary" style={{fontSize:9}}>Live CTI News Feed — MISP Threat Events</p>
                  </div>
                  <span className="badge badge-critical">{mispFeed.length} EVENTS</span>
                </div>
                <div className="overflow-y-auto flex-1">
                  {mispFeed.length>0 ? mispFeed.map((e:any,i:number)=>{
                    const lvl = THREAT_LEVEL[e.threat_level]??THREAT_LEVEL[4];
                    return (
                      <div key={i} className="cti-feed-item">
                        <div className="flex items-start gap-3">
                          <div className="px-2 py-0.5 rounded shrink-0 mt-0.5" style={{background:lvl.bg,border:`1px solid ${lvl.color}30`}}>
                            <span className="mono font-bold" style={{fontSize:8,color:lvl.color}}>{lvl.label}</span>
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold text-white leading-snug" style={{fontSize:12}}>
                              {e.info}
                            </p>
                            <div className="flex items-center gap-3 mt-1">
                              <span className="mono text-dim" style={{fontSize:9}}>📍 {e.org}</span>
                              <span className="mono text-dim" style={{fontSize:9}}>📅 {e.date}</span>
                              <span className="mono text-dim" style={{fontSize:9}}>🔍 {e.attribute_count} IOCs</span>
                            </div>
                            {e.tags?.length>0&&(
                              <div className="flex gap-1 flex-wrap mt-1">
                                {e.tags.slice(0,4).map((t:string,i:number)=>(
                                  <span key={i} className="badge badge-info" style={{fontSize:7}}>{t}</span>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  }) : (
                    <div className="flex items-center justify-center h-full">
                      <p className="mono text-dim" style={{fontSize:11}}>Connecting to MISP threat feed…</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Top IOC tags */}
              <div className="card p-4">
                <p className="label-caps text-secondary mb-3" style={{fontSize:9}}>IOC Sources & Tags</p>
                {mispFeed.length>0?(
                  <div className="space-y-2">
                    {(() => {
                      const orgs: Record<string,number> = {};
                      mispFeed.forEach(e=>{ orgs[e.org]=(orgs[e.org]??0)+1; });
                      const sorted = Object.entries(orgs).sort((a,b)=>b[1]-a[1]).slice(0,8);
                      const max = sorted[0]?.[1]??1;
                      return sorted.map(([org,cnt])=>(
                        <div key={org}>
                          <div className="flex justify-between mb-0.5">
                            <span className="text-secondary truncate" style={{fontSize:10,maxWidth:140}} title={org}>{org}</span>
                            <span className="mono font-bold text-white" style={{fontSize:10}}>{cnt}</span>
                          </div>
                          <div className="rounded-full overflow-hidden" style={{height:3,background:'rgba(255,255,255,0.05)'}}>
                            <div style={{width:`${(cnt/max)*100}%`,height:'100%',background:'var(--cyan)',borderRadius:3}}/>
                          </div>
                        </div>
                      ));
                    })()}
                  </div>
                ):<p className="mono text-dim text-center py-8" style={{fontSize:11}}>Loading…</p>}
              </div>
            </div>
          </>
        )}

        {/* ACTORS */}
        {tab==='actors' && (
          <div className="grid grid-cols-3 gap-4">
            {actors.map((a:any)=>(
              <div key={a.id} className="card-hover p-4 rounded-xl">
                <div className="flex items-start justify-between mb-2">
                  <p className="font-bold text-white" style={{fontSize:14}}>{a.name}</p>
                  {a.sophistication&&<span className="badge badge-warning" style={{fontSize:8}}>{a.sophistication}</span>}
                </div>
                {a.threat_actor_types?.length>0&&(
                  <div className="flex gap-1 flex-wrap mb-2">
                    {a.threat_actor_types.map((t:string,i:number)=><span key={i} className="badge badge-critical" style={{fontSize:7}}>{t}</span>)}
                  </div>
                )}
                {a.description&&<p className="mono text-secondary" style={{fontSize:10,lineHeight:1.4}}>{a.description?.slice(0,120)}…</p>}
                <div className="flex gap-3 mt-2">
                  {a.first_seen&&<p className="mono text-dim" style={{fontSize:9}}>First: {a.first_seen.split('T')[0]}</p>}
                  {a.confidence&&<p className="mono text-dim" style={{fontSize:9}}>Confidence: {a.confidence}%</p>}
                </div>
              </div>
            ))}
            {actors.length===0&&<div className="col-span-3 py-16 text-center"><p className="mono text-dim" style={{fontSize:12}}>No threat actors in OpenCTI</p></div>}
          </div>
        )}

        {/* INDICATORS */}
        {tab==='indicators' && (
          <div className="card" style={{overflow:'auto',maxHeight:'calc(100vh - 250px)'}}>
            <table className="data-table">
              <thead><tr><th>Name</th><th>Pattern Type</th><th>Score</th><th>Valid From</th></tr></thead>
              <tbody>
                {indicators.map((ind:any,i:number)=>(
                  <tr key={ind.id??i}>
                    <td className="mono text-secondary" style={{fontSize:10,maxWidth:300}}><span className="truncate block">{ind.name}</span></td>
                    <td><span className="badge badge-info" style={{fontSize:8}}>{ind.pattern_type}</span></td>
                    <td>
                      <span className="mono font-bold" style={{fontSize:11,color:ind.x_opencti_score>=80?'var(--red)':ind.x_opencti_score>=50?'var(--amber)':'var(--green)'}}>
                        {ind.x_opencti_score??'—'}
                      </span>
                    </td>
                    <td className="mono text-dim" style={{fontSize:10}}>{ind.valid_from?.split('T')[0]??'—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {indicators.length===0&&<div className="py-12 text-center"><p className="mono text-dim" style={{fontSize:11}}>No indicators in OpenCTI</p></div>}
          </div>
        )}

        {/* REPORTS */}
        {tab==='reports' && (
          <div className="py-12 text-center">
            <p className="mono text-secondary" style={{fontSize:13}}>Reports available in OpenCTI</p>
            <p className="mono text-dim mt-2" style={{fontSize:11}}>Connect directly to OpenCTI for full report management.</p>
          </div>
        )}
      </div>
    </div>
  );
}
