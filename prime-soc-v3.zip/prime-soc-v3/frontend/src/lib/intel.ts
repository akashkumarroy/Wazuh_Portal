// MISP client
async function mispFetch<T>(path: string, body?: Record<string, unknown>): Promise<T> {
  const url  = process.env.MISP_URL ?? '';
  const key  = process.env.MISP_API_KEY ?? '';
  const res = await fetch(`${url}${path}`, {
    method: body ? 'POST' : 'GET',
    headers: {
      Authorization: key,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  if (!res.ok) throw new Error(`MISP ${res.status}`);
  return res.json() as Promise<T>;
}

export async function getMISPEvents(limit = 20) {
  try {
    const data = await mispFetch<{ response?: any[] }>('/events/restSearch', {
      limit, page: 1, published: 1, returnFormat: 'json',
    });
    return (data.response ?? []).map((e: any) => {
      const ev = e.Event ?? e;
      return {
        id:           ev.id,
        info:         ev.info,
        threat_level: parseInt(ev.threat_level_id ?? '4', 10),
        date:         ev.date,
        timestamp:    ev.timestamp,
        org:          ev.Orgc?.name ?? ev.Org?.name ?? 'Unknown',
        tags:         (ev.Tag ?? []).slice(0, 5).map((t: any) => t.name),
        attribute_count: parseInt(ev.attribute_count ?? '0', 10),
        uuid:         ev.uuid,
      };
    });
  } catch { return []; }
}

export async function getMISPStats() {
  try {
    const data = await mispFetch<{ response?: any[] }>('/events/restSearch', {
      limit: 1, page: 1, returnFormat: 'json',
    });
    return { total_events: (data.response ?? []).length };
  } catch { return { total_events: 0 }; }
}

// ── OpenCTI GraphQL client ─────────────────────────────────────
async function ctiGQL<T>(gqlQuery: string): Promise<T> {
  const res = await fetch(`${process.env.OPENCTI_URL ?? ''}/graphql`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.OPENCTI_API_KEY ?? ''}`,
    },
    body: JSON.stringify({ query: gqlQuery }),
  });
  if (!res.ok) throw new Error(`OpenCTI ${res.status}`);
  const json = await res.json() as { data?: T; errors?: unknown[] };
  if (json.errors?.length) throw new Error(JSON.stringify(json.errors[0]));
  return json.data as T;
}

export async function getCTIThreatActors(limit = 15) {
  try {
    const d = await ctiGQL<any>(`{
      threatActors(first:${limit}, orderBy:modified, orderMode:desc) {
        edges { node { id name description threat_actor_types sophistication first_seen last_seen confidence } }
      }
    }`);
    return d?.threatActors?.edges?.map((e: any) => e.node) ?? [];
  } catch { return []; }
}

export async function getCTIIndicators(limit = 30) {
  try {
    const d = await ctiGQL<any>(`{
      indicators(first:${limit}, orderBy:modified, orderMode:desc) {
        edges { node { id name pattern pattern_type valid_from confidence x_opencti_score } }
      }
    }`);
    return d?.indicators?.edges?.map((e: any) => e.node) ?? [];
  } catch { return []; }
}

export async function getCTIStats() {
  try {
    const d = await ctiGQL<any>(`{
      stixDomainObjects { totalCount }
      indicators { totalCount }
      reports { totalCount }
      threatActors { totalCount }
      malwares { totalCount }
      attackPatterns { totalCount }
    }`);
    return {
      total_objects:   d?.stixDomainObjects?.totalCount ?? 0,
      indicators:      d?.indicators?.totalCount ?? 0,
      reports:         d?.reports?.totalCount ?? 0,
      threat_actors:   d?.threatActors?.totalCount ?? 0,
      malwares:        d?.malwares?.totalCount ?? 0,
      attack_patterns: d?.attackPatterns?.totalCount ?? 0,
    };
  } catch { return { total_objects:0, indicators:0, reports:0, threat_actors:0, malwares:0, attack_patterns:0 }; }
}

export async function getCTIReports(limit = 10) {
  try {
    const d = await ctiGQL<any>(`{
      reports(first:${limit}, orderBy:published, orderMode:desc) {
        edges { node { id name description published confidence report_types } }
      }
    }`);
    return d?.reports?.edges?.map((e: any) => e.node) ?? [];
  } catch { return []; }
}
