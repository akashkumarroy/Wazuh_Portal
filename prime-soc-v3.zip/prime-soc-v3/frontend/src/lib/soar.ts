// IRIS Case Management client
async function irisFetch<T>(path: string, method = 'GET', body?: Record<string, unknown>): Promise<T> {
  const url = process.env.IRIS_URL ?? '';
  const key = process.env.IRIS_API_KEY ?? '';
  const res = await fetch(`${url}${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${key}`,
      'Content-Type': 'application/json',
    },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  if (!res.ok) throw new Error(`IRIS ${res.status} on ${path}`);
  return res.json() as Promise<T>;
}

export async function getIRISCases() {
  try {
    const data = await irisFetch<any>('/manage/cases/list');
    return data?.data?.cases ?? [];
  } catch { return []; }
}

export async function getIRISAlerts() {
  try {
    const data = await irisFetch<any>('/manage/alerts/filter?page=1&per_page=20&sort=alert_source_event_time&sort_dir=desc');
    return data?.data?.alerts ?? [];
  } catch { return []; }
}

export async function getIRISDashboard() {
  try {
    return await irisFetch<any>('/api/v1/dashboard/main_graphs');
  } catch { return null; }
}

export async function getIRISStats() {
  try {
    const cases = await getIRISCases();
    return {
      total:       cases.length,
      open:        cases.filter((c: any) => c.state_name !== 'Closed').length,
      in_progress: cases.filter((c: any) => c.state_name === 'In Progress').length,
      closed:      cases.filter((c: any) => c.state_name === 'Closed').length,
      critical:    cases.filter((c: any) => c.severity_id === 1).length,
      high:        cases.filter((c: any) => c.severity_id === 2).length,
    };
  } catch { return { total: 0, open: 0, in_progress: 0, closed: 0, critical: 0, high: 0 }; }
}

// ── Shuffle SOAR client ────────────────────────────────────────
async function shuffleFetch<T>(path: string): Promise<T> {
  const url = process.env.SHUFFLE_URL ?? 'https://shuffler.io';
  const key = process.env.SHUFFLE_API_KEY ?? '';
  const res = await fetch(`${url}${path}`, {
    headers: { Authorization: `Bearer ${key}` },
  });
  if (!res.ok) throw new Error(`Shuffle ${res.status}`);
  return res.json() as Promise<T>;
}

export async function getShuffleWorkflows() {
  try {
    const data = await shuffleFetch<any[]>('/api/v1/workflows');
    return Array.isArray(data) ? data : [];
  } catch { return []; }
}

export async function getShuffleStats() {
  try {
    const workflows = await getShuffleWorkflows();
    return {
      total:        workflows.length,
      active:       workflows.filter((w: any) => w.status === 'running' || w.is_running).length,
      success:      workflows.filter((w: any) => w.status === 'finished').length,
      failed:       workflows.filter((w: any) => w.status === 'failed').length,
      last_run:     workflows[0]?.edited ?? null,
    };
  } catch { return { total: 0, active: 0, success: 0, failed: 0, last_run: null }; }
}
