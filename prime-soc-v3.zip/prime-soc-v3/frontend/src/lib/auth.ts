import { SignJWT, jwtVerify, type JWTPayload } from 'jose';

export const COOKIE_NAME = 'primesoc_session';

const secret = () => {
  const s = process.env.JWT_SECRET;
  if (!s) throw new Error('JWT_SECRET not set');
  return new TextEncoder().encode(s);
};

export interface SessionPayload extends JWTPayload {
  sub: string;         // username
  role: 'admin' | 'client';
  group?: string;      // wazuh group = username for clients
  is_admin: boolean;
}

// ── Wazuh Indexer pass-through auth ───────────────────────────
export async function authenticateViaIndexer(
  username: string,
  password: string,
): Promise<{ valid: boolean; is_admin: boolean; group: string | null; roles: string[] }> {
  const indexerUrl = process.env.WAZUH_INDEXER_URL!;
  const creds = Buffer.from(`${username}:${password}`).toString('base64');

  try {
    const res = await fetch(`${indexerUrl}/_plugins/_security/api/account`, {
      headers: {
        Authorization: `Basic ${creds}`,
        'Content-Type': 'application/json',
      },
    });

    if (!res.ok) return { valid: false, is_admin: false, group: null, roles: [] };

    const data = await res.json() as {
      user_name?: string;
      backend_roles?: string[];
      roles?: string[];
      tenants?: Record<string, boolean>;
    };

    // Admin if backend_roles is non-empty (admin, ro-soc, sales, administrator, wazuh-wui)
    const backendRoles = data.backend_roles ?? [];
    const is_admin = backendRoles.length > 0 && backendRoles.some(r => r !== '');

    // For clients: group = username (DLS is keyed on username)
    const group = is_admin ? null : username;

    return {
      valid: true,
      is_admin,
      group,
      roles: [...backendRoles, ...(data.roles ?? [])],
    };
  } catch {
    return { valid: false, is_admin: false, group: null, roles: [] };
  }
}

// ── JWT operations ─────────────────────────────────────────────
export async function createToken(payload: Omit<SessionPayload, 'iat' | 'exp'>): Promise<string> {
  const expiry = process.env.JWT_EXPIRY ?? '8h';
  return new SignJWT(payload as JWTPayload)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(expiry)
    .sign(secret());
}

export async function verifyToken(token: string): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, secret());
    return payload as SessionPayload;
  } catch {
    return null;
  }
}

export const COOKIE_OPTIONS = {
  httpOnly: true,
  secure: process.env.COOKIE_SECURE === 'true',
  sameSite: 'lax' as const,
  path: '/',
  maxAge: 60 * 60 * 8, // 8 hours
};
