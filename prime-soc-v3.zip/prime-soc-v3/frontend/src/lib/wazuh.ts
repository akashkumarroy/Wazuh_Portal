// Wazuh Indexer (OpenSearch) client
// All field names confirmed from live API tests

const INDEXER_URL = () => {
  const u = process.env.WAZUH_INDEXER_URL;
  if (!u) throw new Error('WAZUH_INDEXER_URL not set');
  return u;
};

const ADMIN_CREDS = () =>
  Buffer.from(
    `${process.env.WAZUH_INDEXER_USER ?? 'admin'}:${process.env.WAZUH_INDEXER_PASS ?? ''}`,
  ).toString('base64');

// Shared fetch helper with admin credentials
export async function indexerFetch<T>(
  path: string,
  body?: Record<string, unknown>,
): Promise<T> {
  const res = await fetch(`${INDEXER_URL()}${path}`, {
    method: body ? 'POST' : 'GET',
    headers: {
      Authorization: `Basic ${ADMIN_CREDS()}`,
      'Content-Type': 'application/json',
    },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  if (!res.ok) throw new Error(`Indexer ${res.status} on ${path}`);
  return res.json() as Promise<T>;
}

// Build tenant filter for client users
export function tenantFilter(group: string | null | undefined) {
  if (!group) return null; // admin — no filter
  return { match: { 'agent.labels.group': group } };
}

// ── Alert severity helpers ─────────────────────────────────────
export function severityFromLevel(level: number): 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO' {
  if (level >= 13) return 'CRITICAL';
  if (level >= 10) return 'HIGH';
  if (level >= 7)  return 'MEDIUM';
  if (level >= 4)  return 'LOW';
  return 'INFO';
}

// ── Dashboard overview ─────────────────────────────────────────
export async function getDashboardStats(group?: string | null) {
  const filter = tenantFilter(group);
  const must = filter ? [filter] : [];

  const body = {
    size: 0,
    query: must.length ? { bool: { must } } : { match_all: {} },
    aggs: {
      total: { value_count: { field: '_id' } },
      critical: { filter: { range: { 'rule.level': { gte: 13 } } } },
      high:     { filter: { range: { 'rule.level': { gte: 10, lt: 13 } } } },
      medium:   { filter: { range: { 'rule.level': { gte: 7, lt: 10 } } } },
      by_level: { terms: { field: 'rule.level', size: 15 } },
      alerts_over_time: {
        date_histogram: { field: 'timestamp', calendar_interval: 'hour', min_doc_count: 1 },
      },
      top_agents: { terms: { field: 'agent.name', size: 10 } },
      top_rules:  { terms: { field: 'rule.description.keyword', size: 10 } },
      geo_countries: { terms: { field: 'GeoLocation.country_name.keyword', size: 20 } },
      mitre_techniques: { terms: { field: 'rule.mitre.id', size: 30 } },
      mitre_tactics:    { terms: { field: 'rule.mitre.tactic', size: 15 } },
    },
  };

  const data = await indexerFetch<any>('/wazuh-alerts-4.x-*/_search', body);
  return data;
}

// ── Recent alerts ──────────────────────────────────────────────
export async function getAlerts(
  group?: string | null,
  size = 100,
  from = 0,
  extraFilters: Record<string, unknown>[] = [],
) {
  const filter = tenantFilter(group);
  const must = [...(filter ? [filter] : []), ...extraFilters];

  const data = await indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
    size,
    from,
    sort: [{ timestamp: { order: 'desc' } }],
    query: must.length ? { bool: { must } } : { match_all: {} },
    _source: [
      'timestamp', '@timestamp', 'agent.name', 'agent.id', 'agent.ip',
      'agent.labels.group', 'rule.id', 'rule.level', 'rule.description',
      'rule.groups', 'rule.pci_dss', 'rule.gdpr', 'rule.hipaa',
      'rule.nist_800_53', 'rule.tsc', 'rule.gpg13', 'rule.mitre',
      'data.srcip', 'data.dstip', 'full_log', 'location',
      'GeoLocation', 'manager.name', 'decoder.name', 'predecoder',
    ],
  });

  return (data.hits?.hits ?? []).map((h: any) => ({
    id:         h._id,
    index:      h._index,
    ...h._source,
    severity:   severityFromLevel(h._source?.rule?.level ?? 0),
  }));
}

// ── Alert by ID (for drill-down/triage) ───────────────────────
export async function getAlertById(id: string) {
  const data = await indexerFetch<any>(`/wazuh-alerts-4.x-*/_doc/${id}`);
  if (!data?._source) {
    // Try search by _id
    const search = await indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
      size: 1,
      query: { ids: { values: [id] } },
    });
    const hit = search?.hits?.hits?.[0];
    if (!hit) return null;
    return { id: hit._id, index: hit._index, ...hit._source, severity: severityFromLevel(hit._source?.rule?.level ?? 0) };
  }
  return { id: data._id, index: data._index, ...data._source, severity: severityFromLevel(data._source?.rule?.level ?? 0) };
}

// ── Agents (from monitoring index) ────────────────────────────
export async function getAgents(group?: string | null, size = 1000) {
  const filter = group ? [{ term: { 'group': group } }] : [];
  const data = await indexerFetch<any>('/wazuh-monitoring-*/_search', {
    size,
    sort: [{ lastKeepAlive: { order: 'desc' } }],
    query: filter.length ? { bool: { must: filter } } : { match_all: {} },
    _source: ['name', 'id', 'ip', 'status', 'group', 'os.name', 'os.platform', 'os.version', 'lastKeepAlive', 'dateAdd', 'manager', 'node_name', 'version'],
    collapse: { field: 'id' }, // latest record per agent
  });

  const agents = data.hits?.hits?.map((h: any) => h._source) ?? [];
  const total  = data.hits?.total?.value ?? 0;
  return { agents, total };
}

// ── Agent status summary ───────────────────────────────────────
export async function getAgentStatusSummary(group?: string | null) {
  const filter = group ? [{ term: { 'group': group } }] : [];
  const data = await indexerFetch<any>('/wazuh-monitoring-*/_search', {
    size: 0,
    query: filter.length ? { bool: { must: filter } } : { match_all: {} },
    aggs: {
      by_group: { terms: { field: 'group', size: 50 } },
      by_status: { terms: { field: 'status', size: 5 } },
      by_os: { terms: { field: 'os.platform', size: 10 } },
      unique_agents: { cardinality: { field: 'id' } },
    },
  });
  return data;
}

// ── Tenant overview (for admin tenant-click) ───────────────────
export async function getTenantOverview(tenantGroup: string) {
  const [alertData, agentData] = await Promise.all([
    indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
      size: 0,
      query: { match: { 'agent.labels.group': tenantGroup } },
      aggs: {
        total:    { value_count: { field: '_id' } },
        critical: { filter: { range: { 'rule.level': { gte: 13 } } } },
        high:     { filter: { range: { 'rule.level': { gte: 10, lt: 13 } } } },
        medium:   { filter: { range: { 'rule.level': { gte: 7, lt: 10 } } } },
        alerts_over_time: {
          date_histogram: {
            field: 'timestamp',
            calendar_interval: 'day',
            min_doc_count: 1,
          },
        },
        top_agents: { terms: { field: 'agent.name', size: 10 } },
        top_rules:  { terms: { field: 'rule.description.keyword', size: 10 } },
      },
    }),
    indexerFetch<any>('/wazuh-monitoring-*/_search', {
      size: 0,
      query: { term: { 'group': tenantGroup } },
      aggs: {
        by_status: { terms: { field: 'status', size: 5 } },
        by_os:     { terms: { field: 'os.platform', size: 10 } },
        agent_count: { cardinality: { field: 'id' } },
      },
    }),
  ]);

  return { alerts: alertData, agents: agentData };
}

// ── All tenants summary ────────────────────────────────────────
export async function getAllTenantsSummary() {
  const data = await indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
    size: 0,
    aggs: {
      by_tenant: {
        terms: { field: 'agent.labels.group', size: 50 },
        aggs: {
          critical: { filter: { range: { 'rule.level': { gte: 13 } } } },
          high:     { filter: { range: { 'rule.level': { gte: 10, lt: 13 } } } },
          medium:   { filter: { range: { 'rule.level': { gte: 7, lt: 10 } } } },
          last_alert: { max: { field: 'timestamp' } },
        },
      },
    },
  });
  return data?.aggregations?.by_tenant?.buckets ?? [];
}

// ── MITRE ATT&CK ───────────────────────────────────────────────
export async function getMitreSummary(group?: string | null) {
  const filter = tenantFilter(group);
  const must   = filter ? [filter] : [];
  const data = await indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
    size: 0,
    query: must.length ? { bool: { must } } : { match_all: {} },
    aggs: {
      techniques: { terms: { field: 'rule.mitre.id', size: 50 } },
      tactics:    { terms: { field: 'rule.mitre.tactic', size: 20 } },
      top_with_level: {
        terms: { field: 'rule.mitre.id', size: 50 },
        aggs: { max_level: { max: { field: 'rule.level' } } },
      },
    },
  });
  return data;
}

// ── Compliance ─────────────────────────────────────────────────
export async function getComplianceSummary(group?: string | null) {
  const filter = tenantFilter(group);
  const must   = filter ? [filter] : [];
  const data = await indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
    size: 0,
    query: must.length ? { bool: { must } } : { match_all: {} },
    aggs: {
      pci_dss:      { filter: { exists: { field: 'rule.pci_dss' } },
                      aggs: { requirements: { terms: { field: 'rule.pci_dss', size: 50 } } } },
      gdpr:         { filter: { exists: { field: 'rule.gdpr' } },
                      aggs: { requirements: { terms: { field: 'rule.gdpr', size: 50 } } } },
      hipaa:        { filter: { exists: { field: 'rule.hipaa' } },
                      aggs: { requirements: { terms: { field: 'rule.hipaa', size: 50 } } } },
      nist_800_53:  { filter: { exists: { field: 'rule.nist_800_53' } },
                      aggs: { requirements: { terms: { field: 'rule.nist_800_53', size: 50 } } } },
      tsc:          { filter: { exists: { field: 'rule.tsc' } },
                      aggs: { requirements: { terms: { field: 'rule.tsc', size: 50 } } } },
      gpg13:        { filter: { exists: { field: 'rule.gpg13' } },
                      aggs: { requirements: { terms: { field: 'rule.gpg13', size: 50 } } } },
    },
  });
  return data;
}

// ── Compliance alerts with detail ─────────────────────────────
export async function getComplianceAlerts(
  framework: 'pci_dss' | 'gdpr' | 'hipaa' | 'nist_800_53' | 'tsc' | 'gpg13',
  group?: string | null,
  size = 100,
) {
  const filter = tenantFilter(group);
  const must = [
    { exists: { field: `rule.${framework}` } },
    ...(filter ? [filter] : []),
  ];
  const data = await indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
    size,
    sort: [{ timestamp: { order: 'desc' } }],
    query: { bool: { must } },
    _source: [`rule.${framework}`, 'rule.description', 'rule.level', 'agent.name', 'agent.labels.group', 'timestamp'],
  });
  return (data.hits?.hits ?? []).map((h: any) => ({ id: h._id, ...h._source, severity: severityFromLevel(h._source?.rule?.level ?? 0) }));
}

// ── FIM events ─────────────────────────────────────────────────
export async function getFIMEvents(group?: string | null, size = 200) {
  const filter = tenantFilter(group);
  const must = [
    { term: { 'rule.groups': 'syscheck' } },
    ...(filter ? [filter] : []),
  ];
  const data = await indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
    size,
    sort: [{ timestamp: { order: 'desc' } }],
    query: { bool: { must } },
    _source: [
      'agent.name', 'agent.labels.group', 'syscheck.path', 'syscheck.event',
      'syscheck.md5_after', 'syscheck.sha256_after', 'syscheck.size_after',
      'rule.description', 'rule.level', 'timestamp',
    ],
  });
  return (data.hits?.hits ?? []).map((h: any) => ({ id: h._id, ...h._source }));
}

// ── SCA events ─────────────────────────────────────────────────
export async function getSCAEvents(group?: string | null, size = 200) {
  const filter = tenantFilter(group);
  const must = [
    { term: { 'rule.groups': 'sca' } },
    ...(filter ? [filter] : []),
  ];
  const data = await indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
    size,
    sort: [{ timestamp: { order: 'desc' } }],
    query: { bool: { must } },
    _source: [
      'agent.name', 'agent.labels.group', 'data.sca.check.title',
      'data.sca.check.result', 'data.sca.policy', 'data.sca.score',
      'rule.description', 'rule.level', 'timestamp',
    ],
    aggs: {
      by_policy:  { terms: { field: 'data.sca.policy.keyword', size: 20 } },
      by_result:  { terms: { field: 'data.sca.check.result.keyword', size: 5 } },
      by_agent:   {
        terms: { field: 'agent.name', size: 20 },
        aggs: { latest_score: { max: { field: 'data.sca.score' } } },
      },
    },
  });
  return data;
}

// ── Vulnerability ──────────────────────────────────────────────
export async function getVulnerabilities(group?: string | null) {
  const filter = tenantFilter(group);
  const must = filter ? [filter] : [];
  // Try the new states index first, fall back to alerts
  try {
    const data = await indexerFetch<any>('/wazuh-states-vulnerabilities-*/_search', {
      size: 0,
      query: must.length ? { bool: { must } } : { match_all: {} },
      aggs: {
        by_severity: { terms: { field: 'vulnerability.severity', size: 5 } },
        by_agent:    { terms: { field: 'agent.name', size: 20 } },
        critical:    { filter: { term: { 'vulnerability.severity': 'Critical' } } },
        high:        { filter: { term: { 'vulnerability.severity': 'High' } } },
        medium:      { filter: { term: { 'vulnerability.severity': 'Medium' } } },
        low:         { filter: { term: { 'vulnerability.severity': 'Low' } } },
      },
    });
    if (data.hits?.total?.value > 0) return data;
  } catch { /* fallthrough */ }
  return null;
}

// ── Geo attack data ────────────────────────────────────────────
export async function getGeoData(group?: string | null) {
  const filter = tenantFilter(group);
  const must = [
    { exists: { field: 'GeoLocation.location' } },
    ...(filter ? [filter] : []),
  ];
  const data = await indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
    size: 100,
    sort: [{ timestamp: { order: 'desc' } }],
    query: { bool: { must } },
    _source: ['GeoLocation', 'data.srcip', 'rule.level', 'rule.description', 'agent.name', 'timestamp'],
    aggs: {
      top_countries: { terms: { field: 'GeoLocation.country_name.keyword', size: 20 } },
      top_cities:    { terms: { field: 'GeoLocation.city_name.keyword', size: 20 } },
    },
  });
  return data;
}

// ── Performance / Statistics ───────────────────────────────────
export async function getStatistics() {
  try {
    const data = await indexerFetch<any>('/wazuh-statistics-*/_search', {
      size: 20,
      sort: [{ timestamp: { order: 'desc' } }],
      _source: [
        'analysisd.events_received', 'analysisd.alerts_written',
        'analysisd.total_events_decoded', 'analysisd.events_processed',
        'analysisd.events_dropped', 'analysisd.syscheck_events_decoded',
        'analysisd.sca_events_decoded', 'timestamp', 'nodeName',
      ],
    });
    return data.hits?.hits?.map((h: any) => h._source) ?? [];
  } catch { return []; }
}

// ── Sankey / Log Flow ──────────────────────────────────────────
export async function getSankeyData(group?: string | null) {
  const filter = tenantFilter(group);
  const must = filter ? [filter] : [];
  const data = await indexerFetch<any>('/wazuh-alerts-4.x-*/_search', {
    size: 0,
    query: must.length ? { bool: { must } } : { match_all: {} },
    aggs: {
      by_group: {
        terms: { field: 'agent.labels.group', size: 20 },
        aggs: {
          by_rule_group: {
            terms: { field: 'rule.groups', size: 15 },
            aggs: {
              by_manager: { terms: { field: 'manager.name', size: 5 } },
            },
          },
        },
      },
    },
  });
  return data;
}

// ── OpenSearch Security — list all users (for tenant sync) ─────
export async function getIndexerUsers() {
  const data = await indexerFetch<any>('/_plugins/_security/api/internalusers');
  return Object.entries(data ?? {}).map(([username, info]: [string, any]) => ({
    username,
    backend_roles: info.backend_roles ?? [],
    roles: info.roles ?? [],
    attributes: info.attributes ?? {},
  }));
}

// ── OpenSearch Security — list roles (for DLS groups) ─────────
export async function getIndexerRoles() {
  const data = await indexerFetch<any>('/_plugins/_security/api/roles');
  return Object.entries(data ?? {}).map(([name, info]: [string, any]) => ({
    name,
    dls_group: extractDLSGroup(info),
    tenant_permissions: info.tenant_permissions ?? [],
  }));
}

function extractDLSGroup(roleInfo: any): string | null {
  try {
    const indexPerms = roleInfo.index_permissions ?? [];
    for (const perm of indexPerms) {
      if (perm.dls) {
        const dls = typeof perm.dls === 'string' ? JSON.parse(perm.dls) : perm.dls;
        return dls?.match?.['agent.labels.group'] ?? null;
      }
    }
    return null;
  } catch { return null; }
}
