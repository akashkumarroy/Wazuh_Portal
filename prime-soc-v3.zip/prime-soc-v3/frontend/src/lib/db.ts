import { Pool, type PoolClient } from 'pg';

let _pool: Pool | undefined;

function getPool(): Pool {
  if (_pool) return _pool;
  const url = process.env.DATABASE_URL;
  if (!url) throw new Error('DATABASE_URL not set');
  _pool = new Pool({ connectionString: url, ssl: false, max: 10 });
  return _pool;
}

export const pool = { query: (...args: any[]) => getPool().query(...args) };

export async function query<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<T[]> {
  const c = await getPool().connect();
  try { const { rows } = await c.query(sql, params); return rows as T[]; }
  finally { c.release(); }
}

export async function queryOne<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<T | null> {
  const rows = await query<T>(sql, params);
  return rows[0] ?? null;
}
